class ApiService {
  static const String baseUrl = 'https://api.nowdigitaleasy.com/mail/v1';
}

class DriveService {
  static const String baseUrl = 'https://api.nowdigitaleasy.com/drive/v1';
}
