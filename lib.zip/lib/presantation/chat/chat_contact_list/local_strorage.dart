import 'package:hive/hive.dart';

class GrpLocalChatStorage {
  static const String boxName = 'chatBox';

  /// Save messages list to local storage by convoId
  static Future<void> saveMessages(
    String convoId,
    List<Map<String, dynamic>> messages,
  ) async {
    final box = Hive.box(boxName);
    await box.put('chat_messages_$convoId', messages);
  }

  static List<Map<String, dynamic>> loadMessages(String convoId) {
    final box = Hive.box(boxName);
    final stored = box.get('chat_messages_$convoId', defaultValue: <Map>[]);

    if (stored is! List) return [];

    return stored.whereType<Map>().map((e) {
      return e.map((key, value) => MapEntry(key.toString(), value));
    }).toList();
  }
}
