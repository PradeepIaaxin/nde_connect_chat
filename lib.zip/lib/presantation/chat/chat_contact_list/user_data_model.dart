class UserListResponse {
  final List<String> onlineUsers;
  final List<ChatUserlist> data;
  final int total;
  final int page;
  final int limit;
  final bool hasPreviousPage;
  final bool hasNextPage;

  UserListResponse({
    required this.onlineUsers,
    required this.data,
    required this.total,
    required this.page,
    required this.limit,
    required this.hasPreviousPage,
    required this.hasNextPage,
  });

  // Change from expecting a String to a Map<String, dynamic>
  factory UserListResponse.fromJson(Map<String, dynamic> jsonData) {
    return UserListResponse(
      onlineUsers: List<String>.from(jsonData['onlineUsers'].map((x) => x)),
      data: List<ChatUserlist>.from(
          jsonData['data'].map((x) => ChatUserlist.fromJson(x))),
      total: jsonData['total'],
      page: jsonData['page'],
      limit: jsonData['limit'],
      hasPreviousPage: jsonData['hasPreviousPage'],
      hasNextPage: jsonData['hasNextPage'],
    );
  }

  Map<String, dynamic> toJson() {
    final jsonData = {
      'onlineUsers': onlineUsers,
      'data': data.map((x) => x.toJson()).toList(),
      'total': total,
      'page': page,
      'limit': limit,
      'hasPreviousPage': hasPreviousPage,
      'hasNextPage': hasNextPage,
    };
    return jsonData;
  }
}

// Represents a single user in the list
class ChatUserlist {
  final String? id;
  final String userId;
  final String lastName;
  final String firstName;
  final String email;
  final String? conversationId;
  //final String messageId;

  ChatUserlist({
    this.id,
    required this.userId,
    required this.lastName,
    required this.firstName,
    required this.email,
    this.conversationId,

    //   required this.messageId,
  });

  factory ChatUserlist.fromJson(Map<String, dynamic> json) {
    return ChatUserlist(
      id: json["_id"] ?? "",
      userId: json['userId'],
      lastName: json['lastName'],
      firstName: json['firstName'],
      email: json['email'],
      conversationId: json['conversationId'],
      //  messageId: json["message_id"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "_id": id,
      'userId': userId,
      'lastName': lastName,
      'firstName': firstName,
      'email': email,
      'conversationId': conversationId,
      // "message_id": messageId,
    };
  }
}
