import 'package:nde_email/presantation/chat/chat_list/chat_response_model.dart';
import 'dart:developer';

class ChatSessionStorage {
  // In-memory chat list
  static List<Datu> chatList = [];

  static void saveChatList(List<Datu> newChats) {
    chatList = newChats
        .map((chatReq) => Datu(
        id: chatReq.id,
        name: chatReq.name,
        firstName: chatReq.firstName,
        lastName: chatReq.lastName,
        profilePic: chatReq.profilePic,
        lastMessage: chatReq.lastMessage,
        conversationId: chatReq.conversationId,
        isPinned: chatReq.isPinned,
        unreadCount: chatReq.unreadCount,
        isGroupChat: chatReq.isGroupChat,
        datumId: chatReq.datumId,
        lastMessageId: chatReq.lastMessageId,
        lastMessageSender: chatReq.lastMessageSender,
        lastMessageTime: chatReq.lastMessageTime,
        fileName: chatReq.fileName,
        mimeType: chatReq.mimeType,
        contentType: chatReq.contentType,
        isArchived: chatReq.isArchived,
        groupName: chatReq.groupName))
        .toList();
  }

  static List<Datu> getChatList() {
    return chatList;
  }

  static void updateChat({
    required String convoId,
    String? lastMessage,
    DateTime? lastMessageTime,
    String? contentType,
    int unreadIncrement = 0,
    String? name,
    String? profilePic,
  }) {
    for (var chat in chatList) {
      /// 🔥 Fix: match using BOTH id & conversationId
      if (chat.conversationId == convoId || chat.id == convoId) {
        chat.lastMessage = lastMessage ?? chat.lastMessage;
        chat.lastMessageTime = lastMessageTime ?? chat.lastMessageTime;
        chat.contentType = contentType ?? chat.contentType;

        /// 🧑 Update details if given
        chat.name = name ?? chat.name;
        chat.firstName = name?.split(" ").first ?? chat.firstName;
        chat.lastName = name?.split(" ").skip(1).join(" ") ?? chat.lastName;
        chat.profilePic = profilePic ?? chat.profilePic;

        /// 🔔 Unread only if incoming
        if (unreadIncrement > 0) {
          chat.unreadCount = (chat.unreadCount ?? 0) + unreadIncrement;
          log("⚡ Local chat updated: ${chat.unreadCount}");
          log("⚡ Local chat updated: $unreadIncrement");
        }
        log("⚡ Local chat updated: $convoId");
        return;
      }
    }

    log("❌ Chat NOT FOUND for convoId: $convoId");
  }

//   static void updateChat({
//   required String convoId,
//   String? lastMessage,
//   DateTime? lastMessageTime,
//   String? contentType,
//   int unreadIncrement = 0,
// }) {
//   for (var chat in chatList) {
//     if (chat.id == convoId) {
//       chat.lastMessage = lastMessage ?? chat.lastMessage;
//       chat.lastMessageTime = lastMessageTime ?? chat.lastMessageTime;
//       chat.contentType = contentType ?? chat.contentType;
//       chat.unreadCount = (chat.unreadCount ?? 0) + unreadIncrement;
//       break;
//     }
//   }
//   log("Chat updated locally for: $convoId");
// }

  static void clear() {
    chatList.clear();
    log("chat cleared $chatList");
  }
}