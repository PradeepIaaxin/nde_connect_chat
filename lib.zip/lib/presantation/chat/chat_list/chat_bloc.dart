import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nde_email/presantation/chat/Socket/Socket_Service.dart';
import 'chat_api.dart';
import 'chat_event.dart';
import 'chat_state.dart';
import 'chat_response_model.dart';
import 'chat_session_storage/chat_session.dart';

class ChatListBloc extends Bloc<ChatListEvent, ChatListState> {
  final ChatListApiService apiService;
  
  final SocketService socketService;
  StreamSubscription<List<Datu>>? _chatStreamSubscription;

  ChatListBloc({required this.apiService, required this.socketService}) : super(ChatListInitial()) {
    on<FetchChatList>(_onFetchChatList);
    on<ChatListUpdated>(_onChatListUpdated);
    on<ClearChatList>(_onClearChatList);
    on<SetLocalChatList>(_onSetLocalChatList);
    on<UpdateLocalChatList>((event, emit) {
      final updatedList = ChatSessionStorage.getChatList();

      /// WhatsApp sorting: pinned first, then latest message
      updatedList.sort((a, b) {
        if ((a.isPinned ?? false) && !(b.isPinned ?? false)) return -1;
        if (!(a.isPinned ?? false) && (b.isPinned ?? false)) return 1;

        final aTime = a.lastMessageTime ?? DateTime(2000);
        final bTime = b.lastMessageTime ?? DateTime(2000);
        return bTime.compareTo(aTime);
      });

      emit(ChatListLoaded(
        chats: updatedList,
        paginationData: PaginationData(
          totalDocs: updatedList.length,
          page: 1,
          limit: updatedList.length,
          totalPages: 1,
        ),
        page: 1,
      ));
    });

    _setupSocketListeners();
  }


void _setupSocketListeners() {
    socketService.setChatListUpdateCallback((socketChats) {
      add(ChatListUpdated(chats: socketChats));
    });
  }
  /// ⚡ Show cached chats instantly (no loading UI)
  void _onSetLocalChatList(
      SetLocalChatList event, Emitter<ChatListState> emit) {
    if (event.chats.isEmpty) return;

    // Save cache again (optional)
    ChatSessionStorage.saveChatList(event.chats);

    final pagination = PaginationData(
      totalDocs: event.chats.length,
      page: 1,
      limit: event.chats.length,
      totalPages: 1,
      nextPage: null,
      prevPage: null,
    );

    emit(ChatListLoaded(
      chats: event.chats,
      paginationData: pagination,
      page: 1,
    ));
  }

  /// 📌 Fetch chats & listen to stream from API
  Future<void> _onFetchChatList(
      FetchChatList event, Emitter<ChatListState> emit) async {
    // ⚠ Only show shimmer if no cache and no loaded state
    if (state is! ChatListLoaded && ChatSessionStorage.getChatList().isEmpty) {
      emit(ChatListLoading());
    }

    // Cancel previous streaming
    await _chatStreamSubscription?.cancel();

    try {
      final initialChats =
          await apiService.fetchChats(page: event.page, limit: event.limit);

      add(ChatListUpdated(chats: initialChats));

      // 🔄 Live stream updates
      _chatStreamSubscription =
          apiService.getChatStream(page: event.page, limit: event.limit).listen(
        (chats) {
          add(ChatListUpdated(chats: chats));
        },
      );
    } catch (e) {
      emit(ChatListError('Failed to fetch chats: $e'));
    }
  }

  /// 🔁 When new chats come from stream/API updates
  void _onChatListUpdated(ChatListUpdated event, Emitter<ChatListState> emit) {
    if (event.chats.isEmpty) {
      emit(ChatListEmpty());
      return;
    }

    // Save to local cache
    ChatSessionStorage.saveChatList(event.chats);

    final pagination = PaginationData(
      totalDocs: event.chats.length,
      page: 1,
      limit: event.chats.length,
      totalPages: 1,
      nextPage: null,
      prevPage: null,
    );

    emit(ChatListLoaded(
      chats: event.chats,
      paginationData: pagination,
      page: pagination.nextPage ?? 1,
    ));
  }

  /// 🧹 Clear
  void _onClearChatList(
      ClearChatList event, Emitter<ChatListState> emit) async {
    await _chatStreamSubscription?.cancel();
    emit(ChatListInitial());
  }

  @override
  Future<void> close() async {
    await _chatStreamSubscription?.cancel();
    apiService.dispose();
    return super.close();
  }
}
