import 'package:flutter/material.dart';

class ReactionBar extends StatelessWidget {
  final Map<String, dynamic> message;
  final String currentUserId;
  final void Function(Map<String, dynamic> message, String emoji) onReactionTap;

  const ReactionBar({
    Key? key,
    required this.message,
    required this.currentUserId,
    required this.onReactionTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final reactions = message['reactions'] as List? ?? const [];
    if (reactions.isEmpty) return const SizedBox.shrink();

    final reactionCounts = <String, int>{};
    final userReacted = <String, bool>{};

    for (final r in reactions) {
      if (r is! Map<String, dynamic>) continue;

      final emoji = r['emoji']?.toString();
      if (emoji == null || emoji.isEmpty) continue;

      reactionCounts[emoji] = (reactionCounts[emoji] ?? 0) + 1;

      if (r['user']?['_id'] == currentUserId) {
        userReacted[emoji] = true;
      }
    }

    if (reactionCounts.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Wrap(
        spacing: 4,
        runSpacing: 4,
        children: reactionCounts.entries.map((entry) {
          final emoji = entry.key;
          final count = entry.value;
          final isMyReaction = userReacted[emoji] ?? false;

          return GestureDetector(
            onTap: () => onReactionTap(message, emoji),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 2),
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              decoration: BoxDecoration(
                color: isMyReaction ? Colors.blue[50] : null,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '$emoji${count > 1 ? ' $count' : ''}',
                style: const TextStyle(fontSize: 14),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
