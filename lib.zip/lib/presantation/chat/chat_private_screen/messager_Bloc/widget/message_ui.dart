import 'dart:io';
import 'package:any_link_preview/any_link_preview.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/widget/replymessgae.dart';
import 'package:nde_email/presantation/widgets/chat_widgets/messager_Wifgets/ForwardMessageScreen_widget.dart';
import 'package:nde_email/utils/datetime/date_time_utils.dart';
import 'package:nde_email/utils/router/router.dart';
import 'package:swipe_to/swipe_to.dart';
import 'package:url_launcher/url_launcher.dart';

class MessageBubble extends StatelessWidget {
  final Map<String, dynamic> message;
  final bool isSentByMe;
  final bool isSelected;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final VoidCallback? onRightSwipe;
  final Function(String url, String? fileType)? onFileTap;
  final Function(String imageUrl)? onImageTap;
  final Widget Function(String status)? buildStatusIcon;
  final Widget Function(Map<String, dynamic> msg, bool isSentByMe)?
      buildReactionsBar;
  final Color sentMessageColor;
  final Color receivedMessageColor;
  final Color selectedMessageColor;
  final Color borderColor;
  final Color chatColor;
  final Function(Map<String, dynamic> message, String emoji)? onReact;
  final VoidCallback? emojpicker;
  final bool isReply;
  const MessageBubble({
    super.key,
    required this.message,
    required this.isSentByMe,
    required this.isSelected,
    this.onTap,
    this.onLongPress,
    this.onRightSwipe,
    this.onFileTap,
    this.onImageTap,
    this.buildStatusIcon,
    this.buildReactionsBar,
    required this.sentMessageColor,
    required this.receivedMessageColor,
    required this.selectedMessageColor,
    required this.borderColor,
    required this.chatColor,
    this.onReact,
    this.emojpicker,
    required this.isReply,
  });

  @override
  Widget build(BuildContext context) {
    final String content = message['content']?.toString() ?? '';
    final String? imageUrl = message['imageUrl'];
    final String? replycontent = message['replyContent'];
    final String? fileUrl = message['fileUrl'];
    final String? fileName = message['fileName'];
    final String? fileType = message['fileType'];
    final bool? isForwarded = message['isForwarded'];
    final bool? isReplyMessage = message['isReplyMessage'];
    final String messageStatus = message['messageStatus']?.toString() ?? 'sent';

    if (content.isEmpty &&
        (imageUrl == null || imageUrl.isEmpty) &&
        (fileUrl == null || fileUrl.isEmpty)) {
      return const SizedBox.shrink();
    }

    return SwipeTo(
      animationDuration: const Duration(milliseconds: 150),
      iconOnRightSwipe: Icons.reply,
      iconColor: Colors.grey.shade600,
      iconSize: 24.0,
      offsetDx: 0.3,
      swipeSensitivity: 5,
      onRightSwipe: (details) => onRightSwipe?.call(),
      child: GestureDetector(
        onTap: onTap,
        onLongPress: () {
          _showReactionPicker(context);
          onLongPress?.call();
        },
        child: Align(
          alignment: isReply
              ? Alignment.centerLeft
              : isSentByMe
                  ? Alignment.centerRight
                  : Alignment.centerLeft,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                margin: EdgeInsets.only(
                  left: 9,
                  right: 9,
                  bottom: (message['reactions'] != null &&
                          message['reactions'].isNotEmpty)
                      ? 20 // WHEN REACTION EXISTS
                      : 8,
                ),
                padding: isReply
                    ? null
                    : const EdgeInsets.only(
                        left: 5, right: 5, top: 5, bottom: 10),
                constraints: const BoxConstraints(maxWidth: 280),
                decoration: BoxDecoration(
                  color: isReply
                      ? null
                      : isSelected
                          ? selectedMessageColor
                          : (isSentByMe
                              ? sentMessageColor
                              : receivedMessageColor),
                  borderRadius: isReply
                      ? null
                      : BorderRadius.only(
                          topLeft: isSentByMe
                              ? Radius.zero
                              : const Radius.circular(18),
                          topRight: isSentByMe
                              ? const Radius.circular(18)
                              : Radius.zero,
                          bottomLeft: isSentByMe
                              ? const Radius.circular(18)
                              : Radius.zero,
                          bottomRight: isSentByMe
                              ? Radius.zero
                              : const Radius.circular(16),
                        ),
                  border: isSelected
                      ? Border.all(color: borderColor, width: 2)
                      : null,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (message.containsKey('repliedMessage') &&
                        isReplyMessage == true &&
                        message['repliedMessage'] != null)
                      RepliedMessagePreview(
                        message: message,
                        isSentByMe: isSentByMe,
                      ),
                    if (isForwarded == true)
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Image.asset(
                            "assets/images/forward.png",
                            height: 14,
                            width: 14,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            "Forwarded",
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[700],
                            ),
                          ),
                        ],
                      ),
                    if (imageUrl != null && imageUrl.isNotEmpty)
                      _buildImage(content, imageUrl, fileName,
                          isSentByMe: isSentByMe),
                    if (fileUrl != null && fileUrl.isNotEmpty)
                      _buildFile(fileUrl, fileName, fileType, content,
                          isSentByMe: isSentByMe),
                    if (content.isNotEmpty)
                      _buildTextMessage(content, messageStatus),
                    //if (content.isEmpty) _buildTimeRow(messageStatus),
                  ],
                ),
              ),
              if (message['reactions'] != null &&
                  message['reactions'].isNotEmpty)
                Positioned(
                  bottom: -10,
                  right: isSentByMe
                      ? null
                      : (message['reactions'].length == 1
                          ? 61 // when only 1 reaction
                          : 43),
                  left: isSentByMe ? 12 : null,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: GestureDetector(
                        onTap: () {
                          if (emojpicker != null) {
                            print("Emoji picker called");
                            emojpicker?.call();
                          } else {
                            _showReactionPicker(context);
                          }
                        },
                        child: _buildReactionsBarWidget(message)),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _showReactionPicker(BuildContext context) {
    if (onReact == null) return;
    final List<String> emojis = ['👍', '❤️', '😂', '😮', '😢', '🙏'];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Container(
          margin: const EdgeInsets.all(40),
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: emojis
                .map((emoji) => GestureDetector(
                      onTap: () {
                        Navigator.pop(ctx);

                        onReact?.call(message, emoji);
                      },
                      child: Text(emoji, style: const TextStyle(fontSize: 26)),
                    ))
                .toList(),
          ),
        );
      },
    );
  }

  Widget _buildReactionsBarWidget(Map<String, dynamic> msg) {
    final reactionsRaw = msg['reactions'] ?? [];

    final reactions = (reactionsRaw as List?)
            ?.where((r) => r is Map)
            .map((r) => Map<String, dynamic>.from(r as Map))
            .toList() ??
        [];

    if (reactions.isEmpty) return const SizedBox.shrink();

    // Count occurrences of each emoji
    final Map<String, int> reactionCounts = {};
    for (final reaction in reactions) {
      final emoji = reaction['emoji']?.toString();
      if (emoji != null && emoji.isNotEmpty) {
        reactionCounts[emoji] = (reactionCounts[emoji] ?? 0) + 1;
      }
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: reactionCounts.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: Text(
              entry.value > 1 ? '${entry.key} ${entry.value}' : entry.key,
              style: const TextStyle(fontSize: 14),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildImage(
    String content,
    String imageUrl,
    String? fileName, {
    required bool isSentByMe,
  }) {
    if (content == "Message Deleted") return const SizedBox();
    final String name = fileName ?? 'Unknown file';
    final String extension = name.split('.').last.toLowerCase();
    final String? fileSize = message['fileSize']?.toString();

    // List of image extensions
    final Set<String> imageExtensions = {
      'jpg',
      'jpeg',
      'png',
      'gif',
      'webp',
      'bmp',
      'heic',
      'heif'
    };

    final bool isImage = imageExtensions.contains(extension);

    // Determine file icon
    IconData getFileIcon() {
      switch (extension) {
        case 'pdf':
          return Icons.picture_as_pdf;
        case 'doc':
        case 'docx':
          return Icons.description;
        case 'xls':
        case 'xlsx':
          return Icons.table_chart;
        case 'ppt':
        case 'pptx':
          return Icons.slideshow;
        case 'zip':
        case 'rar':
        case '7z':
          return Icons.archive;
        case 'mp4':
        case 'avi':
        case 'mov':
        case 'mkv':
          return Icons.video_file;
        case 'mp3':
        case 'wav':
        case 'aac':
          return Icons.audio_file;
        default:
          if (isImage) return Icons.image;
          return Icons.insert_drive_file;
      }
    }

    return Stack(
      children: [
        GestureDetector(
          onTap: () => onImageTap?.call(imageUrl),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 2,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
              child: imageUrl.startsWith('http')
                  ? CachedNetworkImage(
                      imageUrl: imageUrl,
                      width: 260,
                      height: isImage ? 350 : 0,
                      fit: BoxFit.cover,
                      placeholder: (context, url) => Container(
                        width: 260,
                        height: 200,
                        color: Colors.grey.shade300,
                        child: const Center(child: CircularProgressIndicator()),
                      ),
                      errorWidget: (context, url, error) => Container(
                        width: 260,
                        height: 200,
                        color: Colors.grey.shade300,
                        child: const Icon(Icons.error, color: Colors.red),
                      ),
                    )
                  : Image.file(
                      File(imageUrl),
                      width: 260,
                      height: 200,
                      fit: BoxFit.cover,
                    ),
            ),
          ),
        ),
        Positioned(
          bottom: 5,
          right: 4,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 2,
                  offset: const Offset(0, 1),
                ),
              ],
              //color: Colors.black.withOpacity(0.4),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  TimeUtils.formatUtcToIst(message['time']),
                  style: const TextStyle(
                    fontSize: 10,
                    color: Colors.white,
                  ),
                ),
                if (isSentByMe) ...[
                  const SizedBox(width: 4),
                  buildStatusIcon?.call(
                          message['messageStatus']?.toString() ?? 'sent') ??
                      const Icon(Icons.done, size: 12, color: Colors.white),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFile(
    String fileUrl,
    String? fileName,
    String? fileType,
    String content, {
    required bool isSentByMe,
  }) {
    if (content == "Message Deleted") return const SizedBox();

    // Extract extension from fileName (fallback to fileType if needed)
    final String name = fileName ?? 'Unknown file';
    final String extension = name.split('.').last.toLowerCase();
    final String? fileSize = message['fileSize']?.toString();

    // List of image extensions
    final Set<String> imageExtensions = {
      'jpg',
      'jpeg',
      'png',
      'gif',
      'webp',
      'bmp',
      'heic',
      'heif'
    };

    final bool isImage = imageExtensions.contains(extension);

    // Determine file icon
    IconData getFileIcon() {
      switch (extension) {
        case 'pdf':
          return Icons.picture_as_pdf;
        case 'doc':
        case 'docx':
          return Icons.description;
        case 'xls':
        case 'xlsx':
          return Icons.table_chart;
        case 'ppt':
        case 'pptx':
          return Icons.slideshow;
        case 'zip':
        case 'rar':
        case '7z':
          return Icons.archive;
        case 'mp4':
        case 'avi':
        case 'mov':
        case 'mkv':
          return Icons.video_file;
        case 'mp3':
        case 'wav':
        case 'aac':
          return Icons.audio_file;
        default:
          if (isImage) return Icons.image;
          return Icons.insert_drive_file;
      }
    }

    return isImage
        ? Container(
            height: 1,
            width: 1,
          )
        : Container(
            width: 300,
            height: 100,
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              //border: Border.all(color: Colors.grey.shade300),
            ),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 8),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(_getFileIcon(fileType), color: chatColor, size: 30),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          fileName ?? 'Download file',
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.download_rounded),
                        onPressed: () => onFileTap?.call(fileUrl, fileType),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: -220,
                  left: isSentByMe ? -320 : null,
                  right: isSentByMe ? null : -60,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () {
                        print("Forwarding file: $fileName");
                        MyRouter.push(
                          screen: ForwardMessageScreen(
                            messages: [message],
                            currentUserId: message['senderId'] ?? '',
                            conversionalid: "",
                            username: message['senderName'] ?? '',
                          ),
                        );
                      },
                      child: CircleAvatar(
                        maxRadius: 16,
                        backgroundColor: Colors.white,
                        child: Image.asset(
                          "assets/images/forward.png",
                          height: 20,
                          width: 20,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ));
  }

  Widget _buildTextMessage(String content, String messageStatus) {
    final bool useIntrinsic = content.trim().length < 25;
    bool isExpanded = false;

    return StatefulBuilder(
      builder: (context, setState) {
        final Widget textWidget = Padding(
          padding: const EdgeInsets.only(
            left: 5,
          ),
          child: Linkify(
            text: content,
            maxLines: isExpanded ? null : 9,
            overflow: isExpanded ? TextOverflow.visible : TextOverflow.ellipsis,
            onOpen: (link) async {
              final uri = Uri.parse(link.url);
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              }
            },
            style: const TextStyle(fontSize: 15, color: Colors.black87),
            linkStyle: const TextStyle(color: Colors.blue),
            options: LinkifyOptions(
              humanize: true,
              looseUrl: true,
              defaultToHttps: true,
            ),
            linkifiers: [
              EmailLinkifier(),
              UrlLinkifier(),
              CustomPhoneNumberLinkifier(),
            ],
          ),
        );

        final Widget messageContent = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (RegExp(r'https?:\/\/[^\s]+').hasMatch(content))
              AnyLinkPreview(
                link: RegExp(r'https?:\/\/[^\s]+')
                        .firstMatch(content)
                        ?.group(0) ??
                    '',
                displayDirection: UIDirection.uiDirectionVertical,
                showMultimedia: true,
                backgroundColor: Colors.grey.shade200,
                bodyStyle: const TextStyle(color: Colors.transparent),
                cache: const Duration(hours: 1),
              ),

            /// 💬 WhatsApp-like row (Message + Time + Tick)
            Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Flexible(child: textWidget),
                const SizedBox(width: 6),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(
                    TimeUtils.formatUtcToIst(message['time']),
                    style: const TextStyle(fontSize: 10, color: Colors.black54),
                  ),
                ),
                const SizedBox(width: 4),
                if (isSentByMe)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: buildStatusIcon?.call(messageStatus) ??
                        const SizedBox(),
                  ),
              ],
            ),

            if (!isExpanded && _isTextLong(content))
              GestureDetector(
                onTap: () => setState(() => isExpanded = true),
                child: const Padding(
                  padding: EdgeInsets.only(top: 4),
                  child: Text(
                    "Read more",
                    style: TextStyle(color: Colors.blue, fontSize: 14),
                  ),
                ),
              ),
          ],
        );

        final constrainedBox = ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 250),
          child: messageContent,
        );

        final textBubble = Padding(
          padding: const EdgeInsets.only(top: 6),
          child: useIntrinsic
              ? IntrinsicWidth(child: constrainedBox)
              : constrainedBox,
        );

        final hasLink = RegExp(r'https?:\/\/[^\s]+').hasMatch(content);

        return hasLink
            ? Stack(
                clipBehavior: Clip.none,
                children: [
                  textBubble,
                  Positioned(
                    top: 35,
                    left: isSentByMe ? -60 : null,
                    right: isSentByMe ? null : -60,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () {
                          print("Forwarding link: $content");
                          MyRouter.push(
                            screen: ForwardMessageScreen(
                              messages: [message],
                              currentUserId: message['senderId'] ?? '',
                              conversionalid: "",
                              username: message['senderName'] ?? '',
                            ),
                          );
                        },
                        child: CircleAvatar(
                          maxRadius: 16,
                          backgroundColor: Colors.white,
                          child: Image.asset(
                            "assets/images/forward.png",
                            height: 18,
                            width: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )
            : textBubble;
      },
    );
  }

  bool _isTextLong(String text) {
    const maxCharsPerLine = 40;
    return (text.length / maxCharsPerLine).ceil() > 9;
  }

  Widget _buildTimeRow(String messageStatus) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            TimeUtils.formatUtcToIst(message['time']),
            style: const TextStyle(fontSize: 10, color: Colors.black54),
          ),
          const SizedBox(width: 4),
          if (isSentByMe)
            buildStatusIcon?.call(messageStatus) ?? const SizedBox(),
        ],
      ),
    );
  }

  IconData _getFileIcon(String? fileType) {
    switch (fileType) {
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'doc':
      case 'docx':
        return Icons.description;
      case 'xls':
      case 'xlsx':
        return Icons.table_chart;
      default:
        return Icons.insert_drive_file;
    }
  }
}

class CustomPhoneNumberLinkifier extends Linkifier {
  final RegExp _phoneRegex = RegExp(r'(\+?\d{10,15})');

  @override
  List<LinkifyElement> parse(
      List<LinkifyElement> elements, LinkifyOptions options) {
    final List<LinkifyElement> result = [];
    for (final element in elements) {
      if (element is TextElement) {
        final text = element.text;
        int start = 0;
        for (final match in _phoneRegex.allMatches(text)) {
          if (match.start != start) {
            result.add(TextElement(text.substring(start, match.start)));
          }
          result.add(LinkableElement(match.group(0)!, match.group(0)!));
          start = match.end;
        }
        if (start < text.length) {
          result.add(TextElement(text.substring(start)));
        }
      } else {
        result.add(element);
      }
    }
    return result;
  }
}
