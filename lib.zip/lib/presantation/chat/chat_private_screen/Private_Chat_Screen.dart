// import 'dart:async';
// import 'dart:developer';
// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:mime/mime.dart';
// import 'package:nde_email/data/respiratory.dart';
// import 'package:nde_email/presantation/chat/Socket/Socket_Service.dart';
// import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/message_handler.dart';
// import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/widget/audio_reuable.dart';
// import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/widget/date_separate.dart';
// import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/widget/double_tick_ui.dart';
// import 'package:nde_email/presantation/chat/widget/delete_dialogue.dart';
// import 'package:nde_email/presantation/chat/widget/image_viewer.dart';
// import 'package:nde_email/presantation/chat/widget/reation_bottom.dart';
// import 'package:nde_email/presantation/widgets/chat_widgets/messager_Wifgets/ForwardMessageScreen_widget.dart';
// import 'package:nde_email/presantation/widgets/chat_widgets/messager_Wifgets/buildMessageInputField_widgets.dart';
// import 'package:nde_email/presantation/widgets/chat_widgets/messager_Wifgets/show_Bottom_Sheet.dart';
// import 'package:nde_email/utils/imports/common_imports.dart';
// import 'package:nde_email/utils/reusbale/common_import.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:url_launcher/url_launcher.dart';
// import 'package:open_file/open_file.dart';

// import 'messager_Bloc/MessagerBloc.dart';
// import 'messager_Bloc/MessagerEvent.dart';
// import 'messager_Bloc/MessagerState.dart';

// class PrivateChatScreen extends StatefulWidget {
//   final String convoId;
//   final String profileAvatarUrl;
//   final String userName;
//   final String lastSeen;
//   final String? receiverId;
//   final String? datumId;
//   final String? firstname;
//   final String? lastname;
//   final bool grpChat;
//   final bool favourite;

//   /// Optional initial messages to show immediately (useful after forwarding)
//   final List<Map<String, dynamic>>? initialMessages;

//   const PrivateChatScreen({
//     super.key,
//     required this.convoId,
//     required this.profileAvatarUrl,
//     required this.userName,
//     required this.lastSeen,
//     this.receiverId,
//     required this.datumId,
//     this.firstname,
//     this.lastname,
//     required this.grpChat,
//     required this.favourite,
//     this.initialMessages,
//   });

//   @override
//   _PrivateChatScreenState createState() => _PrivateChatScreenState();
// }

// class _PrivateChatScreenState extends State<PrivateChatScreen> {
//   // Controllers / focus
//   final TextEditingController _messageController = TextEditingController();
//   final ScrollController _scrollController = ScrollController();
//   final FocusNode _focusNode = FocusNode();
// // add near other fields
//   bool _suppressReactionDialog =
//       false; // used if you want to avoid opening both inline and bottom sheet
//   String? _highlightedMessageId;
//   Timer? _highlightTimer;

//   // Services & handlers
//   final SocketService socketService = SocketService();
//   late MessagerBloc _messagerBloc;
//   MessageHandler? _messageHandler;
//   StreamSubscription<Map<String, dynamic>>? _statusSubscription;

//   // Message storage (in-memory)
//   final List<Map<String, dynamic>> socketMessages = [];
//   final List<Map<String, dynamic>> dbMessages = [];
//   final List<Map<String, dynamic>> messages = [];

//   // Seen IDs to dedupe
//   final Set<String> _seenMessageIds = <String>{};

//   // Debounce saving
//   Timer? _saveDebounceTimer;
//   final Duration _saveDebounceDuration = const Duration(milliseconds: 300);

//   // Notifier for the UI list
//   final ValueNotifier<List<Map<String, dynamic>>> _messagesNotifier =
//       ValueNotifier([]);
//   //final Map<String, GlobalKey> _messageKeys = {};

//   // State
//   String currentUserId = '';
//   bool _showSearchAppBar = false;
//   bool _isRecording = false;
//   bool _isPaused = false;
//   int _recordDuration = 0;
//   Timer? _timer;
//   String? _recordedFilePath;

//   // Pagination: show only last 10 initially
//   int _currentPage = 1;
//   final int _initialLimit = 10;
//   final int _pageSize = 5;

//   bool _isLoadingMore = false;
//   bool _hasNextPage = false;
//   double _prevScrollExtentBeforeLoad = 0.0;

//   // Selection / reactions
//   final Set<String> _selectedMessageIds = {};
//   bool _isSelectionMode = false;
//   final List<dynamic> _selectedMessages = [];
//   StreamSubscription<MessageReaction>? _reactionSubscription;
//   final Set<String> _alreadyRead = {};
//   final Set<String> _unreadMessageIds = {};
//   bool _hasSentInitialReadReceipts = false;
//   final Set<String> _selectedMessageKeys = {};
//   Map<String, dynamic>? _replyMessage;

//   // Media
//   File? _imageFile;
//   File? _fileUrl;

//   // Recorder helper
//   final recorderHelper = AudioRecorderHelper();
//   bool _initialScrollDone = false;

//   @override
//   void initState() {
//     super.initState();
//     _messagerBloc = context.read<MessagerBloc>();
//     _messageHandler = MessageHandler(
//       currentUserId: currentUserId,
//       convoId: widget.convoId,
//     );
//     _scrollController.addListener(_scrollListener);
//     _initializeChat();

//   }

//   @override
//   void dispose() {
//     _reactionSubscription?.cancel();
//     _scrollController.removeListener(_scrollListener);

//     // ✅ force a final save so recent messages are persisted
//     _saveDebounceTimer?.cancel();
//     _saveAllMessages();
//     _statusSubscription?.cancel(); // 👈 IMPORTANT

//     _scrollController.dispose();
//     _messageController.dispose();
//     _focusNode.dispose();
//     _messagesNotifier.dispose();
//     super.dispose();
//   }

//   // ------------------ Initialization ------------------
//   Future<void> _initializeChat() async {
//     log("Initializing chat for convoId: ${widget.convoId}");
//     socketMessages.clear();
//     messages.clear();
//     dbMessages.clear();
//     _seenMessageIds.clear();
//     _initialScrollDone = false;

//     // If initial messages passed (forwarding), normalize and insert
//     if (widget.initialMessages != null && widget.initialMessages!.isNotEmpty) {
//       final normalized = widget.initialMessages!
//           .map<Map<String, dynamic>>((raw) => normalizeMessage(raw))
//           .where((m) => m.isNotEmpty)
//           .toList();
//       dbMessages.addAll(normalized);
//       for (var m in normalized) {
//         final id = (m['message_id'] ?? '').toString();
//         if (id.isNotEmpty) _seenMessageIds.add(id);
//       }
//       _updateNotifier();
//       _scheduleSaveMessages();
//     } else if (widget.convoId.isNotEmpty) {
//       final loaded = LocalChatStorage.loadMessages(widget.convoId) ?? [];
//       final normalized = [
//         for (var msg in loaded)
//           if (msg.isNotEmpty) normalizeMessage(msg)
//       ];
//       dbMessages.addAll(normalized);
//       for (var m in normalized) {
//         final id = (m['message_id'] ?? '').toString();
//         if (id.isNotEmpty) _seenMessageIds.add(id);
//       }
//       _updateNotifier();

//       // ⬇️ Scroll to bottom ONCE when opening
//       WidgetsBinding.instance.addPostFrameCallback((_) {
//         if (!_initialScrollDone) {
//           _scrollToBottom();
//           _initialScrollDone = true;
//         }
//       });
//     }

//     await Future.wait([_initializeSocket(), _loadCurrentUserId()]);

//     if (widget.convoId.isNotEmpty) {
//       _fetchMessages();
//     }
//   }
//   void _handleIncomingRawMessage(Map<String, dynamic> raw, {String? event}) {
//     // 1. Normalize first
//     final normalized = normalizeMessage(raw);
//     final msgId = (normalized['message_id'] ?? '').toString();
//     final senderId = (normalized['senderId'] ?? '').toString();

//     // 2. Ignore my own messages (except forward echo)
//     if (senderId == currentUserId) {
//       if (event == 'forward_message' && msgId.isNotEmpty) {
//         _replaceLocalForwardIdWithRealId(msgId, normalized);
//       }
//       log('Echo of my own message ignored: $msgId');
//       return;
//     }

//     // 3. CRITICAL: Block only REAL duplicates (not temp/forward ids)
//     if (msgId.isNotEmpty &&
//         !msgId.startsWith('temp_') &&
//         !msgId.startsWith('forward_') &&
//         _seenMessageIds.contains(msgId)) {
//       log('Duplicate incoming message blocked: $msgId');
//       return;
//     }

//     // 4. Block if already in any list
//     final alreadyInList = [dbMessages, messages, socketMessages].any((list) =>
//         list.any((m) => (m['message_id'] ?? '').toString() == msgId));

//     if (alreadyInList) {
//       log('Message already exists in local lists: $msgId');
//       return;
//     }

//     // 5. Add media info
//     normalized['imageUrl'] = raw['thumbnailUrl'] ?? raw['originalUrl'];
//     normalized['fileUrl'] = raw['originalUrl'] ?? raw['fileUrl'];
//     normalized['fileName'] = raw['fileName'];
//     normalized['fileType'] = raw['mimeType'] ?? raw['fileType'];
//     normalized['isForwarded'] = raw['isForwarded'] == true;
//     normalized['roomId'] = raw['roomId']?.toString();

//     // 6. Safe to add
//     socketMessages.add(normalized);

//     // Only track real server IDs
//     if (msgId.isNotEmpty && !msgId.startsWith('temp_') && !msgId.startsWith('forward_')) {
//       _seenMessageIds.add(msgId);
//     }

//     if (!mounted) return;

//     _updateNotifier();
//     _scheduleSaveMessages();
//     _scrollToBottom();

//     // Send read receipt
//     if (msgId.isNotEmpty) {
//       _sendReadReceipts([msgId]);
//     }

//     log('New incoming message added: $msgId from $senderId');
//   }
//   Future<void> _initializeSocket() async {
//     final token = await UserPreferences.getAccessToken();
//     if (token == null) {
//       log("Access token is null. Socket connection not initialized.");
//     }
//   }

//   Future<void> _loadCurrentUserId() async {
//     final userId = await UserPreferences.getUserId() ?? '';
//     if (userId.isEmpty || (widget.datumId?.isEmpty ?? true)) {
//       debugPrint('⚠️ _loadCurrentUserId: missing userId or datumId');
//       return;
//     }

//     currentUserId = userId;
//     // create message handler now that currentUserId is known
//     _messageHandler =
//         MessageHandler(currentUserId: currentUserId, convoId: widget.convoId);

//     // connect to socket (singleton)
//     await socketService.connectPrivateRoom(
//         currentUserId, widget.datumId!, onMessageReceived, false);

//     // start listening
//     _setupMessageListener();
//     _setupReactionListener();

//     if (mounted) setState(() {});
//   }

//   bool _hasReplyForMessage(Map<String, dynamic> message) {
//     final reply = message['reply'];

//     // reply map exists
//     if (reply is Map) {
//       final id = (reply['id'] ??
//               reply['message_id'] ??
//               reply['messageId'] ??
//               reply['reply_message_id'])
//           ?.toString();

//       final replyContent =
//           (reply['replyContent'] ?? reply['content'] ?? reply['message'] ?? '')
//               .toString();

//       // Show reply UI if:
//       //   - id exists, OR
//       //   - replyContent not empty
//       if ((id != null && id.isNotEmpty) || replyContent.isNotEmpty) {
//         return true;
//       }
//     }

//     // Top-level id also treated as reply
//     final topReplyId = (message['reply_message_id'] ??
//             message['replyMessageId'] ??
//             message['reply_to'] ??
//             message['replyId'])
//         ?.toString();

//     if (topReplyId != null && topReplyId.isNotEmpty) {
//       return true;
//     }

//     return false;
//   }

//   Map<String, dynamic> _mergeReplyInfoIfMissing(
//     Map<String, dynamic> fresh,
//     Map<String, dynamic> existing,
//   ) {
//     final merged = Map<String, dynamic>.from(fresh);

//     final hadReplyBefore = _hasReplyForMessage(existing);
//     final hasReplyNow = _hasReplyForMessage(fresh);

//     if (hadReplyBefore && !hasReplyNow) {
//       // carry over flags + ids
//       if (existing['isReplyMessage'] == true) {
//         merged['isReplyMessage'] = true;
//       }

//       if (existing['reply_message_id'] != null) {
//         merged['reply_message_id'] ??= existing['reply_message_id'];
//       }

//       if (existing['reply'] is Map) {
//         merged['reply'] ??= Map<String, dynamic>.from(existing['reply']);
//       }
//     }

//     return merged;
//   }

//   void _setupMessageListener() {
//     if (currentUserId.isEmpty || widget.datumId == null) return;
//     _messagerBloc.add(
//         ListenToMessages(senderId: currentUserId, receiverId: widget.datumId!));

//     _statusSubscription ??=
//         socketService.statusUpdateStream.listen((statusUpdate) {
//       if (!mounted) return;
//       final status = statusUpdate['messageStatus'] ?? 'read';
//       final ids = statusUpdate['messageIds'] ?? statusUpdate['messageId'];

//       debugPrint('📥 Status update received: $statusUpdate');

//       if (ids is List) {
//         for (final id in ids.whereType<String>()) {
//           _updateMessageStatus(id, status);
//         }
//       } else if (ids is String) {
//         _updateMessageStatus(ids, status);
//       }
//     });
//   }

//   void _setupReactionListener() {
//     _reactionSubscription = socketService.reactionStream.listen((reaction) {
//       _updateMessageWithReaction(reaction);
//     });
//   }

//   // ------------------ Message Handler helpers ------------------
//   Map<String, dynamic> normalizeMessage(dynamic rawMsg) {
//     if (rawMsg == null) return {};

//     final m = <String, dynamic>{};

//     // ---------- BASIC ----------
//     m['message_id'] =
//         (rawMsg['message_id'] ?? rawMsg['id'] ?? rawMsg['messageId'])
//             ?.toString();
//     m['content'] = (rawMsg['content'] ?? rawMsg['message'] ?? '').toString();
//     m['time'] = rawMsg['time'] ?? rawMsg['createdAt'];

//     // ---------- SENDER ----------
//     dynamic senderRaw = rawMsg['sender'];
//     String? senderId = rawMsg['senderId']?.toString();

//     if (senderRaw is Map) {
//       senderId ??= (senderRaw['_id'] ?? senderRaw['id'] ?? senderRaw['userId'])
//           ?.toString();
//     } else if (senderRaw != null && senderId == null) {
//       senderId = senderRaw.toString();
//       senderRaw = {'_id': senderId};
//     } else if (senderRaw == null && senderId != null) {
//       senderRaw = {'_id': senderId};
//     }

//     m['sender'] = senderRaw;
//     m['senderId'] = senderId;

//     // ---------- RECEIVER ----------
//     dynamic receiverRaw = rawMsg['receiver'];
//     String? receiverId = rawMsg['receiverId']?.toString();

//     if (receiverRaw is Map) {
//       receiverId ??=
//           (receiverRaw['_id'] ?? receiverRaw['id'] ?? receiverRaw['userId'])
//               ?.toString();
//     } else if (receiverRaw != null && receiverId == null) {
//       receiverId = receiverRaw.toString();
//       receiverRaw = {'_id': receiverId};
//     } else if (receiverRaw == null && receiverId != null) {
//       receiverRaw = {'_id': receiverId};
//     }

//     m['receiver'] = receiverRaw;
//     m['receiverId'] = receiverId;

//     // ---------- REPLY NORMALIZATION ----------
//     bool isReply = rawMsg['isReplyMessage'] == true;

//     Map<String, dynamic>? replyMap;

//     if (rawMsg['reply'] is Map) {
//       replyMap = Map<String, dynamic>.from(rawMsg['reply']);
//     } else if (rawMsg['replyTo'] is Map) {
//       replyMap = Map<String, dynamic>.from(rawMsg['replyTo']);
//     }

//     String? replyId = (rawMsg['reply_message_id'] ??
//             rawMsg['replyMessageId'] ??
//             rawMsg['reply_to'] ??
//             rawMsg['replyId'])
//         ?.toString();

//     if ((replyId == null || replyId.isEmpty) && replyMap != null) {
//       replyId = (replyMap['id'] ??
//               replyMap['message_id'] ??
//               replyMap['messageId'] ??
//               replyMap['reply_message_id'])
//           ?.toString();
//     }

//     if (replyId != null && replyId.isNotEmpty) {
//       isReply = true;

//       replyMap ??= <String, dynamic>{};
//       replyMap['id'] ??= replyId;
//       replyMap['message_id'] ??= replyId;
//       replyMap['reply_message_id'] ??= replyId;

//       final replyContent = rawMsg['replyContent'] ??
//           replyMap['replyContent'] ??
//           replyMap['content'] ??
//           replyMap['message'] ??
//           '';

//       replyMap['replyContent'] = replyContent;
//       replyMap['content'] ??= replyContent;

//       m['reply_message_id'] = replyId;
//       m['reply'] = replyMap;
//     }

//     if (isReply) {
//       m['isReplyMessage'] = true;
//     }

//     // ---------- REACTIONS (PERSISTED LOCALLY) ----------
//     if (rawMsg['reactions'] is List) {
//       m['reactions'] = (rawMsg['reactions'] as List)
//           .where((e) => e is Map)
//           .map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e as Map))
//           .toList();
//     }

//     // ---------- FORWARDED META ----------
//     final bool isForwarded = rawMsg['isForwarded'] == true ||
//         rawMsg['forwarded'] == true ||
//         rawMsg['is_forwarded'] == true ||
//         rawMsg['isForwardMessage'] == true;

//     if (isForwarded) {
//       m['isForwarded'] = true;
//     }

//     // keep a stable real/original id for reactions on forwarded messages
//     final original = rawMsg['original_message_id'] ??
//         rawMsg['originalMessageId'] ??
//         rawMsg['parent_message_id'] ??
//         rawMsg['parentMessageId'];

//     if (original != null && original.toString().isNotEmpty) {
//       m['original_message_id'] = original.toString();
//     }

//     return m;
//   }

//   DateTime _parseTime(dynamic time) {
//     _ensureMessageHandler();
//     return _messageHandler!.parseTime(time);
//   }

//   String _generateMessageKey(Map<String, dynamic> msg) {
//     _ensureMessageHandler();
//     return _messageHandler!.generateMessageKey(msg);
//   }

//   bool isSameDay(DateTime? d1, DateTime? d2) {
//     _ensureMessageHandler();
//     return _messageHandler!.isSameDay(d1, d2);
//   }

//   void _ensureMessageHandler() {
//     _messageHandler ??=
//         MessageHandler(currentUserId: currentUserId, convoId: widget.convoId);
//   }

//   // ------------------ Debounced disk save ------------------
//   void _scheduleSaveMessages() {
//     _saveDebounceTimer?.cancel();
//     _saveDebounceTimer = Timer(_saveDebounceDuration, () {
//       if (widget.convoId.isEmpty) return;
//       final combined = [...dbMessages, ...messages, ...socketMessages];
//       LocalChatStorage.saveMessages(widget.convoId, combined);
//     });
//   }

//   void _updateNotifier() {
//     final combined = <Map<String, dynamic>>[];
//     combined.addAll(dbMessages);
//     combined.addAll(messages);
//     combined.addAll(socketMessages);
//     _messagesNotifier.value =
//         List<Map<String, dynamic>>.unmodifiable(_getCombinedMessages());
//   }

//   // ------------------ Send message (optimistic) ------------------
//   void _sendMessage() async {
//     if (_messageController.text.trim().isEmpty || widget.datumId == null) {
//       return;
//     }

//     final original = _replyMessage; // message we are replying to
//     final messageText = _messageController.text.trim();

//     // 1️⃣ Extract reply message id ONE TIME
//     final String? replyMessageId = original == null
//         ? null
//         : (original['message_id'] ?? original['messageId'] ?? original['id'])
//             ?.toString();

//     // 2️⃣ Optional payload for local UI preview
//     final replyPayload = original == null
//         ? null
//         : {
//             'id': replyMessageId,
//             'message_id': replyMessageId,
//             'reply_message_id': replyMessageId,
//             'replyContent':
//                 (original['content'] ?? original['message'] ?? '').toString(),
//             'content':
//                 (original['content'] ?? original['message'] ?? '').toString(),
//           };

//     final completer = Completer<Message>();

//     // Wait for bloc to confirm send
//     final subscription = _messagerBloc.stream.listen((state) {
//       if (state is MessageSentSuccessfully) {
//         completer.complete(state.sentMessage);
//       }
//     });

//     // 3️⃣ PASS replyMessageId INTO EVENT
//     _messagerBloc.add(
//       SendMessageEvent(
//         convoId: widget.convoId,
//         message: messageText,
//         senderId: currentUserId,
//         receiverId: widget.datumId!,
//         replyTo: original,
//         replyMessageId: replyMessageId,
//       ),
//     );

//     final sentMessage = await completer.future;
//     await subscription.cancel();

//     // 4️⃣ Build local message map WITH reply info
//     final messageMap = {
//       'message_id': sentMessage.messageId,
//       'content': sentMessage.message,
//       'sender': {'_id': sentMessage.senderId},
//       'senderId': sentMessage.senderId,
//       'receiver': {'_id': sentMessage.receiverId},
//       'receiverId': sentMessage.receiverId,
//       'messageStatus': sentMessage.messageStatus,
//       'time': sentMessage.time.toIso8601String(),
//       'isReplyMessage': replyPayload != null,
//       if (replyPayload != null) 'reply': replyPayload,
//       if (replyPayload != null) 'reply_message_id': replyMessageId,
//     };

//     setState(() {
//       // add to socketMessages; BlocListener will later merge/normalize
//       socketMessages.add(messageMap);
//       _updateNotifier(); // uses _getCombinedMessages() -> no visible duplicates
//       _scheduleSaveMessages();
//       _scrollToBottom();
//     });

//     _messageController.clear();
//     _replyMessage = null;
//     _imageFile = null;
//   }

//   Future<bool> _scrollToMessageById(String messageId,
//       {bool fetchIfMissing = false}) async {
//     if (messageId.trim().isEmpty) return false;

//     final combined = _getCombinedMessages();
//     final index = combined.indexWhere((m) {
//       final mid =
//           (m['message_id'] ?? m['messageId'] ?? m['id'] ?? '').toString();
//       return mid == messageId;
//     });

//     if (index != -1 && _scrollController.hasClients) {
//       const itemHeightEstimate = 80.0;
//       final target = (index * itemHeightEstimate)
//           .clamp(0.0, _scrollController.position.maxScrollExtent);

//       await _scrollController.animateTo(
//         target,
//         duration: const Duration(milliseconds: 400),
//         curve: Curves.easeOut,
//       );

//       // ⭐ Set highlight on this message
//       setState(() {
//         _highlightedMessageId = messageId;
//       });

//       // clear any previous timer
//       _highlightTimer?.cancel();
//       _highlightTimer = Timer(const Duration(seconds: 2), () {
//         if (mounted) {
//           setState(() {
//             _highlightedMessageId = null;
//           });
//         }
//       });

//       return true;
//     }

//     return false;
//   }

//   // ------------------ Send image (optimistic) ------------------
//   void _sendMessageImage() async {
//     await _loadSessionImagePath();
//     await _loadSessionFilePath();

//     final nowIso = DateTime.now().toIso8601String();
//     final String? mimeType =
//         _fileUrl != null ? lookupMimeType(_fileUrl!.path) : null;

//     final optimistic = {
//       'message_id': 'temp_${DateTime.now().millisecondsSinceEpoch}',
//       'content': _messageController.text.trim(),
//       'sender': {'_id': currentUserId},
//       'receiver': {'_id': widget.datumId},
//       'messageStatus': 'pending',
//       'time': nowIso,
//       'fileName': _fileUrl?.path.split('/').last,
//       'fileType': mimeType,
//       'imageUrl': _imageFile?.path,
//       'fileUrl': _fileUrl?.path,
//     };

//     socketMessages.add(optimistic);
//     final idStr = (optimistic['message_id'] ?? '').toString();
//     if (idStr.isNotEmpty) _seenMessageIds.add(idStr);
//     _updateNotifier();
//     _scheduleSaveMessages();
//     _scrollToBottom();

//     if (_fileUrl != null) {
//       context.read<MessagerBloc>().add(UploadFileEvent(File(_fileUrl!.path),
//           widget.convoId, currentUserId, widget.datumId ?? "", ""));
//     }

//     _messageController.clear();
//     _imageFile = null;
//     _fileUrl = null;
//     await _clearSessionPaths();
//   }

//   Future<void> _openCamera() async {
//     try {
//       final XFile? file =
//           await ImagePicker().pickImage(source: ImageSource.camera);
//       if (file != null) {
//         final localFile = File(file.path);
//         if (!localFile.existsSync()) {
//           Messenger.alert(msg: "Selected image is missing.");
//           return;
//         }
//         final mimeType = lookupMimeType(file.path);
//         final isImage = mimeType != null && mimeType.startsWith('image/');
//         final prefs = await SharedPreferences.getInstance();
//         if (isImage) {
//           await prefs.setString('chat_image_path', localFile.path);
//         }

//         ShowAltDialog.showOptionsDialog(context,
//             conversationId: widget.convoId,
//             senderId: currentUserId,
//             receiverId: widget.datumId!,
//             isGroupChat: false,
//             onOptionSelected: _sendMessageImage);

//         final message = {
//           'message_id': 'temp_${DateTime.now().millisecondsSinceEpoch}',
//           'content': '',
//           'sender': {'_id': currentUserId},
//           'receiver': {'_id': widget.receiverId},
//           'messageStatus': 'pending',
//           'time': DateTime.now().toIso8601String(),
//           'localImagePath': file.path,
//           'fileName': file.name,
//           'fileType': mimeType,
//           'imageUrl': file.path,
//           'fileUrl': null,
//         };

//         socketMessages.add(message);
//         _seenMessageIds.add((message['message_id'] ?? "").toString());
//         _updateNotifier();
//         context.read<MessagerBloc>().add(UploadFileEvent(localFile,
//             widget.convoId, currentUserId, widget.datumId ?? "", ""));
//         Navigator.pop(context);
//       }
//     } catch (e) {
//       Messenger.alert(msg: "Could not open camera.");
//     }
//   }

//   // ------------------ Incoming messages ------------------
//   void onMessageReceived(Map<String, dynamic> data) {
//     final event = data['event'];

//     if (event == 'update_message_read') {
//       final messageId =
//           data['data']?['messageId'] ?? data['data']?['message_id'];
//       if (messageId != null) _updateMessageStatus(messageId.toString(), 'read');
//       return;
//     }

//     if (event == 'updated_reaction') {
//       _handleReactionUpdate(data['data']);
//       return;
//     }

//     if (event == 'receive_message' || event == 'forward_message') {
//       final raw = data['data'];
//       if (raw == null) return;

//       // ONE AND ONLY CALL — DO NOT DUPLICATE LOGIC BELOW
//       _handleIncomingRawMessage(raw, event: event);
//       return;
//     }
//     log("⚠️ Unknown socket event: $event");
//   }

//   // ------------------ Reaction handling ------------------
//   void _handleReactionUpdate(dynamic reactionData) {
//     try {
//       MessageReaction? reaction;
//       if (reactionData is Map<String, dynamic>) {
//         reaction = MessageReaction.fromMap(reactionData);
//       } else if (reactionData is List &&
//           reactionData.isNotEmpty &&
//           reactionData.first is Map)
//         reaction = MessageReaction.fromMap(
//             Map<String, dynamic>.from(reactionData.first));
//       if (reaction == null) return;
//       _updateMessageWithReaction(reaction);
//     } catch (e, st) {
//       debugPrint('❌ Reaction update failed: $e\n$st');
//     }
//   }

//   void _replaceLocalForwardIdWithRealId(
//       String realId, Map<String, dynamic> serverMsg) {
//     final serverOriginalId = (serverMsg['original_message_id'] ??
//             serverMsg['originalMessageId'] ??
//             serverMsg['parent_message_id'] ??
//             serverMsg['parentMessageId'] ??
//             '')
//         .toString();

//     final serverContent = (serverMsg['content'] ?? '').toString();

//     bool replaced = false;

//     void tryReplaceIn(List<Map<String, dynamic>> list) {
//       if (replaced) return;

//       for (var i = 0; i < list.length; i++) {
//         final m = list[i];
//         final mid = (m['message_id'] ?? m['messageId'] ?? '').toString();

//         // Only synthetic local ids: temp_... or forward_...
//         final isSynthetic =
//             mid.startsWith('temp_') || mid.startsWith('forward_');
//         if (!isSynthetic) continue;

//         final localOriginalId = (m['original_message_id'] ??
//                 m['originalMessageId'] ??
//                 m['parent_message_id'] ??
//                 m['parentMessageId'] ??
//                 '')
//             .toString();

//         final localContent = (m['content'] ?? '').toString();

//         final sameOriginal = serverOriginalId.isNotEmpty &&
//             localOriginalId.isNotEmpty &&
//             serverOriginalId == localOriginalId;

//         final sameContent =
//             serverContent.isNotEmpty && serverContent == localContent;

//         if (sameOriginal || sameContent) {
//           final copy = Map<String, dynamic>.from(m);
//           copy['message_id'] = realId;
//           copy['messageStatus'] = serverMsg['messageStatus'] ?? 'delivered';
//           copy['isForwarded'] = true;
//           if (serverOriginalId.isNotEmpty) {
//             copy['original_message_id'] = serverOriginalId;
//           }

//           list[i] = copy;
//           replaced = true;
//           log('✅ Replaced synthetic id $mid → real id $realId');
//           break;
//         }
//       }
//     }

//     tryReplaceIn(socketMessages);
//     tryReplaceIn(messages);
//     tryReplaceIn(dbMessages);

//     if (replaced) {
//       _seenMessageIds.add(realId);
//       _updateNotifier();
//       _scheduleSaveMessages();
//     } else {
//       log('ℹ️ _replaceLocalForwardIdWithRealId: no temp_ message matched, keeping serverMsg if needed');
//     }
//   }

//   void _updateMessageWithReaction(MessageReaction reaction) {
//     if (!mounted) return;

//     String normalizeId(dynamic id) => id?.toString().trim() ?? '';

//     final targetId = normalizeId(reaction.messageId);
//     if (targetId.isEmpty) return;

//     bool updated = false;

//     void updateReactions(List<Map<String, dynamic>> list) {
//       for (var msg in list) {
//         // ❗ Only match the actual message id
//         final msgId = normalizeId(
//           msg['message_id'] ?? msg['messageId'] ?? msg['_id'],
//         );

//         if (msgId == targetId) {
//           List<Map<String, dynamic>> oldReactions =
//               List<Map<String, dynamic>>.from(msg['reactions'] ?? []);

//           // remove my old reaction
//           oldReactions.removeWhere((r) =>
//               normalizeId(r['user']?['_id'] ?? r['userId']) ==
//               normalizeId(reaction.user.id));

//           // add new one if not a removal
//           if (!reaction.isRemoval) {
//             oldReactions.add({
//               'emoji': reaction.emoji,
//               'reacted_at': reaction.reactedAt.toIso8601String(),
//               'user': {
//                 '_id': reaction.user.id,
//                 'first_name': reaction.user.firstName,
//                 'last_name': reaction.user.lastName,
//               },
//             });
//           }

//           msg['reactions'] = List<Map<String, dynamic>>.from(oldReactions);
//           updated = true;
//           break; // only this message
//         }
//       }
//     }

//     updateReactions(dbMessages);
//     updateReactions(messages);
//     updateReactions(socketMessages);

//     if (updated) {
//       _updateNotifier();
//       _scheduleSaveMessages();
//     } else {
//       _fetchMessages(); // fallback if something went out of sync
//     }
//   }

//   // ------------------ Status update ------------------
//   void _updateMessageStatus(String messageId, String status) {
//     bool updated = false;
//     void updateInList(List<Map<String, dynamic>> list) {
//       for (var msg in list) {
//         final id = (msg['message_id'] ?? msg['messageId'] ?? '').toString();
//         if (id == messageId) {
//           if (msg['messageStatus'] != status) {
//             msg['messageStatus'] = status;
//             updated = true;
//           }
//           break;
//         }
//       }
//     }

//     updateInList(messages);
//     updateInList(socketMessages);
//     updateInList(dbMessages);

//     // if (!updated) {
//     //   Future.delayed(const Duration(milliseconds: 300), () {
//     //     _updateMessageStatus(messageId, status);
//     //   });
//     // }

//     if (updated) {
//       _updateNotifier();
//       _scheduleSaveMessages();
//     }
//   }

//   String get roomId =>
//       socketService.generateRoomId(currentUserId, widget.datumId!);

//   void _sendReadReceipts(List<String> messageIds) {
//     final unique = messageIds
//         .where((id) => id.trim().isNotEmpty && !_alreadyRead.contains(id))
//         .toSet()
//         .toList();

//     if (unique.isEmpty) return;

//     // Mark them so we DO NOT send again
//     _alreadyRead.addAll(unique);

//     socketService.sendReadReceipts(
//       messageIds: unique,
//       conversationId: widget.convoId,
//       roomId: roomId,
//     );

//     log("📤 Read receipts sent (unique): $unique");
//   }

//   // ------------------ Pagination ------------------
//   Future<void> _fetchMessages() async {
//     _messagerBloc.add(FetchMessagesEvent(convoId: widget.convoId, page: _currentPage, limit: _initialLimit));
//   }

//   void _scrollListener() {
//     if (!_scrollController.hasClients) return;
//     // if near top and has next page, load more
//     if (_scrollController.position.pixels <=
//             _scrollController.position.minScrollExtent + 120 &&
//         _hasNextPage &&
//         !_isLoadingMore) {
//       _loadMoreMessages();
//     }
//   }

//   void _loadMoreMessages() {
//     if (!_hasNextPage || _isLoadingMore) return;
//     setState(() => _isLoadingMore = true);
//     _currentPage++;
//     _prevScrollExtentBeforeLoad = _scrollController.hasClients ? _scrollController.position.maxScrollExtent : 0.0;
//     _messagerBloc.add(FetchMessagesEvent(convoId: widget.convoId, page: _currentPage, limit: _initialLimit));
//   }

//   // ------------------ UI builders ------------------
//   Widget _buildMessageBubble(
//       Map<String, dynamic> message, bool isSentByMe, bool isReply) {
//     return MessageBubble(
//       message: message,
//       isSentByMe: isSentByMe,
//       isSelected: _selectedMessageKeys.contains(_generateMessageKey(message)),
//       onTap: () => _onMessageTap(message),
//       onLongPress: () => _onMessageLongPress(message),

//       onRightSwipe: () => _replyToMessage(message),
//       onFileTap: (url, type) => _openFile(url, type),
//       onImageTap: (url) => ImageViewer.show(context, url),
//       buildStatusIcon: (status) => MessageStatusIcon(status: status ?? 'sent'),
//       // sbuildReactionsBar: (msg, sentByMe) => _buildReactionsBar(msg, sentByMe),
//       sentMessageColor: senderColor,
//       receivedMessageColor: receiverColor,
//       selectedMessageColor: senderColor.withOpacity(0.2),
//       borderColor: Colors.blue,
//       chatColor: chatColor,
//       onReact: (msg, emoji) {
//         setState(() {
//           _handleReactionTap(msg, emoji);
//           _showSearchAppBar = false;
//           _isSelectionMode = false;
//           _selectedMessages.clear();
//           _selectedMessageKeys.clear();
//         });
//       },
//       emojpicker: () => ReactionDialog.show(
//         context: context,
//         messageId: message['message_id']?.toString() ?? '',
//         reactions: message['reactions'] as List<Map<String, dynamic>>? ?? [],
//         currentUserId: currentUserId,
//         convoId: widget.convoId,
//         receiverId: widget.datumId ?? "",
//         firstName: widget.firstname ?? "",
//         lastName: widget.lastname ?? "",
//       ),
//       isReply: isReply,
//     );
//   }

//   Widget _buildReactionsBar(Map<String, dynamic> message, bool isSentByMe) {
//     if (message['reactions'] == null || message['reactions'].isEmpty) {
//       return const SizedBox.shrink();
//     }
//     return ReactionBar(
//         message: message,
//         currentUserId: currentUserId,
//         onReactionTap: _handleReactionTap);
//   }

//   /// Called when user taps a message bubble.
//   /// - If selection mode is active, toggle selection.
//   /// - Otherwise, do nothing (so reply-preview tap works and normal taps don't select).
//   void _onMessageTap(Map<String, dynamic> message) async {
//     print("hiii");
//     if (_isSelectionMode) {
//       _toggleMessageSelection(message);
//       return;
//     }

//     String? extractReplyId(Map<String, dynamic> m) {
//       if (m['reply'] is Map) {
//         final r = Map<String, dynamic>.from(m['reply']);
//         return (r['id'] ??
//                 r['message_id'] ??
//                 r['messageId'] ??
//                 r['reply_message_id'])
//             ?.toString();
//       }
//       if (m['reply_message_id'] != null) {
//         return m['reply_message_id'].toString();
//       }
//       return (m['replyId'] ?? m['reply_to_id'])?.toString();
//     }

//     final replyId = extractReplyId(message);

//     if (replyId != null && replyId.isNotEmpty) {
//       print("reply $replyId");
//       final found = await _scrollToMessageById(replyId, fetchIfMissing: true);
//       if (!found) {
//         Messenger.alert(
//           msg: "Original message not loaded. Scroll up to load older messages.",
//         );
//       }
//     }
//   }

//   void _onMessageLongPress(Map<String, dynamic> message) {
//     // Start selection mode and select this message (your existing logic)
//     final msgId = message['message_id']?.toString();
//     if (msgId == null || msgId.isEmpty) {
//       _toggleMessageSelection(message);
//     } else {
//       if (!_isSelectionMode) {
//         setState(() {
//           _isSelectionMode = true;
//         });
//       }
//       if (!_selectedMessageIds.contains(msgId)) {
//         _selectedMessageIds.add(msgId);
//         _selectedMessageKeys.add(_generateMessageKey(message));
//         _selectedMessages.add(message);
//       }
//     }

//     // Show inline emoji picker (not the bottom sheet)
//     // _showInlineReactionPicker(message);
//   }

//   // overlay for inline emoji picker
//   OverlayEntry? _reactionOverlayEntry;
//   Timer? _reactionOverlayTimer;
//   // bool _suppressReactionDialog = false;
//   final List<String> _quickReactions = ['👍', '❤️', '😂', '😮', '😢', '👏'];

//   /// Show an inline overlay of reaction emojis above center of screen (or you can compute position)
//   void _removeInlineReactionPicker() {
//     try {
//       _reactionOverlayTimer?.cancel();
//       _reactionOverlayTimer = null;
//       _reactionOverlayEntry?.remove();
//       _reactionOverlayEntry = null;
//     } catch (_) {}
//     _suppressReactionDialog = false;
//   }

//   void _showInlineReactionPicker(Map<String, dynamic> message) {
//     // avoid duplicate overlays
//     if (_reactionOverlayEntry != null) return;

//     _suppressReactionDialog = true;

//     final overlay = Overlay.of(context);
//     if (overlay == null) return;

//     _reactionOverlayEntry = OverlayEntry(builder: (context) {
//       final media = MediaQuery.of(context);
//       final bottomPadding = media.viewInsets.bottom;
//       final top = media.size.height - 180 - bottomPadding; // tweak if needed

//       return Positioned(
//         top: top,
//         left: 16,
//         right: 16,
//         child: Material(
//           color: Colors.transparent,
//           child: Center(
//             child: Container(
//               padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(24),
//                 boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 8)],
//               ),
//               child: Row(
//                 mainAxisSize: MainAxisSize.min,
//                 children: _quickReactions.map((emoji) {
//                   return GestureDetector(
//                     onTap: () {
//                       try {
//                         _handleReactionTap(message, emoji);
//                       } catch (e) {
//                         log("Error applying reaction: $e");
//                       } finally {
//                         _removeInlineReactionPicker();
//                       }
//                     },
//                     child: Padding(
//                       padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                       child: Text(emoji, style: const TextStyle(fontSize: 22)),
//                     ),
//                   );
//                 }).toList(),
//               ),
//             ),
//           ),
//         ),
//       );
//     });

//     overlay.insert(_reactionOverlayEntry!);

//     _reactionOverlayTimer?.cancel();
//     _reactionOverlayTimer = Timer(const Duration(seconds: 6), () {
//       _removeInlineReactionPicker();
//     });

//     // small delay before clearing suppression so the immediate long-press flow doesn't open sheet
//     Future.delayed(const Duration(milliseconds: 250), () {
//       _suppressReactionDialog = false;
//     });
//   }

//   /// Strip client-side "forward_" prefix so API always sees a real id
//   String _normalizeMessageIdForApi(String messageId) {
//     if (messageId.isEmpty) return messageId;

//     // for ids like: forward_<realId>_<timestamp>
//     if (messageId.startsWith('forward_')) {
//       final parts = messageId.split('_');
//       if (parts.length >= 3) {
//         return parts[1]; // <realId>
//       }
//     }
//     return messageId;
//   }

//   void _updateLocalReactions(String targetMessageId, String? newEmoji) {
//     bool changed = false;

//     String normalizeId(dynamic id) => id?.toString().trim() ?? '';

//     void updateList(List<Map<String, dynamic>> list) {
//       for (var msg in list) {
//         final msgId = normalizeId(
//           msg['message_id'] ?? msg['messageId'] ?? msg['id'] ?? msg['_id'],
//         );
//         if (msgId != targetMessageId) continue;

//         // make sure we have a mutable list
//         final List<Map<String, dynamic>> reactions =
//             List<Map<String, dynamic>>.from(msg['reactions'] ?? []);

//         // remove my old reaction (if any)
//         reactions.removeWhere((r) {
//           final uid = normalizeId(r['user']?['_id'] ?? r['userId']);
//           return uid == normalizeId(currentUserId);
//         });

//         // if newEmoji != null → add my new reaction
//         if (newEmoji != null && newEmoji.isNotEmpty) {
//           reactions.add({
//             'emoji': newEmoji,
//             'reacted_at': DateTime.now().toIso8601String(),
//             'user': {
//               '_id': currentUserId,
//               'first_name': widget.firstname ?? "",
//               'last_name': widget.lastname ?? "",
//             },
//           });
//         }

//         msg['reactions'] = reactions;
//         changed = true;
//       }
//     }

//     updateList(dbMessages);
//     updateList(messages);
//     updateList(socketMessages);

//     if (changed) {
//       _updateNotifier();
//       _scheduleSaveMessages();
//     }
//   }

//   void _handleReactionTap(Map<String, dynamic> message, String emoji) {
//     try {
//       // 1️⃣ Get whatever id this bubble has (real or synthetic)
//       String rawId = (message['message_id'] ??
//               message['messageId'] ??
//               message['id'] ??
//               message['_id'] ??
//               '')
//           .toString();

//       if (rawId.isEmpty) {
//         log('⚠️ Skipping reaction: message has empty id');
//         return;
//       }

//       // 2️⃣ Convert forward_ id → real id for BACKEND ONLY
//       final apiMessageId = _normalizeMessageIdForApi(rawId);

//       log('🔍 Reacting on bubbleId=$rawId  apiMessageId=$apiMessageId  isForwarded=${message['isForwarded']}');

//       // 3️⃣ Figure out my current reaction on this message
//       final reactions =
//           (message['reactions'] as List?)?.whereType<Map>().toList() ?? [];
//       final myReaction = reactions.firstWhere(
//         (r) => (r['user']?['_id'] ?? r['userId']) == currentUserId,
//         orElse: () => {},
//       );
//       final hasMyReaction = myReaction.isNotEmpty;
//       final oldEmoji = hasMyReaction ? (myReaction['emoji'] as String?) : null;

//       // 4️⃣ Cases: remove / change / add
//       if (hasMyReaction && oldEmoji == emoji) {
//         // 👉 Tap same emoji → remove it

//         // UI: remove locally
//         _updateLocalReactions(rawId, null);

//         // Network: tell backend to remove
//         _messagerBloc.add(RemoveReaction(
//           messageId: apiMessageId,
//           conversationId: widget.convoId,
//           emoji: emoji,
//           userId: currentUserId,
//           receiverId: widget.datumId ?? "",
//           firstName: widget.firstname ?? "",
//           lastName: widget.lastname ?? "",
//         ));
//         return;
//       }

//       if (hasMyReaction && oldEmoji != emoji) {
//         // 👉 Change emoji: remove old one then add new one

//         // UI: apply new emoji
//         _updateLocalReactions(rawId, emoji);

//         // Network: remove old reaction
//         _messagerBloc.add(RemoveReaction(
//           messageId: apiMessageId,
//           conversationId: widget.convoId,
//           emoji: oldEmoji ?? '',
//           userId: currentUserId,
//           receiverId: widget.datumId ?? "",
//           firstName: widget.firstname ?? "",
//           lastName: widget.lastname ?? "",
//         ));

//         // Network: add new one
//         _messagerBloc.add(AddReaction(
//           messageId: apiMessageId,
//           conversationId: widget.convoId,
//           emoji: emoji,
//           userId: currentUserId,
//           receiverId: widget.datumId ?? "",
//           firstName: widget.firstname ?? "",
//           lastName: widget.lastname ?? "",
//         ));
//         return;
//       }

//       // hasMyReaction == false → first time reacting
//       // 👉 Add new emoji

//       // UI: add locally
//       _updateLocalReactions(rawId, emoji);

//       // Network: add reaction
//       _messagerBloc.add(AddReaction(
//         messageId: apiMessageId,
//         conversationId: widget.convoId,
//         emoji: emoji,
//         userId: currentUserId,
//         receiverId: widget.datumId ?? "",
//         firstName: widget.firstname ?? "",
//         lastName: widget.lastname ?? "",
//       ));
//     } catch (e, st) {
//       log('❌ Error handling reaction tap: $e\n$st');
//     }
//   }

//   bool isValidUrl(String url) =>
//       url.startsWith('http://') || url.startsWith('https://');

//   void _openFile(String urlOrPath, String? fileType) async {
//     if (urlOrPath.startsWith('http://') || urlOrPath.startsWith('https://')) {
//       try {
//         await launchUrl(Uri.parse(urlOrPath),
//             mode: LaunchMode.externalApplication);
//       } catch (e) {
//         Messenger.alertError("Could not open file from URL.");
//       }
//     } else {
//       final result = await OpenFile.open(urlOrPath);
//       if (result.type != ResultType.done) {
//         Messenger.alertError("Could not open local file.");
//       }
//     }
//   }

//   // ------------------ Selection / other helpers ------------------
//   void _toggleMessageSelection(Map<String, dynamic> msg) {
//     final key = _generateMessageKey(msg);
//     final String? messageId = msg['message_id']?.toString();

//     setState(() {
//       if (_selectedMessageIds.contains(messageId)) {
//         _selectedMessageIds.remove(messageId);
//         _selectedMessageKeys.remove(key);
//         _selectedMessages.removeWhere((m) => _generateMessageKey(m) == key);
//       } else if (messageId != null) {
//         _selectedMessageIds.add(messageId);
//         _selectedMessageKeys.add(key);
//         _selectedMessages.add(msg);
//       }
//       _isSelectionMode = _selectedMessageIds.isNotEmpty;
//     });
//   }

//   /// Mark messages as deleted locally (UI + local storage).
//   /// This only updates local state — if you want to notify server,
//   /// call your DeleteMessagesEvent separately (see example below).
//   void _markMessagesAsDeleted(List<String> messageIds) {
//     if (messageIds.isEmpty) return;

//     bool changed = false;

//     void markInList(List<Map<String, dynamic>> list) {
//       for (var i = 0; i < list.length; i++) {
//         final msg = list[i];
//         final id = (msg['message_id'] ?? msg['messageId'] ?? '').toString();
//         if (id.isNotEmpty && messageIds.contains(id)) {
//           // Update the message in place
//           msg['content'] = "Message Deleted";
//           msg['imageUrl'] = "";
//           msg['fileUrl'] = "";
//           msg['fileName'] = "";
//           msg['mimeType'] = msg['mimeType'] ?? msg['fileType'] ?? "";
//           msg['messageStatus'] = 'deleted';
//           changed = true;
//         }
//       }
//     }

//     setState(() {
//       markInList(socketMessages);
//       markInList(messages);
//       markInList(dbMessages);
//     });

//     if (changed) {
//       // Update UI notifier & persist changes (these helpers exist in the full screen)
//       try {
//         _updateNotifier();
//       } catch (e) {
//         // if you didn't include _updateNotifier, you can still call setState above to refresh UI
//       }
//       try {
//         _scheduleSaveMessages();
//       } catch (e) {
//         // fallback: immediate save if debounce helper doesn't exist
//         if (widget.convoId.isNotEmpty) {
//           final combined = [...dbMessages, ...messages, ...socketMessages];
//           LocalChatStorage.saveMessages(widget.convoId, combined);
//         }
//       }
//     }
//   }

//   void _forwardSelectedMessages() {
//     MyRouter.pushReplace(
//       screen: ForwardMessageScreen(
//         messages: _selectedMessages.toList(),
//         currentUserId: currentUserId,
//         conversionalid: widget.convoId,
//         username: widget.firstname ?? "",
//       ),
//     );

//     setState(() {
//       _selectedMessages.clear();
//       _selectedMessageKeys.clear();
//       _selectedMessageIds.clear();
//       _isSelectionMode = false;
//     });
//   }

//   void _deleteSelectedMessages() {
//     // nothing to do
//     if (_selectedMessageIds.isEmpty) return;

//     // Mark locally as deleted so UI updates immediately
//     _markMessagesAsDeleted(_selectedMessageIds.toList());

//     // Fire bloc event to delete on server/backend
//     _messagerBloc.add(DeleteMessagesEvent(
//       messageIds: _selectedMessageIds.toList(),
//       convoId: widget.convoId,
//       senderId: currentUserId,
//       receiverId: widget.datumId ?? "",
//       // The `message` field in your DeleteMessagesEvent earlier was using
//       // `_selectedMessageKeys.first` — pass a safe fallback string if empty.
//       message:
//           _selectedMessageKeys.isNotEmpty ? _selectedMessageKeys.first : "",
//     ));

//     // Clear UI selection state
//     setState(() {
//       _selectedMessages.clear();
//       _selectedMessageIds.clear();
//       _selectedMessageKeys.clear();
//       _isSelectionMode = false;
//     });

//     // Optionally re-fetch latest messages after deletion (keeps UI in-sync).
//     // Use post-frame callback so it doesn't interfere with ongoing build.
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       _fetchMessages();
//     });

//     // Persist change to local storage (debounced save if you have one)
//     _scheduleSaveMessages();
//   }

//   void _starSelectedMessages() {
//     // simple UI behavior for now (clear selection)
//     setState(() {
//       _selectedMessages.clear();
//       _selectedMessageKeys.clear();
//       _selectedMessageIds.clear();
//       _isSelectionMode = false;
//     });
//     // optionally dispatch a bloc event to star messages
//   }

//   void _replyToMessage(Map<String, dynamic> message) {
//     if (message.isEmpty) return;
//     setState(() {
//       _replyMessage = message;
//       _focusNode.requestFocus();
//     });
//   }

//   PreferredSizeWidget _buildAppBar() {
//     return CommonAppBarBuilder.build(
//       context: context,
//       showSearchAppBar: _showSearchAppBar,
//       isSelectionMode: _isSelectionMode,
//       selectedMessages: _selectedMessages,
//       toggleSelectionMode: () {
//         setState(() {
//           _isSelectionMode = !_isSelectionMode;
//           if (!_isSelectionMode) {
//             _selectedMessages.clear();
//             _selectedMessageIds.clear();
//             _selectedMessageKeys.clear();
//           }
//         });
//       },
//       deleteSelectedMessages: () {
//         DeleteMessageDialog.show(
//             context: context,
//             onDeleteForEveryone: () {},
//             onDeleteForMe: () => _deleteSelectedMessages());
//       },
//       forwardSelectedMessages: _forwardSelectedMessages,
//       starSelectedMessages: _starSelectedMessages,
//       replyToMessage: _replyToMessage,
//       profileAvatarUrl: widget.profileAvatarUrl,
//       userName: widget.userName,
//       firstname: widget.firstname,
//       lastname: widget.lastname,
//       lastSeen: widget.lastSeen,
//       convertionId: widget.convoId,
//       grpId: widget.datumId ?? "",
//       resvID: widget.datumId ?? "",
//       favouitre: widget.favourite,
//       grpChat: widget.grpChat,
//       onSearchTap: () => toggleSearchAppBar(),
//       onCloseSearch: () => toggleSearchAppBar(),
//     );
//   }

//   void toggleSearchAppBar() =>
//       setState(() => _showSearchAppBar = !_showSearchAppBar);

//   // ------------------ Save and other small helpers ------------------
//   void _saveAllMessages() {
//     if (widget.convoId.isEmpty) return;
//     final combined = [...dbMessages, ...messages, ...socketMessages];
//     LocalChatStorage.saveMessages(widget.convoId, combined);
//   }

//   bool _shouldAddMessage(Map<String, dynamic> msg) {
//     return msg['content']?.toString().trim().isNotEmpty == true ||
//         (msg['imageUrl']?.toString().isNotEmpty == true) ||
//         (msg['fileUrl']?.toString().isNotEmpty == true);
//   }

//   bool _isUnreadMessage(dynamic msg) {
//     if (msg is Map<String, dynamic>) {
//       final senderId =
//           (msg['senderId'] ?? msg['sender']?['_id'] ?? msg['sender']?['id'])
//               ?.toString();
//       return msg['messageStatus'] != 'read' &&
//           senderId != currentUserId &&
//           msg['message_id'] != null;
//     }
//     return false;
//   }

//   List<String> _getUnreadMessageIds(List<dynamic> msgs) {
//     return msgs
//         .where(_isUnreadMessage)
//         .map((m) => m['message_id'].toString())
//         .toList();
//   }

//   Future<void> _loadSessionImagePath() async {
//     final prefs = await SharedPreferences.getInstance();
//     final imagePath = prefs.getString('chat_image_path');
//     if (imagePath != null && imagePath.isNotEmpty) {
//       setState(() => _imageFile = File(imagePath));
//     }
//   }

//   Future<void> _loadSessionFilePath() async {
//     final prefs = await SharedPreferences.getInstance();
//     final filePath = prefs.getString('chat_file_path');
//     if (filePath != null && filePath.isNotEmpty) {
//       setState(() => _fileUrl = File(filePath));
//     }
//   }

//   Future<void> _clearSessionImagePath() async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.remove('chat_image_path');
//   }

//   Future<void> _clearSessionFilePath() async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.remove('chat_file_path');
//   }

//   Future<void> _clearSessionPaths() async {
//     await _clearSessionImagePath();
//     await _clearSessionFilePath();
//   }

//   void _scrollToBottom() {
//     if (_scrollController.hasClients) {
//       WidgetsBinding.instance.addPostFrameCallback((_) {
//         if (!_scrollController.hasClients) return;
//         _scrollController.animateTo(_scrollController.position.maxScrollExtent,
//             duration: const Duration(milliseconds: 200),
//             curve: Curves.easeInOut);
//       });
//     }
//   }

//   // ------------------ Build ------------------
//   @override
//   Widget build(BuildContext context) {
//     return ReusableChatScaffold(
//       appBar: _buildAppBar(),
//       chatBody: ValueListenableBuilder<List<Map<String, dynamic>>>(
//         valueListenable: _messagesNotifier,
//         builder: (context, combinedMessages, child) {
//           return BlocListener<MessagerBloc, MessagerState>(
//             listener: (context, state) {
//               if (state is MessageSentSuccessfully) {
//                 final newMessage = state.sentMessage;

//                 setState(() {
//                   // 1) keep a copy of the optimistic message before removing it
//                   Map<String, dynamic>? optimistic;

//                   try {
//                     optimistic = socketMessages.firstWhere(
//                       (msg) =>
//                           (msg['time'] ?? '') ==
//                               newMessage.time.toIso8601String() ||
//                           (msg['content'] ?? '') == (newMessage.message ?? ''),
//                       orElse: () => {},
//                     );
//                   } catch (_) {
//                     optimistic = {};
//                   }

//                   socketMessages.removeWhere((msg) =>
//                       (msg['time'] ?? '') ==
//                           newMessage.time.toIso8601String() ||
//                       (msg['content'] ?? '') == (newMessage.message ?? ''));

//                   // 2) normalize server message
//                   final normalized = normalizeMessage(newMessage.toJson());

//                   // 3) if server JSON has no reply but optimistic one had, copy it
//                   if (optimistic != null && optimistic!.isNotEmpty) {
//                     if (!_hasReplyForMessage(normalized) &&
//                         _hasReplyForMessage(optimistic!)) {
//                       normalized['isReplyMessage'] = true;
//                       normalized['reply_message_id'] ??=
//                           optimistic!['reply_message_id'];
//                       if (optimistic!['reply'] != null) {
//                         normalized['reply'] = optimistic!['reply'];
//                       }
//                     }
//                   }

//                   messages.add(normalized);

//                   final realId = newMessage.messageId ?? '';
//                   if (realId.isNotEmpty) _seenMessageIds.add(realId);
//                 });

//                 _updateNotifier();
//                 _scheduleSaveMessages();
//                 _scrollToBottom();
//               } else if (state is MessagerLoaded &&
//                   !_hasSentInitialReadReceipts &&
//                   mounted) {
//                 final unreadIds = _getUnreadMessageIds(state.response.data);
//                 if (unreadIds.isNotEmpty && widget.datumId != null) {
//                   _sendReadReceipts(unreadIds);
//                   _hasSentInitialReadReceipts = true;
//                 }
//               }
//               else if (state is MessagerLoaded) {
//                 // pagination from bloc
//                 _hasNextPage = state.response.hasNextPage;
//                 _isLoadingMore = false;

//                 final newDbMessages = state.response.data
//                     .map<Map<String, dynamic>>(normalizeMessage)
//                     .where((m) => m.isNotEmpty)
//                     .toList();
//                 if (_currentPage == 1) {
//                   // ✅ Build a map of existing messages by id
//                   final Map<String, Map<String, dynamic>> byId = {};

//                   for (final old in dbMessages) {
//                     final id = (old['message_id'] ??
//                         old['messageId'] ??
//                         old['id'])
//                         ?.toString() ??
//                         '';
//                     if (id.isEmpty) continue;
//                     byId[id] = old;
//                   }

//                   // ✅ Overlay fresh messages from server
//                   for (final fresh in newDbMessages) {
//                     final id = (fresh['message_id'] ??
//                         fresh['messageId'] ??
//                         fresh['id'])
//                         ?.toString() ??
//                         '';

//                     if (id.isEmpty) {
//                       // messages without ids, just append later
//                       dbMessages.add(fresh);
//                       continue;
//                     }

//                     if (byId.containsKey(id)) {
//                       // keep reply info if local had it
//                       final merged = _mergeReplyInfoIfMissing(fresh, byId[id]!);
//                       byId[id] = merged;
//                     } else {
//                       byId[id] = fresh;
//                     }
//                   }

//                   // ✅ Replace dbMessages with the union (existing + fresh)
//                   dbMessages
//                     ..clear()
//                     ..addAll(byId.values);
//                 } else {
//                   // loading older pages – you can also merge here if needed
//                   dbMessages.insertAll(0, newDbMessages);
//                 }

//                 for (var m in newDbMessages) {
//                   final id = (m['message_id'] ?? '').toString();
//                   if (id.isNotEmpty) _seenMessageIds.add(id);
//                 }

//                 _updateNotifier();
//                 _scheduleSaveMessages();

//                 // restore scroll after adding older messages
//                 WidgetsBinding.instance.addPostFrameCallback((_) {
//                   try {
//                     if (_prevScrollExtentBeforeLoad > 0 &&
//                         _scrollController.hasClients) {
//                       final newMax = _scrollController.position.maxScrollExtent;
//                       final delta = newMax - _prevScrollExtentBeforeLoad;
//                       final newOffset = (_scrollController.offset + delta)
//                           .clamp(
//                               0.0, _scrollController.position.maxScrollExtent);
//                       _scrollController.jumpTo(newOffset);
//                     }
//                   } catch (_) {}
//                   _prevScrollExtentBeforeLoad = 0.0;
//                 });
//               }
//               else if (state is NewMessageReceivedState) {
//                 // here state.message is just the raw socket payload: Map<String, dynamic>
//                 onMessageReceived(state.message);
//               }
//             },
//             // final bool isHighlighted = _highlightedMessageId == messageId;

//             child: ListView.builder(
//               controller: _scrollController,
//               itemCount: combinedMessages.length + (_isLoadingMore ? 1 : 0),
//               itemBuilder: (context, index) {
//                 // If loading more indicator is shown at the top, then index 0 is loader.
//                 if (_isLoadingMore) {
//                   if (index == 0) {
//                     return const Padding(
//                       padding: EdgeInsets.symmetric(vertical: 12),
//                       child: Center(
//                         child: SizedBox(
//                           width: 24,
//                           height: 24,
//                           child: CircularProgressIndicator(strokeWidth: 2),
//                         ),
//                       ),
//                     );
//                   }
//                   // map builder index -> message index in combinedMessages
//                   final msgIndex = index - 1;
//                   final message = combinedMessages[msgIndex];

//                   final senderMap = message['sender'] is Map
//                       ? Map<String, dynamic>.from(message['sender'])
//                       : <String, dynamic>{};

//                   final senderId = (message['senderId'] ??
//                           senderMap['_id'] ??
//                           senderMap['id'] ??
//                           message['sender'])
//                       ?.toString();

//                   final isSentByMe = senderId == currentUserId;

//                   final showDate = msgIndex == 0 ||
//                       !isSameDay(
//                         _parseTime(message['time']),
//                         _parseTime(combinedMessages[msgIndex - 1]['time']),
//                       );

//                   // detect reply presence (support various payload shapes)

//                   final messageId = (message['message_id'] ??
//                           message['messageId'] ??
//                           message['id'] ??
//                           '')
//                       .toString();

// // For stable message ids we keep a single GlobalKey per id (used for ensureVisible)
//                   // final String messageId = (message['message_id'] ?? message['messageId'] ?? message['id'] ?? '').toString();
//                   //
//                   //  Key keyForThisItem;
//                   //
//                   //  if (messageId.isNotEmpty) {
//                   //    keyForThisItem = _messageKeys.putIfAbsent(
//                   //      messageId,
//                   //          () => GlobalKey(debugLabel: 'msg_$messageId'),
//                   //    );
//                   //  } else {
//                   //    keyForThisItem = ValueKey('temp_${message['time']}_$index');
//                   //  }
//                   final hasReply = _hasReplyForMessage(message);

//                   final bool isHighlighted = _highlightedMessageId == messageId;

//                   print("hasreplyyy $hasReply");
//                   return AnimatedContainer(
//                     duration: const Duration(milliseconds: 300),
//                     curve: Curves.easeOut,
//                     margin: const EdgeInsets.symmetric(vertical: 2),
//                     // 💡 WhatsApp-like shading
//                     color: isHighlighted
//                         ? Colors.yellow.withOpacity(0.25)
//                         : Colors.transparent,
//                     // key: keyForThisItem,
//                     child: Column(
//                       crossAxisAlignment: isSentByMe
//                           ? CrossAxisAlignment.end
//                           : CrossAxisAlignment.start,
//                       children: [
//                         if (showDate)
//                           DateSeparator(dateTime: _parseTime(message['time'])),
//                         if (hasReply) _buildReplyPreview(message),
//                         _buildMessageBubble(message, isSentByMe, hasReply),
//                       ],
//                     ),
//                   );
//                 } else {
//                   // Normal (not loading-more) indexing
//                   final msgIndex = index;
//                   final message = combinedMessages[msgIndex];
//                   final senderMap = message['sender'] is Map
//                       ? Map<String, dynamic>.from(message['sender'])
//                       : <String, dynamic>{};
//                   final isSentByMe =
//                       (senderMap['_id'] ?? senderMap['id']) == currentUserId;

//                   final showDate = msgIndex == 0 ||
//                       !isSameDay(
//                         _parseTime(message['time']),
//                         _parseTime(combinedMessages[msgIndex - 1]['time']),
//                       );

//                   final hasReply = _hasReplyForMessage(message);

//                   // assign global key (if message has id, store it for later ensureVisible)
//                   final messageId = (message['message_id'] ??
//                           message['messageId'] ??
//                           message['id'] ??
//                           '')
//                       .toString();
//                   //s  final String messageId = (message['message_id'] ?? message['messageId'] ?? message['id'] ?? '').toString();

//                   // Key keyForThisItem;
//                   //
//                   // if (messageId.isNotEmpty) {
//                   //   keyForThisItem = _messageKeys.putIfAbsent(
//                   //     messageId,
//                   //         () => GlobalKey(debugLabel: 'msg_$messageId'),
//                   //   );
//                   // } else {
//                   //   keyForThisItem = ValueKey('temp_${message['time']}_$index');
//                   // }
//                   final bool isHighlighted = _highlightedMessageId == messageId;
//                   print("hasreplyyy $hasReply");

//                   return AnimatedContainer(
//                     duration: const Duration(milliseconds: 300),
//                     curve: Curves.easeOut,
//                     margin: const EdgeInsets.symmetric(vertical: 2),
//                     // 💡 WhatsApp-like shading
//                     color: isHighlighted
//                         ? Colors.yellow.withOpacity(0.25)
//                         : Colors.transparent,

//                     // key: keyForThisItem,
//                     child: !hasReply
//                         ? _buildMessageBubble(message, isSentByMe, hasReply)
//                         : Column(
//                             crossAxisAlignment: isSentByMe
//                                 ? CrossAxisAlignment.end
//                                 : CrossAxisAlignment.start,
//                             children: [
//                               if (showDate)
//                                 DateSeparator(
//                                     dateTime: _parseTime(message['time'])),
//                               Container(
//                                 margin: const EdgeInsets.symmetric(
//                                     horizontal: 5, vertical: 6),
//                                 padding: const EdgeInsets.all(7),
//                                 constraints:
//                                     const BoxConstraints(maxWidth: 150),
//                                 decoration: BoxDecoration(
//                                   color: (isSentByMe
//                                       ? Color(0xFFD8E1FE)
//                                       : Colors.white),
//                                   borderRadius: BorderRadius.only(
//                                     topLeft: isSentByMe
//                                         ? Radius.zero
//                                         : const Radius.circular(18),
//                                     topRight: isSentByMe
//                                         ? const Radius.circular(18)
//                                         : Radius.zero,
//                                     bottomLeft: isSentByMe
//                                         ? const Radius.circular(18)
//                                         : Radius.zero,
//                                     bottomRight: isSentByMe
//                                         ? Radius.zero
//                                         : const Radius.circular(16),
//                                   ),
//                                   border: null,
//                                   boxShadow: [
//                                     BoxShadow(
//                                       color: Colors.black.withOpacity(0.05),
//                                       blurRadius: 4,
//                                       offset: const Offset(0, 2),
//                                     ),
//                                   ],
//                                 ),
//                                 child: Column(
//                                   children: [
//                                     if (hasReply) _buildReplyPreview(message),
//                                     _buildMessageBubble(
//                                         message, isSentByMe, hasReply),
//                                   ],
//                                 ),
//                               )
//                             ],
//                           ),
//                   );
//                 }
//               },
//             ),
//           );
//         },
//       ),
//       voiceRecordingUI: _buildVoiceRecordingUI(),
//       messageInputBuilder: (isKeyboardVisible) =>
//           _buildMessageInputField(isKeyboardVisible),
//       isRecording: _isRecording,
//       bloc: _messagerBloc,
//     );
//   }

//   Widget _buildVoiceRecordingUI() {
//     return VoiceRecordingWidget(
//       isRecording: _isRecording,
//       isPaused: _isPaused,
//       recordDuration: Duration(seconds: _recordDuration),
//       formatDuration: (duration) => _formatDuration(duration.inSeconds),
//       onStartRecording: recorderHelper.startRecording,
//       onPauseRecording: recorderHelper.pauseRecording,
//       onResumeRecording: recorderHelper.resumeRecording,
//       onStopRecording: recorderHelper.stopRecording,
//       onPlayRecording: recorderHelper.playRecording,
//       onSendRecording: recorderHelper.sendRecording,
//       recordedFilePath: _recordedFilePath,
//       onCancel: () {
//         _timer?.cancel();
//         setState(() {
//           _isRecording = false;
//           _isPaused = false;
//           _recordedFilePath = null;
//         });
//       },
//     );
//   }

//   List<Map<String, dynamic>> _getCombinedMessages() {
//     final combined = <Map<String, dynamic>>[];

//     int idx = 0;

//     void addWithIndex(List<Map<String, dynamic>> source) {
//       for (var m in source) {
//         if (m.isNotEmpty) {
//           final copy = Map<String, dynamic>.from(m);
//           copy['_localIndex'] ??= idx++; // stable order
//           combined.add(copy);
//         }
//       }
//     }

//     // order of insertion: db -> messages -> socket
//     addWithIndex(dbMessages);
//     addWithIndex(messages);
//     addWithIndex(socketMessages);

//     // sort by time, then by local index
//     combined.sort((a, b) {
//       try {
//         final ta = _parseTime(a['time']);
//         final tb = _parseTime(b['time']);
//         final cmp = ta.compareTo(tb);
//         if (cmp != 0) return cmp;

//         final ia = a['_localIndex'] as int? ?? 0;
//         final ib = b['_localIndex'] as int? ?? 0;
//         return ia.compareTo(ib);
//       } catch (_) {
//         return 0;
//       }
//     });

//     // 🔁 DEDUPLICATE BY MESSAGE ID
//     // ✅ Prefer versions that have: reply info OR isForwarded = true
//     final result = <Map<String, dynamic>>[];

//     for (final m in combined) {
//       final id =
//           (m['message_id'] ?? m['messageId'] ?? m['id'])?.toString() ?? '';

//       // optimistic messages without id – always keep
//       if (id.isEmpty) {
//         result.add(m);
//         continue;
//       }

//       final existingIndex = result.indexWhere((e) {
//         final eid =
//             (e['message_id'] ?? e['messageId'] ?? e['id'])?.toString() ?? '';
//         return eid == id;
//       });

//       if (existingIndex == -1) {
//         // first time we see this id
//         result.add(m);
//       } else {
//         final existing = result[existingIndex];

//         final existingHasReply = _hasReplyForMessage(existing);
//         final newHasReply = _hasReplyForMessage(m);

//         final existingIsForwarded = existing['isForwarded'] == true;
//         final newIsForwarded = m['isForwarded'] == true;

//         // 🧠 If the new version has more info (reply OR forwarded), replace the old one
//         if ((!existingHasReply && newHasReply) ||
//             (!existingIsForwarded && newIsForwarded)) {
//           result[existingIndex] = m;
//         }
//       }
//     }

//     return result;
//   }
//   Widget _buildReplyPreview(Map<String, dynamic> message) {
//     final replyMap = (message['reply'] is Map)
//         ? Map<String, dynamic>.from(message['reply'])
//         : <String, dynamic>{};

//     final replyId = (replyMap['id'] ??
//                 replyMap['message_id'] ??
//                 replyMap['messageId'] ??
//                 replyMap['reply_message_id'] ??
//                 message['reply_message_id']) // <--- fallback
//             ?.toString() ??
//         '';

//     final replyContent = (replyMap['replyContent'] ??
//             replyMap['content'] ??
//             replyMap['message'] ??
//             '')
//         .toString();

//     if (replyId.isEmpty && replyContent.isEmpty) {
//       return const SizedBox.shrink();
//     }

//     return GestureDetector(
//       onTap: () async {
//         if (replyId.isNotEmpty) {
//           final found =
//               await _scrollToMessageById(replyId, fetchIfMissing: true);
//           if (!found) {
//             Messenger.alert(
//               msg:
//                   "Original message not loaded. Scroll up to load older messages.",
//             );
//           }
//         }
//       },
//       child: Container(
//         margin: const EdgeInsets.only(bottom: 6),
//         padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
//         decoration: BoxDecoration(
//           color: Colors.grey.shade200,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: Row(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Container(
//               width: 3,
//               height: 32,
//               decoration: BoxDecoration(
//                 color: Colors.grey.shade500,
//                 borderRadius: BorderRadius.circular(4),
//               ),
//             ),
//             const SizedBox(width: 6),
//             Flexible(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   if (replyContent.isNotEmpty)
//                     Text(
//                       replyContent,
//                       maxLines: 2,
//                       overflow: TextOverflow.ellipsis,
//                       style: const TextStyle(
//                         fontSize: 11,
//                         color: Colors.black87,
//                       ),
//                     ),
//                   const SizedBox(height: 2),
//                   Text(
//                     'Tap to view original',
//                     style: TextStyle(
//                       fontSize: 10,
//                       color: Colors.grey.shade600,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildMessageInputField(bool isKeyboardVisible) {
//     return MessageInputField(
//       messageController: _messageController,
//       reciverID: widget.datumId ?? "",
//       focusNode: _focusNode,
//       onSendPressed: _sendMessage,
//       onEmojiPressed: () {
//         setState(() {});
//       },
//       onAttachmentPressed: () => ShowAltDialog.showOptionsDialog(context,
//           conversationId: widget.convoId,
//           senderId: currentUserId,
//           receiverId: widget.datumId!,
//           isGroupChat: false,
//           onOptionSelected: _sendMessageImage),
//       onCameraPressed: _openCamera,
//       onRecordPressed: _isRecording
//           ? recorderHelper.stopRecording
//           : recorderHelper.startRecording,
//       isRecording: _isRecording,
//       replyText: _replyMessage,
//       onCancelReply: () {
//         recorderHelper.cancelReply();
//         _replyMessage = null;
//         _messageController.clear();
//         setState(() {});
//       },
//     );
//   }

//   String _formatDuration(int seconds) {
//     final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
//     final secs = (seconds % 60).toString().padLeft(2, '0');
//     return '$minutes:$secs';
//   }
// }

import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/message_handler.dart';
import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/widget/audio_reuable.dart';
import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/widget/date_separate.dart';
import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/widget/double_tick_ui.dart';
import 'package:nde_email/presantation/chat/widget/delete_dialogue.dart';
import 'package:nde_email/presantation/chat/widget/image_viewer.dart';
import 'package:nde_email/presantation/chat/widget/reation_bottom.dart';
import 'package:nde_email/utils/imports/common_imports.dart';
import 'package:nde_email/utils/reusbale/common_import.dart';

import '../../widgets/chat_widgets/messager_Wifgets/ForwardMessageScreen_widget.dart';
import '../../widgets/chat_widgets/messager_Wifgets/buildMessageInputField_widgets.dart';
import '../../widgets/chat_widgets/messager_Wifgets/show_Bottom_Sheet.dart';
import 'messager_Bloc/MessagerEvent.dart';
import 'messager_Bloc/MessagerState.dart';

class PrivateChatScreen extends StatefulWidget {
  final String convoId;
  final String profileAvatarUrl;
  final String userName;
  final String lastSeen;
  final String? receiverId;
  final String? datumId;
  final String? firstname;
  final String? lastname;
  final bool grpChat;
  final bool favourite;

  const PrivateChatScreen(
      {super.key,
      required this.convoId,
      required this.profileAvatarUrl,
      required this.userName,
      required this.lastSeen,
      this.receiverId,
      required this.datumId,
      this.firstname,
      this.lastname,
      required this.grpChat,
      required this.favourite});

  @override
  _PrivateChatScreenState createState() => _PrivateChatScreenState();
}

class _PrivateChatScreenState extends State<PrivateChatScreen> {
  // Controllers and Focus
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _focusNode = FocusNode();

  // Services
  final SocketService socketService = SocketService();

  late MessagerBloc _messagerBloc;
  late MessageHandler _messageHandler;

  // State variables
  final ValueNotifier<bool> isLongPressed = ValueNotifier<bool>(false);
  List<Map<String, dynamic>> socketMessages = [];
  List<Map<String, dynamic>> dbMessages = [];
  List<Map<String, dynamic>> messages = [];
  String currentUserId = '';
  bool _showSearchAppBar = false;
  bool _isRecording = false;
  bool _isPaused = false;
  int _recordDuration = 0;
  Timer? _timer;
  String? _recordedFilePath;
  // Pagination
  int _currentPage = 1;
  final int _limit = 20;
  bool _isLoadingMore = false;
  bool _hasNextPage = false;
  final Set<String> _selectedMessageIds = {};

  // Media handling
  File? _imageFile;

  final AudioRecorder _audioRecorder = AudioRecorder();
  bool _showEmoji = false;

  // Message selection
  bool _isSelectionMode = false;
  final List<dynamic> _selectedMessages = [];

  @override
  void initState() {
    super.initState();
    _messagerBloc = context.read<MessagerBloc>();
    _messageHandler = MessageHandler(
      currentUserId: currentUserId,
      convoId: widget.convoId,
    );
    _initializeChat();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _focusNode.dispose();
    _scrollController.removeListener(_scrollListener);
    _scrollController.dispose();
    _reactionSubscription?.cancel();

    _clearSessionImagePath();
    // SocketService().disconnect();
    if (widget.convoId.isEmpty) {
      socketMessages.clear();
      messages.clear();
    }

    super.dispose();
  }

  Future<void> _initializeChat() async {
    print("Initializing chat for convoId: ${widget.convoId}");
    // dbMessages = [
    //   for (var msg in LocalChatStorage.loadMessages(widget.convoId))
    //     if (msg.isNotEmpty) normalizeMessage(msg)
    // ];
    if (widget.convoId.isNotEmpty) {
      dbMessages = [
        for (var msg in LocalChatStorage.loadMessages(widget.convoId))
          if (msg.isNotEmpty) normalizeMessage(msg)
      ];
    } else {
      dbMessages = [];
    }

    _messagerBloc = MessagerBloc(
      apiService: MessagerApiService(),
      socketService: socketService,
    );

    await Future.wait([
      _initializeSocket(),
      _loadCurrentUserId(),
    ]);
    if (widget.convoId.isNotEmpty) {
      _fetchMessages();
    }

    _scrollController.addListener(_scrollListener);
  }

  StreamSubscription<MessageReaction>? _reactionSubscription;

  void _setupReactionListener() {
    _reactionSubscription = socketService.reactionStream.listen((reaction) {
      _updateMessageWithReaction(reaction);
    });
  }

  void _updateMessageWithReaction(MessageReaction reaction) {
    if (!mounted) return;

    String normalizeId(dynamic id) => id?.toString().trim() ?? '';

    bool updated = false;

    void updateReactions(List<Map<String, dynamic>> messageList) {
      for (var msg in messageList) {
        final msgId = normalizeId(
            msg['message_id'] ?? msg['messageId'] ?? msg['id'] ?? msg['_id']);

        if (msgId == normalizeId(reaction.messageId)) {
          List<Map<String, dynamic>> oldReactions =
              List<Map<String, dynamic>>.from(msg['reactions'] ?? []);

          // Remove old reaction by same user (ignore emoji match)
          oldReactions.removeWhere((r) =>
              normalizeId(r['user']?['_id']) == normalizeId(reaction.user.id));

          // Add new reaction if not a removal
          if (!reaction.isRemoval) {
            oldReactions.add({
              'emoji': reaction.emoji,
              'reacted_at': reaction.reactedAt.toIso8601String(),
              'user': {
                '_id': reaction.user.id,
                'first_name': reaction.user.firstName,
                'last_name': reaction.user.lastName,
              },
            });
          }

          // Assign new list reference for UI rebuild
          msg['reactions'] = List<Map<String, dynamic>>.from(oldReactions);
          updated = true;
          break;
        }
      }
    }

    updateReactions(dbMessages);
    updateReactions(messages);
    updateReactions(socketMessages);

    if (updated) {
      setState(() {});
      final combined = [...dbMessages, ...messages, ...socketMessages];
      LocalChatStorage.saveMessages(widget.convoId, combined);
    }
  }

  void _updateMessageStatus(String messageId, String status) {
    bool updated = false;

    void updateInList(List<Map<String, dynamic>> list) {
      for (var msg in list) {
        final id = msg['message_id'] ?? msg['messageId'];

        if (id == messageId) {
          if (msg['messageStatus'] != status) {
            msg['messageStatus'] = status;
            updated = true;
            debugPrint('✅ Updated message $messageId to status: $status');
          } else {
            //   debugPrint('ℹ️ Already has status: $status');
          }
          break;
        }
      }
    }

    updateInList(messages);
    updateInList(socketMessages);
    updateInList(dbMessages);

    if (!updated) {
      // Retry after a short delay
      Future.delayed(Duration(milliseconds: 300), () {
        _updateMessageStatus(messageId, status);
      });
    }

    if (updated && mounted) {
      setState(() {});
      final combined = [...dbMessages, ...messages, ...socketMessages];
      LocalChatStorage.saveMessages(widget.convoId, combined);
    }
  }

  final Set<String> _alreadyRead = {};

  String get roomId =>
      socketService.generateRoomId(currentUserId, widget.datumId!);

  void _sendReadReceipts(List<String> messageIds) {
    final unique = messageIds
        .where((id) => id.trim().isNotEmpty && !_alreadyRead.contains(id))
        .toSet()
        .toList();

    if (unique.isEmpty) return;

    // Mark them so we DO NOT send again
    _alreadyRead.addAll(unique);

    socketService.sendReadReceipts(
      messageIds: unique,
      conversationId: widget.convoId,
      roomId: roomId,
    );

    log("📤 Read receipts sent (unique): $unique");
  }

  String _userOnlineStatus = "";

  final Set<String> _unreadMessageIds = {};
  bool _hasSentInitialReadReceipts = false;

  Future<void> _initializeSocket() async {
    final token = await UserPreferences.getAccessToken();
    if (token == null) {
      log("Access token is null. Socket connection not initialized.");
    }
  }

  Map<String, dynamic> normalizeMessage(dynamic rawMsg) {
    return _messageHandler.normalizeMessage(rawMsg);
  }

  // Update time parsing calls
  DateTime _parseTime(dynamic time) {
    return _messageHandler.parseTime(time);
  }

  // Update message key generation
  String _generateMessageKey(Map<String, dynamic> msg) {
    return _messageHandler.generateMessageKey(msg);
  }

  // Update date comparison
  bool isSameDay(DateTime? date1, DateTime? date2) {
    return _messageHandler.isSameDay(date1, date2);
  }

  Future<void> _loadCurrentUserId() async {
    currentUserId = await UserPreferences.getUserId() ?? '';
    if (currentUserId.isEmpty || widget.datumId!.isEmpty) return;

    SocketService().connectPrivateRoom(
      currentUserId,
      widget.datumId!,
      onMessageReceived,
      false,
    );

    _setupMessageListener();
    setState(() {});
  }

  void _setupMessageListener() {
    if (currentUserId.isEmpty || widget.datumId == null) return;

    _messagerBloc.add(ListenToMessages(
      senderId: currentUserId,
      receiverId: widget.datumId!,
    ));

    // Listen to incoming messages
    socketService.listenToMessages(
      currentUserId,
      widget.datumId!,
      (data) {
        if (!mounted || data.isEmpty) return;

        final content = data['content']?.toString().trim() ?? '';
        if (content.isEmpty) return;

        setState(() {
          final exists = messages.any((msg) =>
              msg['time'] == data['time'] && msg['content'] == data['content']);

          if (!exists) {
            messages.add(Map<String, dynamic>.from(data));
          }

          LocalChatStorage.saveMessages(
            widget.convoId,
            [...dbMessages, ...messages, ...socketMessages],
          );
        });
      },
    );

    // Listen to status updates
    socketService.statusUpdateStream.listen((statusUpdate) {
      if (!mounted) return;

      final status = statusUpdate['messageStatus'] ?? 'read';

      // FIX: Support list and single formats
      final ids = statusUpdate['messageIds'] ?? statusUpdate['messageId'];

      debugPrint('📥 Status update received: $statusUpdate');

      if (ids is List) {
        for (final id in ids.whereType<String>()) {
          debugPrint('🔄 Updating status for messageId: $id -> $status');
          _updateMessageStatus(id, status);
        }
      } else if (ids is String) {
        debugPrint('🔄 Updating status for single messageId: $ids -> $status');
        _updateMessageStatus(ids, status);
      } else {
        debugPrint('⚠️ Invalid messageId format: $ids');
      }
    });

    _setupReactionListener();
    _setupOnlineStatusListener();
  }

  File? _fileUrl;

  void _setupOnlineStatusListener() {
    socketService.userStatusStream.listen((data) {
      if (!mounted) return;

      final userId = data['userId']?.toString() ?? data['_id']?.toString();

      if (userId == widget.datumId) {
        final status = data['status'];
        setState(() {
          _userOnlineStatus = status == 'online' ? 'Online' : 'Offline';
        });
      }
    });
  }

  Future<void> _loadSessionImagePath() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('chat_image_path');

    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _imageFile = File(imagePath);
        log(" -----image-- $_imageFile");
      });
    }
  }

  Future<void> _clearSessionPaths() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('chat_image_path');
    await prefs.remove('chat_file_path');
  }

  Future<void> _loadSessionFilePath() async {
    final prefs = await SharedPreferences.getInstance();
    final filePath = prefs.getString('chat_file_path');

    if (filePath != null && filePath.isNotEmpty) {
      setState(() {
        _fileUrl = File(filePath);
        log(" ------- $_fileUrl");
      });
    }
  }

  void _sendMessage() async {
    if (_messageController.text.trim().isEmpty || widget.datumId == null)
      return;

    final reply = _replyMessage;
    final messageText = _messageController.text.trim();

    // Completer to wait for Bloc response
    final completer = Completer<Message>();

    // Listen once for Bloc success state
    final subscription = _messagerBloc.stream.listen((state) {
      if (state is MessageSentSuccessfully) {
        completer.complete(state.sentMessage);
      }
    });

    // Dispatch event to Bloc
    _messagerBloc.add(
      SendMessageEvent(
        convoId: widget.convoId,
        message: messageText,
        senderId: currentUserId,
        receiverId: widget.datumId!,
        replyTo: reply,
      ),
    );

    // Await the sent message from Bloc
    final sentMessage = await completer.future;
    await subscription.cancel();

    // Prepare message for UI list
    final messageMap = {
      'message_id': sentMessage.messageId,
      'content': sentMessage.message,
      'sender': {'_id': sentMessage.senderId},
      'receiver': {'_id': sentMessage.receiverId},
      'messageStatus': sentMessage.messageStatus,
      'time': sentMessage.time.toIso8601String(),
      'isReplyMessage': reply != null,
      if (reply != null) 'replyTo': reply,
    };

    setState(() {
      socketMessages.add(messageMap);
      _scrollToBottom();

      final combined = [...dbMessages, ...messages, ...socketMessages];
      LocalChatStorage.saveMessages(widget.convoId, combined);
    });

    // Clear input
    _messageController.clear();
    _replyMessage = null;
    _imageFile = null;
  }

  void _sendMessageImage() async {
    await _loadSessionImagePath();
    await _loadSessionFilePath();

    log("Sending message with image and file");
    final nowIso = DateTime.now().toIso8601String();
    final String? mimeType =
        _fileUrl != null ? lookupMimeType(_fileUrl!.path) : null;

    final message = {
      'content': _messageController.text.trim(),
      'sender': {'_id': currentUserId},
      'receiver': {'_id': widget.datumId},
      'messageStatus': 'delivered',
      'time': nowIso,
      'fileName': _fileUrl?.path.split('/').last,
      'fileType': mimeType,
      'imageUrl': _imageFile?.path,
      'fileUrl': _fileUrl?.path,
    };

    log(message.toString());

    setState(() {
      socketMessages.add(message);
      _scrollToBottom();
      // Save combined messages after sending image message
      final combined = [...dbMessages, ...messages, ...socketMessages];
      LocalChatStorage.saveMessages(widget.convoId, combined);
    });
    setState(() {
      _messageController.clear();
      _imageFile = null;
      _fileUrl = null;
    });

    await _clearSessionPaths();
  }

  Future<void> _openCamera() async {
    try {
      final XFile? file =
          await ImagePicker().pickImage(source: ImageSource.camera);

      if (file != null) {
        final File localFile = File(file.path);

        if (!localFile.existsSync()) {
          log("  File does not exist at: ${file.path}");
          Messenger.alert(msg: "Selected image is missing.");

          return;
        }

        final mimeType = lookupMimeType(file.path);
        final isImage = mimeType != null && mimeType.startsWith('image/');
        log("📄 MIME Type: $mimeType");
        log("🖼️ Is Image: $isImage");

        final prefs = await SharedPreferences.getInstance();

        // Save only image path to session
        if (isImage) {
          await prefs.setString('chat_image_path', localFile.path);
          log(" Image path saved: ${localFile.path}");
        }

        ShowAltDialog.showOptionsDialog(context,
            conversationId: widget.convoId,
            senderId: currentUserId,
            receiverId: widget.datumId!,
            isGroupChat: false,
            onOptionSelected: _sendMessageImage);

        final message = {
          'content': '',
          'sender': {'_id': currentUserId},
          'receiver': {'_id': widget.receiverId},
          'messageStatus': 'pending',
          'time': DateTime.now().toIso8601String(),
          'localImagePath': file.path,
          'fileName': file.name,
          'fileType': mimeType,
          'imageUrl': file.path,
          'fileUrl': null,
        };

        log("🟢 Local message metadata: $message");

        setState(() {
          socketMessages.add(message);
        });

        // Upload via BLoC
        context.read<MessagerBloc>().add(
              UploadFileEvent(
                localFile,
                widget.convoId,
                currentUserId,
                widget.datumId ?? "",
                "",
              ),
            );

        Navigator.pop(context);
      }
    } catch (e) {
      log('  Error opening camera: $e');
      Messenger.alert(msg: "Could not open camera.");
    }
  }

  void _appendMessage(Map<String, dynamic> message) {
    setState(() {
      messages.add(message);
      _scrollToBottom();
    });
  }

  void _toggleSelectionMode() {
    setState(() {
      _isSelectionMode = false;
      _selectedMessages.clear();
      _selectedMessageKeys.clear();
    });
  }

  final Set<String> _selectedMessageKeys = {};
  void _markMessagesAsDeleted(List<String> messageIds) {
    if (messageIds.isEmpty) return;

    setState(() {
      void updateMessages(List<Map<String, dynamic>> list) {
        if (list.isEmpty) return;

        // Build a lookup map for faster access
        final idToIndex = {
          for (var i = 0; i < list.length; i++)
            if (list[i]['message_id'] is String)
              list[i]['message_id'] as String: i
        };

        for (final id in messageIds) {
          final index = idToIndex[id];
          if (index != null) {
            final msg = list[index];
            msg['content'] = "Message Deleted";

            msg['imageUrl'] = "";
            msg['fileUrl'] = "";
          }
        }
      }

      updateMessages(messages);
      updateMessages(dbMessages);
      updateMessages(socketMessages);
    });
  }

  void _deleteSelectedMessages() {
    if (_selectedMessageIds.isEmpty) {
      log("❌ No messages selected. Skipping delete.");
      return;
    }

    log("🔴 _deleteSelectedMessages() called");
    log("🟡 Selected Message IDs: $_selectedMessageIds");
    log("🟡 Selected Message Keys: $_selectedMessageKeys");

    // Mark as deleted locally
    _markMessagesAsDeleted(_selectedMessageIds.toList());

    // Trigger deletion in BLoC
    log("🟢 Triggering DeleteMessagesEvent...");
    _messagerBloc.add(DeleteMessagesEvent(
      messageIds: List<String>.from(_selectedMessageIds),
      convoId: widget.convoId,
      senderId: currentUserId,
      receiverId: widget.receiverId ?? "",
      message: _selectedMessageKeys.first,
    ));

    setState(() {
      _selectedMessages.clear();
      _selectedMessageIds.clear();
      _selectedMessageKeys.clear();
      _isSelectionMode = false;
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => _fetchMessages());
  }

  void _toggleMessageSelection(Map<String, dynamic> msg) {
    final key = _generateMessageKey(msg);
    final String? messageId = msg['message_id']?.toString();

    setState(() {
      if (_selectedMessageIds.contains(messageId)) {
        _selectedMessageIds.remove(messageId);
        _selectedMessageKeys.remove(key);
        _selectedMessages.removeWhere((m) => _generateMessageKey(m) == key);
      } else if (messageId != null) {
        _selectedMessageIds.add(messageId);
        _selectedMessageKeys.add(key);
        _selectedMessages.add(msg);
      }
      _isSelectionMode = _selectedMessageIds.isNotEmpty;
    });
  }

  void _forwardSelectedMessages() {
    MyRouter.push(
      screen: ForwardMessageScreen(
        messages: _selectedMessages.toList(),
        currentUserId: currentUserId,
        conversionalid: "",
        username: widget.firstname ?? "",
      ),
    );

    setState(() {
      _selectedMessages.clear();
      _selectedMessageKeys.clear();
      _selectedMessageIds.clear();
      _isSelectionMode = false;
    });
  }

  void _starSelectedMessages() {
    // _messagerBloc.add(StarMessagesEvent(
    //   messageIds:
    //       _selectedMessages.map((m) => m['message_id'] as String).toList(),
    //   convoId: widget.convoId,
    // ));

    setState(() {
      _selectedMessages.clear();
      _isSelectionMode = false;
    });
  }

  Map<String, dynamic>? _replyMessage;

  void _replyToMessage(Map<String, dynamic> message) {
    if (message.isEmpty) return;
    setState(() {
      log("hiiiiiii");
      _replyMessage = message;
      _focusNode.requestFocus();
    });
  }

  void _toggleEmojiKeyboard() {
    setState(() {
      _showEmoji = !_showEmoji;
    });

    if (_showEmoji) {
      _focusNode.unfocus();
    } else {
      _focusNode.requestFocus();
    }
  }

  void toggleSearchAppBar() {
    setState(() {
      _showSearchAppBar = !_showSearchAppBar;
    });
  }

  final bool _isTyping = false;

  bool _initialScrollDone = false;

  void onMessageReceived(Map<String, dynamic> data) {
    if (data['event'] == 'update_message_read') {
      log("calinggggggggg.._updateMessageStatus.....1.");
      final messageId =
          data['data']?['messageId'] ?? data['data']?['message_id'];
      if (messageId != null) {
        log("calinggggggggg.._updateMessageStatus....22 emoj.");
        _updateMessageStatus(messageId, 'read');
      }
      return;
    } else if (data['event'] == 'updated_reaction') {
      _handleReactionUpdate(data['data']);
      return;
    }

    // Original message processing
    final messageData = data['data'];
    if (messageData == null) return;

    final content = messageData['content']?.toString().trim() ?? '';
    final imageUrl = messageData['thumbnailUrl'] ?? messageData['originalUrl'];
    final fileUrl = messageData['originalUrl'] ?? messageData['fileUrl'];
    final fileName = messageData['fileName'];

    if (content.isEmpty && imageUrl == null && fileUrl == null) return;

    final messageId = messageData['message_id'] ?? messageData['id'];
    if (messageId != null) {
      _unreadMessageIds.add(messageId);
    }
    final newMessage = {
      'message_id': messageId,
      'content': content,
      'sender': messageData['sender'],
      'receiver': messageData['receiver'],
      'messageStatus': messageData['messageStatus'] ?? 'delivered',
      'time': messageData['time'],
      'imageUrl': imageUrl,
      'fileName': fileName,
      'fileUrl': fileUrl,
      'fileType': messageData['mimeType'] ?? messageData['fileType'],
    };

    if (mounted) {
      setState(() {
        final exists = messages.any((msg) =>
            msg['time'] == newMessage['time'] &&
            msg['message_id'] == newMessage['message_id']);

        if (!exists) {
          socketMessages.add(newMessage);
          _scrollToBottom();
          // Send read receipt immediately for new messages
          if (newMessage['message_id'] != null) {
            _sendReadReceipts([newMessage['message_id'].toString()]);
          }
        }

      
        if (widget.convoId.isNotEmpty) {
          final combined = [...dbMessages, ...messages, ...socketMessages];
          LocalChatStorage.saveMessages(widget.convoId, combined);
        }
      });
    }
  }

  void _handleReactionUpdate(dynamic reactionData) {
    try {
      MessageReaction? reaction;

      if (reactionData is Map<String, dynamic>) {
        reaction = MessageReaction.fromMap(reactionData);
      } else if (reactionData is List && reactionData.isNotEmpty) {
        final first = reactionData.first;
        if (first is Map<String, dynamic>) {
          reaction = MessageReaction.fromMap(first);
        }
      }

      if (reaction == null) return;

      _updateMessageWithReaction(reaction);

      if (mounted) {
        setState(() {});
      }
    } catch (e, stackTrace) {
      debugPrint('❌ Reaction update failed: $e\n$stackTrace');
    }
  }

  Future<void> _clearSessionImagePath() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('chat_image_path');
    await prefs.remove('chat_file_path');
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: Duration(milliseconds: 200),
          curve: Curves.easeInOut,
        );
      });
    }
  }

  // Pagination methods
  Future<void> _fetchMessages() async {
    _messagerBloc.add(
      FetchMessagesEvent(
        convoId: widget.convoId,
        page: _currentPage,
        limit: _limit,
      ),
    );
  }

  void _scrollListener() {
    if (_scrollController.position.pixels <=
            _scrollController.position.minScrollExtent + 100 &&
        _hasNextPage &&
        !_isLoadingMore) {
      _loadMoreMessages();
    }
  }

  // void _loadMoreMessages() {
  //   if (_hasNextPage && !_isLoadingMore) {
  //     setState(() => _isLoadingMore = true);
  //     _currentPage++;
  //     _messagerBloc.add(FetchMessagesEvent(
  //       convoId: widget.convoId,
  //       page: _currentPage,
  //       limit: _limit,
  //     ));
  //   }
  // }
  void _loadMoreMessages() {
    if (_hasNextPage && !_isLoadingMore) {
      setState(() => _isLoadingMore = true);
      _currentPage++;
      _messagerBloc.add(FetchMessagesEvent(
        convoId: widget.convoId,
        page: _currentPage,
        limit: _limit,
      ));
    }
  }

  Widget _buildChatBody() {
    return BlocListener<MessagerBloc, MessagerState>(
      listener: (context, state) {
        if (state is MessageSentSuccessfully) {
          final newMessage = state.sentMessage;
          setState(() {
            socketMessages.removeWhere((msg) =>
                msg['content'] == newMessage.message &&
                msg['time'] == newMessage.time);

            messages.add(newMessage.toJson());

            // Merge & Save
            _saveAllMessages();
          });
          _scrollToBottom();
        } else if (state is MessagerError) {
        } else if (state is MessagerLoaded &&
            !_hasSentInitialReadReceipts &&
            mounted) {
          final unreadIds = _getUnreadMessageIds(state.response.data);
          if (unreadIds.isNotEmpty && widget.datumId != null) {
            _sendReadReceipts(unreadIds);
            _hasSentInitialReadReceipts = true;
          }
        }
      },
      child: BlocBuilder<MessagerBloc, MessagerState>(
        builder: (context, state) {
          if (state is MessagerLoading &&
              _currentPage == 1 &&
              messages.isEmpty &&
              socketMessages.isEmpty) {
            return ListView.builder(
              itemCount: 10,
              itemBuilder: (context, index) {
                return ShimmerMessageBubble(isSentByMe: index % 3 == 0);
              },
            );
          }

          if (state is MessagerError &&
              messages.isEmpty &&
              socketMessages.isEmpty) {
            return Center(child: Text('Error: ${state.message}'));
          }

          if (state is MessagerLoaded) {
            _hasNextPage = state.response.hasNextPage;
            _isLoadingMore = false;
            _hasNextPage = state.response.hasNextPage;
            _isLoadingMore = false;

            final allMessages =
                state.response.data.expand((group) => group.messages).toList();

            final newDbMessages = allMessages
                .map<Map<String, dynamic>>(normalizeMessage)
                .where((m) => m.isNotEmpty)
                .toList();

            /// 🔥 1. Flatten group.messages into a single list of Datum
            // final allMessages =
            //     state.response.data.expand((group) => group.messages).toList();

            // /// 🔥 2. Convert Datum → Map via normalizeMessage
            // final newDbMessages = allMessages
            //     .map<Map<String, dynamic>>(normalizeMessage)
            //     .where((m) => m.isNotEmpty)
            //     .toList();

            // /// 🔥 3. Merge existing statuses
            // for (var fetched in newDbMessages) {
            //   final id = fetched['message_id']?.toString();
            //   final existing = dbMessages.firstWhere(
            //     (m) => m['message_id']?.toString() == id,
            //     orElse: () => {},
            //   );

            //   if (existing.isNotEmpty && existing['messageStatus'] == 'read') {
            //     fetched['messageStatus'] = 'read';
            //   }
            // }

            /// 🔥 4. Save to db + assign in memory
            dbMessages = newDbMessages;
            LocalChatStorage.saveMessages(widget.convoId, dbMessages);
          }

          // if (state is MessagerLoaded) {
          //   _hasNextPage = state.response.hasNextPage;
          //   _isLoadingMore = false;

          //   final newDbMessages = (state.response.data)
          //       .map<Map<String, dynamic>>(normalizeMessage)
          //       .where((m) => m.isNotEmpty)
          //       .toList();

          //   // if (dbMessages.length != newDbMessages.length ||
          //   //     (dbMessages.isNotEmpty &&
          //   //         dbMessages.last['time'] != newDbMessages.last['time'])) {
          //   //   dbMessages = newDbMessages;
          //   //   if (widget.convoId.isNotEmpty) {
          //   //     LocalChatStorage.saveMessages(widget.convoId, dbMessages);
          //   //   } else {
          //   //     LocalChatStorage.saveMessages(widget.convoId, []);
          //   //   }
          //   // }

          //   // Merge DB fetched with existing local statuses
          //   for (var fetched in newDbMessages) {
          //     final id = fetched['message_id']?.toString();
          //     final existing = dbMessages.firstWhere(
          //       (m) => m['message_id']?.toString() == id,
          //       orElse: () => {},
          //     );

          //     if (existing.isNotEmpty && existing['messageStatus'] == 'read') {
          //       fetched['messageStatus'] = 'read';
          //     }
          //   }
          //   dbMessages = newDbMessages;
          //   LocalChatStorage.saveMessages(widget.convoId, dbMessages);
          // }

          // Merge messages in one pass
          final combinedMessages = <Map<String, dynamic>>[];
          final unreadMessageIds = <String>[];

          void addMessages(List<Map<String, dynamic>> source) {
            for (var m in source) {
              if (_shouldAddMessage(m)) {
                combinedMessages.add(m);
                if (_isUnreadMessage(m)) {
                  unreadMessageIds.add(m['message_id'].toString());
                }
              }
            }
          }

          addMessages(dbMessages);
          addMessages(messages);
          addMessages(socketMessages);

          // Sort once
          combinedMessages.sort(
              (a, b) => _parseTime(a['time']).compareTo(_parseTime(b['time'])));

          // Send read receipts after build
          if (unreadMessageIds.isNotEmpty &&
              widget.datumId != null &&
              mounted) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _sendReadReceipts(
                unreadMessageIds,
              );
            });
          }

          // Save combined messages only if changed
          LocalChatStorage.saveMessages(widget.convoId, combinedMessages);

          // Initial scroll
          if (!_initialScrollDone && _scrollController.hasClients) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _scrollController.animateTo(
                _scrollController.position.maxScrollExtent,
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeInOutSine,
              );
              _initialScrollDone = true;
            });
          }

          return ListView.builder(
            controller: _scrollController,
            itemCount: combinedMessages.length,
            itemBuilder: (context, index) {
              final message = combinedMessages[index];
              final senderMap = message['sender'] is Map
                  ? Map<String, dynamic>.from(message['sender'])
                  : <String, dynamic>{};
              final isSentByMe = senderMap['_id'] == currentUserId;

              final showDate = index == 0 ||
                  !isSameDay(
                    _parseTime(message['time']),
                    _parseTime(combinedMessages[index - 1]['time']),
                  );

              return Column(
                crossAxisAlignment: isSentByMe
                    ? CrossAxisAlignment.end
                    : CrossAxisAlignment.start,
                children: [
                  if (showDate)
                    DateSeparator(dateTime: _parseTime(message['time'])),
                  _buildMessageBubble(message, isSentByMe),
                ],
              );
            },
          );
        },
      ),
    );
  }

  void _saveAllMessages() {
    if (widget.convoId.isEmpty) return;
    final combined = [...dbMessages, ...messages, ...socketMessages];
    LocalChatStorage.saveMessages(widget.convoId, combined);
  }

// Helper methods
  bool _shouldAddMessage(Map<String, dynamic> msg) {
    return msg['content'].toString().trim().isNotEmpty ||
        msg['imageUrl'].toString().isNotEmpty ||
        msg['fileUrl'].toString().isNotEmpty;
  }

  bool _isUnreadMessage(dynamic msg) {
    if (msg is Map<String, dynamic>) {
      return msg['messageStatus'] != 'read' &&
          msg['sender']?['_id'] != currentUserId &&
          msg['message_id'] != null;
    }
    return false;
  }

  List<String> _getUnreadMessageIds(List<dynamic> messages) {
    return messages
        .where(_isUnreadMessage)
        .map((msg) => msg['message_id'].toString())
        .toList();
  }

  Widget _buildMessageBubble(Map<String, dynamic> message, bool isSentByMe) {
    return MessageBubble(
      isReply: false,
      message: message,
      isSentByMe: isSentByMe,
      isSelected: _selectedMessageKeys.contains(_generateMessageKey(message)),
      onTap: () => _toggleMessageSelection(message),
      onLongPress: () => _toggleMessageSelection(message),
      onRightSwipe: () => _replyToMessage(message),
      onFileTap: (url, type) => _openFile(url, type),
      onImageTap: (url) => ImageViewer.show(context, url),
      buildStatusIcon: (status) => MessageStatusIcon(status: status ?? 'sent'),
      buildReactionsBar: (msg, sentByMe) => _buildReactionsBar(msg, sentByMe),
      sentMessageColor: senderColor,
      // primaryshadecolor.withOpacity(0.3),
      receivedMessageColor: receiverColor,
      //Colors.white,
      selectedMessageColor: senderColor.withOpacity(0.2),
      //   Colors.lightBlueAccent.withOpacity(0.2),

      borderColor: Colors.blue,
      chatColor: chatColor,
      onReact: (msg, emoji) {
        setState(() {
          log("Adding reaction: $emoji to message: ${msg['message_id']}");
          _handleReactionTap(msg, emoji);

          setState(() {
            _showSearchAppBar = false;
            _isSelectionMode = false;
            _selectedMessages.clear();
            _selectedMessageKeys.clear();
          });
        });
      },
      emojpicker: () => ReactionDialog.show(
        context: context,
        messageId: message['message_id']?.toString() ?? '',
        reactions: message['reactions'] as List<Map<String, dynamic>>? ?? [],
        currentUserId: currentUserId,
        convoId: widget.convoId,
        receiverId: widget.datumId ?? "",
        firstName: widget.firstname ?? "",
        lastName: widget.lastname ?? "",
      ),
    );
  }

  Widget _buildReactionsBar(Map<String, dynamic> message, bool isSentByMe) {
    if (message['reactions'] == null || message['reactions'].isEmpty) {
      return const SizedBox.shrink();
    }
    return ReactionBar(
      message: message,
      currentUserId: currentUserId,
      onReactionTap: _handleReactionTap,
    );
  }

  void _handleReactionTap(Map<String, dynamic> message, String emoji) {
    try {
      final messageId = message['message_id']?.toString() ??
          message['messageId']?.toString() ??
          message['id']?.toString() ??
          message['_id']?.toString();

      if (messageId == null || messageId.isEmpty) {
        log('❌ Invalid message ID');
        return;
      }

      final reactions =
          (message['reactions'] as List?)?.whereType<Map>().toList() ?? [];

      // Find if current user already reacted
      final myReaction = reactions.firstWhere(
        (r) => (r['user']?['_id'] ?? r['userId']) == currentUserId,
        orElse: () => {},
      );

      final hasMyReaction = myReaction.isNotEmpty;

      if (hasMyReaction) {
        final oldEmoji = myReaction['emoji'];

        if (oldEmoji == emoji) {
          // Same emoji → remove it
          _messagerBloc.add(RemoveReaction(
            messageId: messageId,
            conversationId: widget.convoId,
            emoji: emoji,
            userId: currentUserId,
            receiverId: widget.datumId ?? "",
            firstName: widget.firstname ?? "",
            lastName: widget.lastname ?? "",
          ));
          return;
        } else {
          // Different emoji → remove old first
          _messagerBloc.add(RemoveReaction(
            messageId: messageId,
            conversationId: widget.convoId,
            emoji: emoji,
            userId: currentUserId,
            receiverId: widget.datumId ?? "",
            firstName: widget.firstname ?? "",
            lastName: widget.lastname ?? "",
          ));
        }
      }

      // Add the new emoji
      _messagerBloc.add(AddReaction(
        messageId: messageId,
        conversationId: widget.convoId,
        emoji: emoji,
        userId: currentUserId,
        receiverId: widget.datumId ?? "",
        firstName: widget.firstname ?? "",
        lastName: widget.lastname ?? "",
      ));
    } catch (e, stackTrace) {
      log('❌ Error handling reaction tap: $e\n$stackTrace');
    }
  }

  bool isValidUrl(String url) {
    return url.startsWith('http://') || url.startsWith('https://');
  }

  void _openFile(String urlOrPath, String? fileType) async {
    if (urlOrPath.startsWith('http://') || urlOrPath.startsWith('https://')) {
      // It's a URL - open in browser or external app
      try {
        await launchUrl(Uri.parse(urlOrPath),
            mode: LaunchMode.externalApplication);
      } catch (e) {
        Messenger.alertError("Could not open file from URL.");
      }
    } else {
      // It's a local file - open using system file viewer
      final result = await OpenFile.open(urlOrPath);
      if (result.type != ResultType.done) {
        Messenger.alertError("Could not open local file.");
      }
    }
  }

  final recorderHelper = AudioRecorderHelper();

  String _formatDuration(int seconds) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$secs';
  }

  Widget _buildVoiceRecordingUI() {
    return VoiceRecordingWidget(
      isRecording: _isRecording,
      isPaused: _isPaused,
      recordDuration: Duration(seconds: _recordDuration),
      formatDuration: (duration) => _formatDuration(duration.inSeconds),
      onStartRecording: recorderHelper.startRecording,
      onPauseRecording: recorderHelper.pauseRecording,
      onResumeRecording: recorderHelper.resumeRecording,
      onStopRecording: recorderHelper.stopRecording,
      onPlayRecording: recorderHelper.playRecording,
      onSendRecording: recorderHelper.sendRecording,
      recordedFilePath: _recordedFilePath,
      onCancel: () {
        _timer?.cancel();
        setState(() {
          _isRecording = false;
          _isPaused = false;
          _recordedFilePath = null;
        });
      },
    );
  }

  Widget _buildMessageInputField(bool isKeyboardVisible) {
    return MessageInputField(
      messageController: _messageController,
      reciverID: widget.datumId ?? "",
      focusNode: _focusNode,
      onSendPressed: _sendMessage,
      onEmojiPressed: _toggleEmojiKeyboard,
      onAttachmentPressed: () => ShowAltDialog.showOptionsDialog(context,
          conversationId: widget.convoId,
          senderId: currentUserId,
          receiverId: widget.datumId!,
          isGroupChat: false,
          onOptionSelected: _sendMessageImage),
      onCameraPressed: _openCamera,
      onRecordPressed: _isRecording
          ? recorderHelper.stopRecording
          : recorderHelper.startRecording,
      isRecording: _isRecording,
      replyText: _replyMessage,
      onCancelReply: () {
        recorderHelper.cancelReply();
        _replyMessage = null;
        _messageController.clear();
        setState(() {});
      },
    );
  }

  PreferredSizeWidget _buildAppBar() {
    log("converstionId : ${widget.convoId}");
    return CommonAppBarBuilder.build(
        context: context,
        showSearchAppBar: _showSearchAppBar,
        isSelectionMode: _isSelectionMode,
        selectedMessages: _selectedMessages,
        toggleSelectionMode: _toggleSelectionMode,
        deleteSelectedMessages: () {
          DeleteMessageDialog.show(
            context: context,
            onDeleteForEveryone: () {
              print("Deleted for everyone");
            },
            onDeleteForMe: () {
              _deleteSelectedMessages();
              print("Deleted for me");
            },
          );
        },
        // _deleteSelectedMessages,
        forwardSelectedMessages: _forwardSelectedMessages,
        starSelectedMessages: _starSelectedMessages,
        replyToMessage: _replyToMessage,
        profileAvatarUrl: widget.profileAvatarUrl,
        userName: widget.userName,
        firstname: widget.firstname,
        lastname: widget.lastname,
        lastSeen:
            _userOnlineStatus.isNotEmpty ? _userOnlineStatus : widget.lastSeen,
        convertionId: widget.convoId,
        grpId: widget.datumId ?? "",
        resvID: widget.datumId ?? "",
        favouitre: widget.favourite,
        grpChat: widget.grpChat,
        onSearchTap: () {
          toggleSearchAppBar();
        },
        onCloseSearch: () {
          toggleSearchAppBar();
        });
  }

  @override
  Widget build(BuildContext context) {
    return ReusableChatScaffold(
      appBar: _buildAppBar(),
      chatBody: _buildChatBody(),
      voiceRecordingUI: _buildVoiceRecordingUI(),
      messageInputBuilder: _buildMessageInputField,
      isRecording: _isRecording,
      bloc: _messagerBloc,
    );
  }
}
