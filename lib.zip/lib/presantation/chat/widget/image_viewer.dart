import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';

class ImageViewer {
  /// Shows a full-screen dialog with zoomable image
  static void show(BuildContext context, String imageUrl) {
    if (imageUrl.isEmpty) {
      log("Image URL is empty");
      return;
    }

    log("Opening full image: $imageUrl");

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: const EdgeInsets.all(10),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: InteractiveViewer(
            panEnabled: true,
            minScale: 0.8,
            maxScale: 4,
            child: _buildImage(imageUrl),
          ),
        ),
      ),
    );
  }

  /// Builds image widget depending on source type
  static Widget _buildImage(String imageUrl) {
    final isNetwork = imageUrl.startsWith('http');

    return isNetwork
        ? Image.network(
            imageUrl,
            fit: BoxFit.cover,
            filterQuality: FilterQuality.high,
            errorBuilder: (context, error, stackTrace) => const Center(
              child: Text(
                "Failed to load image",
                style: TextStyle(color: Colors.white),
              ),
            ),
          )
        : Image.file(
            File(imageUrl),
            fit: BoxFit.cover,
            filterQuality: FilterQuality.high,
            errorBuilder: (context, error, stackTrace) => const Center(
              child: Text(
                "Failed to load image",
                style: TextStyle(color: Colors.white),
              ),
            ),
          );
  }
}
