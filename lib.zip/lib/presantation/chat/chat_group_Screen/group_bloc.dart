// import 'dart:developer';

// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:nde_email/data/respiratory.dart';
// import 'package:nde_email/presantation/chat/Socket/Socket_Service.dart';
// import 'package:nde_email/presantation/chat/chat_contact_list/local_strorage.dart';
// import 'package:nde_email/presantation/chat/chat_group_Screen/api_servicer.dart';
// import 'package:nde_email/presantation/chat/chat_group_Screen/group_event.dart';
// import 'package:nde_email/presantation/chat/chat_group_Screen/group_model.dart';
// import 'package:nde_email/presantation/chat/chat_group_Screen/group_state.dart';
// import 'package:objectid/objectid.dart';

// import '../../../main.dart';

// class GroupChatBloc extends Bloc<GroupChatEvent, GroupChatState> {
//   final SocketService grpsocketService;
//   final GrpMessagerApiService apiService;

//   GroupChatBloc(this.grpsocketService, this.apiService)
//       : super(GroupChatInitial()) {
//     on<FetchGroupMessages>(_onFetchMessages);
//     on<GrpUploadFileEvent>(_onUploadFile);
//     on<ListenToMessages>(_onListenToMessages);
//     on<SendMessageEvent>(_onSendMessage);
//     on<DeleteMessagesEvent>(_onDeleteMessage);
//     on<ForwardMessageEvent>(_forwardMessage);
//     on<PermissionCheck>(_chatPermission);
//     on<GroupAddReaction>(_onGroupAddReaction);
//     on<GroupRemoveReaction>(_onGroupRemoveReaction);
//   }

//   Future<void> _onFetchMessages(
//     FetchGroupMessages event,
//     Emitter<GroupChatState> emit,
//   ) async {
//     try {
//       if (event.page == 1) {
//         emit(GroupChatLoading());

//         final localMessages = GrpLocalChatStorage.loadMessages(event.convoId)
//             .map((map) {
//               try {
//                 if (map is Map<String, dynamic>) {
//                   return GroupMessageModel.fromJson(map);
//                 }
//                 return null;
//               } catch (e, stack) {
//                 log('⚠️ Error parsing local message: $e');
//                 log(stack.toString());
//                 return null;
//               }
//             })
//             .whereType<GroupMessageModel>()
//             .toList();

//         if (localMessages.isNotEmpty) {
//           emit(GroupChatLoaded(
//             GroupMessageResponse(
//               data: localMessages,
//               total: localMessages.length,
//               page: 1,
//               limit: event.limit,
//               hasPreviousPage: false,
//               hasNextPage: false,
//             ),
//           ));
//           log('📤 Loaded ${localMessages.length} local messages');
//         }
//       }

//       // Fetch from API
//       final response = await apiService.fetchMessages(
//         convoId: event.convoId,
//         page: event.page,
//         limit: event.limit,
//       );

//       // Process API response with proper error handling
//       final apiMessages = response.data
//           .map((msg) {
//             try {
//               if (msg is GroupMessageModel) return msg;
//               if (msg is Map<String, dynamic>) {
//                 return GroupMessageModel.fromJson(msg as Map<String, dynamic>);
//               }
//               return null;
//             } catch (e, stack) {
//               log('⚠️ Error parsing API message: $e');

//               return null;
//             }
//           })
//           .whereType<GroupMessageModel>()
//           .toList();

//       log('  Received ${apiMessages.length} API messages');

//       // Save to local storage
//       if (apiMessages.isNotEmpty) {
//         await GrpLocalChatStorage.saveMessages(
//           event.convoId,
//           apiMessages.map((msg) => msg.toJson()).toList(),
//         );
//       }

//       // Update state
//       final currentState = state;
//       if (currentState is GroupChatLoaded && event.page > 1) {
//         final allMessages = [...currentState.response.data, ...apiMessages];
//         emit(GroupChatLoaded(
//           GroupMessageResponse(
//             data: allMessages,
//             total: response.total,
//             page: event.page,
//             limit: event.limit,
//             hasPreviousPage: response.hasPreviousPage,
//             hasNextPage: response.hasNextPage,
//           ),
//         ));
//       } else {
//         emit(GroupChatLoaded(response));
//       }
//     } catch (e, stack) {
//       log('  Error in _onFetchMessages: $e');

//       emit(GroupChatError('Failed to load messages: ${e.toString()}'));
//     }
//   }

//   Future<void> _onUploadFile(
//     GrpUploadFileEvent event,
//     Emitter<GroupChatState> emit,
//   ) async {
//     emit(UploadInProgress(0));
//     log("Entering into BLoC");

//     try {
//       await apiService.uploadFile(
//         file: event.file,
//         onProgress: (progress) {
//           emit(UploadInProgress(progress));
//         },
//         onSuccess: (data) async {
//           emit(UploadSuccess(data));

//           final contentType = data["ContentType"] ?? "file";
//           final mimeType = data["mimetype"] ?? "unknown";
//           final fileWithText = data["file_with_text"] ?? "";
//           final fileName = data["fileName"] ?? "unknown";
//           final size = data["size"] ?? 0;
//           final thumbnailKey = data["thumbnail_key"] ?? "";
//           final originalKey = data["originalKey"] ?? "";
//           final thumbnailUrl = data["thumbnailUrl"] ?? "";
//           final originalUrl = data["originalUrl"] ?? "";

//           log("📡 Upload success - now emitting socket event...");

//           String? workspaceID = await UserPreferences.getDefaultWorkspace();

//           final roomId =
//               grpsocketService.generateRoomId(event.senderId, event.receiverId);
//           final messageId = ObjectId().toString();

//           grpsocketService.sendMessage(
//             isGroupMessage: true,
//             messageId: messageId,
//             conversationId: event.convoId,
//             senderId: event.senderId,
//             receiverId: event.receiverId,
//             message: event.message,

//             roomId: roomId,
//             workspaceId: workspaceID!,
//             isGroupChat: true,
//             contentType: contentType,
//             mimeType: mimeType,
//             fileWithText: fileWithText.isNotEmpty,
//             fileName: fileName,
//             size: size,
//             thumbnailKey: thumbnailKey,
//             thumbnailUrl: thumbnailUrl,
//             originalKey: originalKey,
//             originalUrl: originalUrl,
//           );
//         },
//         onError: (error) {
//           emit(UploadFailure(error));
//           log("Error during upload: $error");
//         },
//       );
//     } catch (e) {
//       emit(UploadFailure(e.toString()));
//       log("Error: $e");
//     }
//   }
//   Future<void> _onGroupAddReaction(
//       GroupAddReaction event,
//       Emitter<GroupChatState> emit,
//       ) async {
//     try {
//       log('🔹 _onGroupAddReaction: ${event.messageId}');

//       final String messageId = event.messageId;
//       final bool isTemp = messageId.startsWith('temp_');

//       // Only call REST if not temp
//       if (!isTemp) {
//         await apiService.reactionUpdated(
//           conversationId: event.conversationId,
//           messageId: messageId,
//           emoji: event.emoji,
//           userId: event.userId,
//           receiverId: event.receiverId,
//         );
//       } else {
//         log('ℹ️ Skipping HTTP reactionUpdated for temp messageId=$messageId');
//       }

//       // Always send via socket so all group members get updated_reaction
//       socketService.reactToMessage(
//         messageId: messageId,
//         conversationId: event.conversationId,
//         emoji: event.emoji,
//         userId: event.userId,
//         firstName: event.firstName ?? '',
//         lastName: event.lastName ?? '',
//       );
//     } catch (e, st) {
//       log('❌ _onGroupAddReaction error: $e');
//       log(st.toString());
//       // optional: emit(GroupChatError(...));
//     }
//   }

//   Future<void> _onGroupRemoveReaction(
//       GroupRemoveReaction event,
//       Emitter<GroupChatState> emit,
//       ) async {
//     try {
//       log('🔹 _onGroupRemoveReaction: ${event.messageId}');

//       final String messageId = event.messageId;
//       final bool isTemp = messageId.startsWith('temp_');

//       if (!isTemp) {
//         await apiService.reactionRemove(
//           conversationId: event.conversationId,
//           messageId: messageId,
//           userId: event.userId,
//           receiverId: event.receiverId,
//         );
//       } else {
//         log('ℹ️ Skipping HTTP reactionRemove for temp messageId=$messageId');
//       }

//       socketService.removeReaction(
//         messageId: messageId,
//         conversationId: event.conversationId,
//         emoji: event.emoji,
//         userId: event.userId,
//         firstName: event.firstName ?? '',
//         lastName: event.lastName ?? '',
//       );
//     } catch (e, st) {
//       log('❌ _onGroupRemoveReaction error: $e');
//       log(st.toString());
//     }
//   }

//   Future<void> _onDeleteMessage(
//     DeleteMessagesEvent event,
//     Emitter<GroupChatState> emit,
//   ) async {
//     log("Entering Delete Message and MessageBloc : $event");
//     try {
//       for (String messageId in event.messageIds) {
//         grpsocketService.deleteMessage(
//           messageId: messageId,
//           conversationId: event.convoId,
//         );
//       }

//       emit(GroupChatMessageDeletedSuccessfully(
//           deletedMessageIds: event.messageIds));
//     } catch (e) {
//       log("Failed to emit delete_message: $e");
//       emit(GroupChatError('Failed to delete message.'));
//     }
//   }

//   Future<void> _onListenToMessages(
//     ListenToMessages event,
//     Emitter<GroupChatState> emit,
//   ) async {
//     try {
//       grpsocketService.listenToMessages(
//         event.senderId,
//         event.receiverId,
//         (message) {
//           add(NewMessageReceived(message as GroupMessageResponse));
//         },
//       );
//     } catch (e) {
//       emit(GroupChatError(e.toString()));
//     }
//   }

//   Future<void> _onSendMessage(
//     SendMessageEvent event,
//     Emitter<GroupChatState> emit,
//   ) async {
//     try {
//       log("entering send message and MessagerBloc : $event");
//       String? workspaceID = await UserPreferences.getDefaultWorkspace();
//       final name = await UserPreferences.getUsername();

//       final roomId =
//           grpsocketService.generateRoomId(event.senderId, event.receiverId);
//       final messageId = ObjectId().toString();
//       log('Generated Message ID: $messageId');
//       log('Generated reply : ${event.replyTo.toString()}');
//       grpsocketService.sendMessage(
//           isGroupMessage: true,
//           messageId: messageId,
//           conversationId: event.convoId,
//           senderId: event.senderId,
//           receiverId: event.receiverId,
//           message: event.message,
//           roomId: roomId,
//           workspaceId: workspaceID!,
//           isGroupChat: true,
//           contentType: event.contentType,
//           reply: event.replyTo,
//           userName: name);
//       final sentMessage = GrpMessage(
//         senderId: event.senderId,
//         receiverId: event.receiverId,
//         message: event.message,
//         time: DateTime.now(),
//         messageId: messageId,
//         messageStatus: 'delivered',
//         isTemporary: false,
//       );

//       log(' Message sent successfully $sentMessage');
//       emit(GrpMessageSentSuccessfully(sentMessage) as GroupChatState);
//     } catch (e) {
//       emit(GroupChatError('Error sending message: $e'));
//     }
//   }

//   Future<void> _forwardMessage(
//     ForwardMessageEvent event,
//     Emitter<GroupChatState> emit,
//   ) async {
//     try {
//       grpsocketService.forwardMessage(
//         senderId: event.senderId,
//         receiverIds: event.receiverIds,
//         originalMessageId: event.originalMessageId,
//         messageContent: event.message,
//         conversationId: event.conversationId,
//         workspaceId: event.workspaceId,
//         isGroupChat: event.isGroupChat,
//         currentUserInfo: event.currentUserInfo,
//         file: event.file,
//         fileName: event.fileName,
//         image: event.image,
//         contentType: event.contentType,
//       );
//     } catch (e) {
//       log("  Error forwarding message: $e");
//       emit(GroupChatError('Error forwarding message: $e'));
//     }
//   }

//   Future<void> _chatPermission(
//     PermissionCheck event,
//     Emitter<GroupChatState> emit,
//   ) async {
//     final response = await apiService.checkPermission(grpId: event.grpId);

//     if (response != null) {
//       // Case 2: Error (e.g., left group)
//       if (response.containsKey('type') && response['type'] == 'left') {
//         if (state is! GroupLeftState) {
//           emit(GroupLeftState());
//         }
//         return;
//       }

//       // Case 1: Success (valid permissions)
//       if (response.containsKey('permissions') &&
//           response.containsKey('role') &&
//           response.containsKey('status')) {
//         emit(GroupPermissionLoaded(
//           role: response['role'],
//           permissions: Map<String, dynamic>.from(response['permissions']),
//           status: response['status'],
//         ));
//         return;
//       }

//       // Unknown case
//       if (state is! GroupChatError) {
//         emit(GroupChatError("Invalid permission response"));
//       }
//     } else {
//       if (state is! GroupChatError) {
//         emit(GroupChatError("Failed to fetch permissions"));
//       }
//     }
//   }
// }



import 'dart:developer';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nde_email/data/respiratory.dart';
import 'package:nde_email/presantation/chat/Socket/Socket_Service.dart';
import 'package:nde_email/presantation/chat/chat_contact_list/local_strorage.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/api_servicer.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_event.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_model.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_state.dart';
import 'package:objectid/objectid.dart';
import '../../../main.dart';

class GroupChatBloc extends Bloc<GroupChatEvent, GroupChatState> {
  final SocketService grpSocket;
  final GrpMessagerApiService api;

  GroupChatBloc(this.grpSocket, this.api) : super(GroupChatInitial()) {
    on<FetchGroupMessages>(_onFetchGroupMessages);
    on<SendMessageEvent>(_onSendMessage);
    on<GrpUploadFileEvent>(_onUploadFile);
    on<DeleteMessagesEvent>(_onDeleteMessage);
    on<GroupAddReaction>(_onGroupAddReaction);
    on<GroupRemoveReaction>(_onGroupRemoveReaction);
    on<ForwardMessageEvent>(_forwardMessage);
    on<PermissionCheck>(_chatPermission);
  }

  // ==========================================================
  //                📌 FETCH GROUPED MESSAGES
  // ==========================================================
  Future<void> _onFetchGroupMessages(
      FetchGroupMessages event, Emitter<GroupChatState> emit) async {
    try {
      if (event.page == 1) {
        emit(GroupChatLoading());

        /// Load local stored (flat) messages
        final localMaps = GrpLocalChatStorage.loadMessages(event.convoId);

        final localMessages = localMaps
            .map((json) => GroupMessageModel.fromJson(json))
            .toList();

        if (localMessages.isNotEmpty) {
          emit(GroupChatLoaded(
            GroupMessageResponse(
              data: _groupMessagesByDate(localMessages),
              total: localMessages.length,
              page: 1,
              limit: event.limit,
              hasPreviousPage: false,
              hasNextPage: false,
            ),
          ));

          log("📌 Loaded local cache: ${localMessages.length}");
        }
      }

      // =============================
      // 🔥 Fetch API Grouped Response
      // =============================
      final apiResp = await api.fetchMessages(
        convoId: event.convoId,
        page: event.page,
        limit: event.limit,
      );

      // API returns:
      // data = List<GroupMessageGroup>
      final List<GroupMessageGroup> incomingGroups = apiResp.data;

      // Flatten messages for saving to local
      final flatIncoming = incomingGroups
          .expand((group) => group.messages)
          .toList();

      if (flatIncoming.isNotEmpty) {
        await GrpLocalChatStorage.saveMessages(
          event.convoId,
          flatIncoming.map((m) => m.toJson()).toList(),
        );
      }

      // Merge Pages
      if (state is GroupChatLoaded && event.page > 1) {
        final prev = (state as GroupChatLoaded).response;

        // merge groups properly
        final mergedGroups =
            _mergeGroupedPages(prev.data, incomingGroups);

        emit(GroupChatLoaded(
          GroupMessageResponse(
            data: mergedGroups,
            total: apiResp.total,
            page: apiResp.page,
            limit: apiResp.limit,
            hasPreviousPage: apiResp.hasPreviousPage,
            hasNextPage: apiResp.hasNextPage,
          ),
        ));
      } else {
        emit(GroupChatLoaded(apiResp));
      }
    } catch (e, st) {
      log("❌ FetchGroupMessages Error: $e");
      emit(GroupChatError("Failed to load messages"));
    }
  }

  // ==========================================================
  //                📌 MERGE PAGINATION GROUPS
  // ==========================================================
  List<GroupMessageGroup> _mergeGroupedPages(
      List<GroupMessageGroup> oldGroups,
      List<GroupMessageGroup> newGroups) {
    final Map<String, GroupMessageGroup> groupMap = {
      for (var g in oldGroups) g.label: g
    };

    for (var ng in newGroups) {
      if (groupMap.containsKey(ng.label)) {
        groupMap[ng.label] = GroupMessageGroup(
          label: ng.label,
          messages: [...groupMap[ng.label]!.messages, ...ng.messages],
        );
      } else {
        groupMap[ng.label] = ng;
      }
    }

    final sorted = groupMap.values.toList()
      ..sort((a, b) => a.label.compareTo(b.label));

    return sorted;
  }

  // ==========================================================
  //           📌 BUILD GROUPS FROM LOCAL CACHE
  // ==========================================================
  List<GroupMessageGroup> _groupMessagesByDate(
      List<GroupMessageModel> list) {
    Map<String, List<GroupMessageModel>> map = {};

    for (var m in list) {
      final label = _formatDate(m.time);
      map.putIfAbsent(label, () => []);
      map[label]!.add(m);
    }

    return map.entries
        .map((e) => GroupMessageGroup(label: e.key, messages: e.value))
        .toList();
  }

  String _formatDate(DateTime dt) {
    return "${dt.year}-${dt.month}-${dt.day}";
  }

  // ==========================================================
  //               📌 SEND MESSAGE
  // ==========================================================
  Future<void> _onSendMessage(
      SendMessageEvent event, Emitter<GroupChatState> emit) async {
    try {
      final workspace = await UserPreferences.getDefaultWorkspace();
      final username = await UserPreferences.getUsername();
      final messageId = ObjectId().toString();

      grpSocket.sendMessage(
        isGroupMessage: true,
        messageId: messageId,
        conversationId: event.convoId,
        senderId: event.senderId,
        receiverId: event.receiverId,
        message: event.message,
        roomId:
            grpSocket.generateRoomId(event.senderId, event.receiverId),
        workspaceId: workspace!,
        isGroupChat: true,
        contentType: event.contentType,
        reply: event.replyTo,
        userName: username,
      );

      emit(GrpMessageSentSuccessfully(
        GrpMessage(
          messageId: messageId,
          senderId: event.senderId,
          receiverId: event.receiverId,
          message: event.message,
          time: DateTime.now(),
          messageStatus: "sent",
        ),
      ));
    } catch (e) {
      emit(GroupChatError("Failed to send message"));
    }
  }

  // ==========================================================
  //               📌 UPLOAD FILE
  // ==========================================================
  Future<void> _onUploadFile(
      GrpUploadFileEvent event, Emitter<GroupChatState> emit) async {
    emit(UploadInProgress(0));

    try {
      await api.uploadFile(
        file: event.file,
        onProgress: (p) => emit(UploadInProgress(p)),
        onSuccess: (data) async {
          final messageId = ObjectId().toString();
          final workspace = await UserPreferences.getDefaultWorkspace();

          grpSocket.sendMessage(
            isGroupMessage: true,
            messageId: messageId,
            conversationId: event.convoId,
            senderId: event.senderId,
            receiverId: event.receiverId,
            message: event.message,
            roomId: grpSocket.generateRoomId(
                event.senderId, event.receiverId),
            workspaceId: workspace!,
            isGroupChat: true,
            contentType: data["ContentType"],
            mimeType: data["mimeType"],
            fileName: data["fileName"],
            originalUrl: data["originalUrl"],
            thumbnailUrl: data["thumbnailUrl"],
            fileWithText: data["file_with_text"],
          );

          emit(UploadSuccess(data));
        },
        onError: (err) => emit(UploadFailure(err)),
      );
    } catch (e) {
      emit(UploadFailure(e.toString()));
    }
  }

  // ==========================================================
  //           📌 DELETE MESSAGE
  // ==========================================================
  Future<void> _onDeleteMessage(
      DeleteMessagesEvent event, Emitter<GroupChatState> emit) async {
    try {
      for (var id in event.messageIds) {
        grpSocket.deleteMessage(
          messageId: id,
          conversationId: event.convoId,
        );
      }

      emit(GroupChatMessageDeletedSuccessfully(
          deletedMessageIds: event.messageIds));
    } catch (e) {
      emit(GroupChatError("Delete failed"));
    }
  }

  // ==========================================================
  //          📌 ADD / REMOVE REACTION
  // ==========================================================
  Future<void> _onGroupAddReaction(
      GroupAddReaction e, Emitter<GroupChatState> emit) async {
    try {
      if (!e.messageId.startsWith("temp_")) {
        await api.reactionUpdated(
          conversationId: e.conversationId,
          messageId: e.messageId,
          emoji: e.emoji,
          userId: e.userId,
          receiverId: e.receiverId,
        );
      }

      grpSocket.reactToMessage(
        messageId: e.messageId,
        conversationId: e.conversationId,
        emoji: e.emoji,
        userId: e.userId,
        firstName: e.firstName ?? "",
        lastName: e.lastName ?? "",
      );
    } catch (_) {}
  }

  Future<void> _onGroupRemoveReaction(
      GroupRemoveReaction e, Emitter<GroupChatState> emit) async {
    try {
      if (!e.messageId.startsWith("temp_")) {
        await api.reactionRemove(
          conversationId: e.conversationId,
          messageId: e.messageId,
          userId: e.userId,
          receiverId: e.receiverId,
        );
      }

      grpSocket.removeReaction(
        messageId: e.messageId,
        conversationId: e.conversationId,
        emoji: e.emoji,
        userId: e.userId,
        firstName: e.firstName ?? "",
        lastName: e.lastName ?? "",
      );
    } catch (_) {}
  }

  // ==========================================================
  //             📌 FORWARD MESSAGE
  // ==========================================================
  Future<void> _forwardMessage(
      ForwardMessageEvent e, Emitter<GroupChatState> emit) async {
    try {
      grpSocket.forwardMessage(
        senderId: e.senderId,
        receiverIds: e.receiverIds,
        originalMessageId: e.originalMessageId,
        messageContent: e.message,
        conversationId: e.conversationId,
        workspaceId: e.workspaceId,
        isGroupChat: e.isGroupChat,
        currentUserInfo: e.currentUserInfo,
        file: e.file,
        fileName: e.fileName,
        image: e.image,
        contentType: e.contentType,
      );
    } catch (e) {
      emit(GroupChatError("Forward failed"));
    }
  }

  // ==========================================================
  //             📌 PERMISSION CHECK
  // ==========================================================
  Future<void> _chatPermission(
      PermissionCheck e, Emitter<GroupChatState> emit) async {
    final res = await api.checkPermission(grpId: e.grpId);

    if (res == null) {
      emit(GroupChatError("Permission check failed"));
      return;
    }

    if (res['type'] == "left") {
      emit(GroupLeftState());
      return;
    }

    if (res['permissions'] != null) {
      emit(GroupPermissionLoaded(
        role: res['role'],
        permissions: Map<String, dynamic>.from(res['permissions']),
        status: res['status'],
      ));
      return;
    }

    emit(GroupChatError("Invalid permission response"));
  }
}
