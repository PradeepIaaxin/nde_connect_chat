import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:any_link_preview/any_link_preview.dart';
import 'package:audio_waveforms/audio_waveforms.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:flutter_sound/public/flutter_sound_player.dart';
import 'package:flutter_sound/public/flutter_sound_recorder.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import 'package:mime/mime.dart';
import 'package:nde_email/presantation/chat/chat_contact_list/local_strorage.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/api_servicer.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_bloc.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_event.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_model.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_state.dart';
import 'package:nde_email/presantation/chat/widget/custom_appbar.dart';
import 'package:nde_email/presantation/chat/widget/scaffold.dart';
import 'package:nde_email/presantation/chat/widget/voicerec_ui.dart';
import 'package:nde_email/utils/const/consts.dart';
import 'package:nde_email/utils/datetime/date_time_utils.dart';
import 'package:nde_email/utils/reusbale/colour_utlis.dart';
import 'package:nde_email/utils/router/router.dart';
import 'package:nde_email/utils/snackbar/snackbar.dart';
import 'package:nde_email/utils/spacer/spacer.dart';
import 'package:objectid/objectid.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:swipe_to/swipe_to.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../data/respiratory.dart';
import '../../../utils/simmer_effect.dart/chat_simmerefect.dart';
import '../../widgets/chat_widgets/messager_Wifgets/ForwardMessageScreen_widget.dart';
import '../../widgets/chat_widgets/messager_Wifgets/buildMessageInputField_widgets.dart';
import '../../widgets/chat_widgets/messager_Wifgets/show_Bottom_Sheet.dart';
import '../Socket/Socket_Service.dart';

import 'package:nde_email/presantation/chat/widget/reation_bottom.dart';

import '../model/emoj_model.dart';

class GroupChatScreen extends StatefulWidget {
  const GroupChatScreen({
    super.key,
    required this.groupName,
    required this.groupAvatarUrl,
    this.participants,
    required this.currentUserId,
    required this.conversationId,
    required this.datumId,
    required this.grpChat,
    required this.favorite,
  });

  final String conversationId;
  final String currentUserId;
  final String datumId;
  final String groupAvatarUrl;
  final String groupName;
  final List<String>? participants;
  final bool grpChat;
  final bool favorite;

  @override
  State<GroupChatScreen> createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  String currentUserId = '';
  List<Map<String, dynamic>> dbMessages = [];

  final ValueNotifier<bool> isLongPressed = ValueNotifier<bool>(false);

  List<Map<String, dynamic>> messages = [];
  List<Map<String, dynamic>> socketMessages = [];
  final SocketService socketService = SocketService();

  Duration _audioDuration = Duration.zero;
  final AudioPlayer _audioPlayer = AudioPlayer();
  final AudioRecorder _audioRecorder = AudioRecorder();
  Duration _currentDuration = Duration.zero;

  int _currentPage = 1;

  File? _fileUrl;
  final FocusNode _focusNode = FocusNode();
  late final GroupChatBloc _groupBloc;
  bool _hasNextPage = false;

  File? _imageFile;

  bool _initialScrollDone = false;
  bool _isCompleted = false;
  bool _isDeletingMessages = false;
  bool _isLoadingMore = false;
  bool _isPaused = false;
  bool _isPlaying = false;
  bool _isRecording = false;
  bool _isSelectionMode = false;

  bool _isTyping = false;
  int _limit = 10;

  final TextEditingController _messageController = TextEditingController();

  final FlutterSoundPlayer _player = FlutterSoundPlayer();
  int _recordDuration = 0;
  Timer? _recordTimer;
  File? _recordedFile;
  String? _recordedFilePath;
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  late final RecorderController _recorderController = RecorderController();
  Timer? _recordingTimer;
  Map<String, dynamic>? _replyMessage;
  final ScrollController _scrollController = ScrollController();
  final Set<String> _selectedMessageIds = {};
  final Set<String> _selectedMessageKeys = {};
  List<dynamic> _selectedMessages = [];
  bool _showEmoji = false;
  bool _showSearchAppBar = false;
  Timer? _timer;
  Duration _totalDuration = Duration.zero;
  bool _permissionChecked = false;

  // 👇 NEW: reaction stream + seen ids (for dedupe)
  StreamSubscription<MessageReaction>? _reactionSubscription;
  final Set<String> _seenMessageIds = {};

  @override
  void dispose() {
    _messageController.dispose();
    _focusNode.dispose();
    _scrollController.removeListener(_scrollListener);
    _scrollController.dispose();

    _timer?.cancel();
    _recordingTimer?.cancel();
    _recordTimer?.cancel();

    _reactionSubscription?.cancel();

    _clearSessionImagePath();
    SocketService().disconnect();

    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _initMessages();

    _groupBloc = GroupChatBloc(socketService, GrpMessagerApiService());

    _initializeSocket();
    _loadCurrentUserId();

    if (!_permissionChecked) {
      _groupBloc.add(PermissionCheck(widget.datumId));
      _permissionChecked = true;
    }

    _fetchMessages2();

    _scrollController.addListener(_scrollListener);
  }

  Future<void> startRecording() async {
    try {
      if (await _audioRecorder.hasPermission()) {
        final directory = await getApplicationDocumentsDirectory();
        final path =
            '${directory.path}/audio_message_${DateTime.now().millisecondsSinceEpoch}.m4a';

        await _audioRecorder.start(
          RecordConfig(encoder: AudioEncoder.aacLc),
          path: path,
        );

        _startTimer();

        setState(() {
          _isRecording = true;
          _recordedFilePath = path;
        });
      } else {
        Messenger.alert(msg: "Microphone permission denied");
      }
    } catch (e) {
      log('Error starting recording: $e');
      setState(() => _isRecording = false);
    }
  }

  bool isSameDay(DateTime? date1, DateTime? date2) {
    if (date1 == null || date2 == null) return false;
    return date1.year == date2.year &&
        date1.month == date2.month &&
        date1.day == date2.day;
  }

  void toggleSearchAppBar() {
    setState(() {
      _showSearchAppBar = !_showSearchAppBar;
    });
  }

  /// 🔁 SOCKET CALLBACK – now also understands reaction events, like private chat
  void onMessageReceived(Map<String, dynamic> rawData) {
    // Step 1: Extract the actual message from the weird wrapper
    Map<String, dynamic> messageData;

    if (rawData['data'] != null) {
      // Case 1: { "data": { ...message... } } → your log shows this
      messageData = rawData['data'] as Map<String, dynamic>;
    } else if (rawData is Map && rawData.values.isNotEmpty) {
      // Case 2: The message is directly in rawData (fallback)
      messageData = rawData;
    } else {
      log("Invalid message format: $rawData");
      return;
    }

    // Step 2: Handle reactions (if backend sends event separately)
    if (messageData['event'] == 'updated_reaction') {
      _handleReactionUpdate(messageData['data']);
      return;
    }

    // Step 3: Extract fields safely
    final content = (messageData['content'] ?? '').toString().trim();
    final imageUrl = messageData['thumbnailUrl'] ?? messageData['originalUrl'];
    final fileUrl = messageData['originalUrl'] ?? messageData['fileUrl'];
    final fileName = messageData['fileName'];
    final userName = messageData['userName'] ?? 'Unknown';

    if (content.isEmpty && imageUrl == null && fileUrl == null) return;

    final messageId =
        (messageData['message_id'] ?? messageData['id'])?.toString();
    if (messageId != null && _seenMessageIds.contains(messageId)) {
      log("Duplicate group message ignored: $messageId");
      return;
    }
    if (messageId != null) _seenMessageIds.add(messageId);

    final newMessage = {
      'message_id': messageId,
      'content': content,
      'sender': messageData['sender'] ?? {},
      'receiver': messageData['receiver'] ?? {},
      'messageStatus': messageData['messageStatus'] ?? 'delivered',
      'time': messageData['time'],
      'imageUrl': imageUrl,
      'fileName': fileName,
      'userName': userName,
      'fileUrl': fileUrl,
      'fileType': messageData['mimeType'] ?? messageData['fileType'],
      'isForwarded': messageData['isForwarded'] ?? false,
      'ContentType': messageData['ContentType'] ?? 'text',
      'isReplyMessage': messageData['isReplyMessage'] ?? false,
      'repliedMessage': messageData['reply'] ?? messageData['repliedMessage'],
      'reactions': messageData['reactions'] ?? [],
    };

    if (!mounted) return;

    setState(() {
      final exists = socketMessages.any((msg) =>
          (msg['message_id'] ?? msg['id']) == newMessage['message_id']);

      if (!exists) {
        socketMessages.add(newMessage);
        _scrollToBottom();
        log("NEW GROUP MESSAGE ADDED: $content - $userName");
      }

      final combined = [...dbMessages, ...messages, ...socketMessages];
      GrpLocalChatStorage.saveMessages(widget.conversationId, combined);
    });
  }

  void _handleReactionUpdate(dynamic reactionData) {
    try {
      MessageReaction? reaction;
      if (reactionData is Map<String, dynamic>) {
        reaction = MessageReaction.fromMap(reactionData);
      } else if (reactionData is List &&
          reactionData.isNotEmpty &&
          reactionData.first is Map) {
        reaction = MessageReaction.fromMap(
            Map<String, dynamic>.from(reactionData.first));
      }
      if (reaction == null) return;
      _updateMessageWithReaction(reaction);
    } catch (e, st) {
      debugPrint('❌ Group reaction update failed: $e\n$st');
    }
  }

  /// 🔁 listen to SocketService.reactionStream (same as private)
  void _setupReactionListener() {
    _reactionSubscription?.cancel();
    _reactionSubscription =
        socketService.reactionStream.listen((MessageReaction reaction) {
      _updateMessageWithReaction(reaction);
    });
  }

  /// Actually apply reaction change to in-memory lists and save
  void _updateMessageWithReaction(MessageReaction reaction) {
    if (!mounted) return;
    String normalizeId(dynamic id) => id?.toString().trim() ?? '';

    bool updated = false;

    void updateReactions(List<Map<String, dynamic>> list) {
      for (var msg in list) {
        final msgId = normalizeId(
            msg['message_id'] ?? msg['messageId'] ?? msg['_id'] ?? msg['id']);
        if (msgId == normalizeId(reaction.messageId)) {
          List<Map<String, dynamic>> oldReactions =
              List<Map<String, dynamic>>.from(msg['reactions'] ?? []);

          // remove old reaction from same user
          oldReactions.removeWhere((r) =>
              normalizeId(r['user']?['_id']) == normalizeId(reaction.user.id));

          if (!reaction.isRemoval) {
            oldReactions.add({
              'emoji': reaction.emoji,
              'reacted_at': reaction.reactedAt.toIso8601String(),
              'user': {
                '_id': reaction.user.id,
                'first_name': reaction.user.firstName,
                'last_name': reaction.user.lastName,
              }
            });
          }

          msg['reactions'] = List<Map<String, dynamic>>.from(oldReactions);
          updated = true;
          break;
        }
      }
    }

    updateReactions(dbMessages);
    updateReactions(messages);
    updateReactions(socketMessages);

    if (updated) {
      setState(() {});
      final combined = _getCombinedMessages();
      GrpLocalChatStorage.saveMessages(widget.conversationId, combined);
    }
  }

  Map<String, dynamic> normalizeMessage(dynamic rawMsg) {
    if (rawMsg == null) return {};
    if (rawMsg is String) return {};
    if (rawMsg is! Map && rawMsg is! GroupMessageModel) return {};

    Map<String, dynamic> message = {};

    if (rawMsg is GroupMessageModel) {
      message = rawMsg.toJson();
    } else if (rawMsg is Map) {
      try {
        message = Map<String, dynamic>.from(rawMsg);
      } catch (e) {
        return {};
      }
    }

    final content = message['content']?.toString().trim() ?? '';
    final userName = message['userName'] ?? '';
    final isForwarded = message['isForwarded'] ?? false;
    final imageUrl = message['originalUrl'] ?? message['imageUrl'];
    final fileUrl = message['originalUrl'] ?? message['fileUrl'];
    final fileName = message['fileName'];
    final fileType = message['mimeType'] ?? message['fileType'];
    final messageId = message['message_id'] ?? message['id'];
    final contentType = message['ContentType'] ?? message['contentType'];

    final isReplyMessage = message['isReplyMessage'] ?? false;
    final reply = message['reply'] ?? message['repliedMessage'];

    final senderData = message['sender'] is Map ? message['sender'] : {};
    final String profilePic = senderData['profile_pic_path'] ??
        senderData['profilePic'] ??
        senderData['avatar'] ??
        '';

    final normalizedReply = (reply != null && reply is Map<String, dynamic>)
        ? {
            "userId": reply["userId"] ?? reply["senderId"],
            "id": reply["id"] ?? reply["message_id"] ?? reply["messageId"],
            "mimeType": reply["mimeType"] ?? "",
            "ContentType": reply["ContentType"] ?? "",
            "replyContent": reply["content"] ?? reply["replyContent"] ?? "",
            "replyToUser": reply["replyToUser"] ?? reply["replyToUSer"] ?? "",
            "fileName": reply["fileName"] ?? "",
            "first_name": reply["first_name"] ?? "",
            "last_name": reply["last_name"] ?? "",
            'profile_pic_path': message['sender']?['profile_pic_path'] ??
                message['sender']?['profilePic'] ??
                message['profile_pic_path'] ??
                '',
          }
        : null;

    return {
      'message_id': messageId,
      'content': content,
      'userName': userName,
      'sender': message['sender'],
      'receiver': message['receiver'],
      'messageStatus': message['messageStatus'] ?? 'delivered',
      'time': message['time'],
      'imageUrl': imageUrl,
      'fileName': fileName,
      'ContentType': contentType,
      'fileUrl': fileUrl,
      'fileType': fileType,
      'isForwarded': isForwarded,
      'isReplyMessage': isReplyMessage,
      'repliedMessage': normalizedReply,
      'reactions': message['reactions'] ?? [],
      'profile_pic_path': profilePic,
    };
  }

  bool isValidUrl(String url) {
    return url.startsWith('http://') || url.startsWith('https://');
  }

  void _showFullImage(BuildContext context, String imageUrl) {
    log(imageUrl);
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: const EdgeInsets.all(10),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: InteractiveViewer(
            panEnabled: true,
            minScale: 0.8,
            maxScale: 4,
            child: imageUrl.startsWith('https')
                ? Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.high,
                    errorBuilder: (context, error, stackTrace) => const Center(
                      child: Text("Failed to load image",
                          style: TextStyle(color: Colors.white)),
                    ),
                  )
                : Image.file(
                    File(imageUrl),
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.high,
                    errorBuilder: (context, error, stackTrace) => const Center(
                      child: Text("Failed to load image",
                          style: TextStyle(color: Colors.white)),
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  IconData _getFileIcon(String? fileType) {
    if (fileType == null) return Icons.insert_drive_file;

    switch (fileType.toLowerCase()) {
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'doc':
      case 'docx':
        return Icons.description;
      case 'xls':
      case 'xlsx':
        return Icons.grid_on;
      case 'ppt':
      case 'pptx':
        return Icons.slideshow;
      case 'mp3':
      case 'wav':
        return Icons.audiotrack;
      case 'mp4':
      case 'mov':
      case 'avi':
        return Icons.movie;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return Icons.image;
      default:
        return Icons.insert_drive_file;
    }
  }

  Future<void> _initMessages() async {
    final savedMessages =
        await GrpLocalChatStorage.loadMessages(widget.conversationId);

    setState(() {
      dbMessages = savedMessages
          .map<Map<String, dynamic>>((msg) => normalizeMessage(msg))
          .where((m) => m.isNotEmpty)
          .toList();

      for (var m in dbMessages) {
        final id = (m['message_id'] ?? m['id'])?.toString();
        if (id != null && id.isNotEmpty) _seenMessageIds.add(id);
      }
    });
  }

  Future<void> _initializeSocket() async {
    final String? token = await UserPreferences.getAccessToken();
    if (token == null) {
      log("Access token is null. Socket connection not initialized.");
    }
  }

  Future<void> _loadCurrentUserId() async {
    currentUserId = await UserPreferences.getUserId() ?? '';

    if (currentUserId.isNotEmpty && widget.datumId.isNotEmpty) {
      log("currentUserId  ..$currentUserId");
      log("datumId  ..${widget.datumId}");

      SocketService().connectPrivateRoom(
          currentUserId, widget.datumId, onMessageReceived, true);

      _setupReactionListener();
    }
    setState(() {});
  }

  void _fetchMessages2() {
    _groupBloc.add(
      FetchGroupMessages(
        convoId: widget.conversationId,
        page: _currentPage,
        limit: 40,
      ),
    );
  }

  void _fetchMessages() {
    _groupBloc.add(
      FetchGroupMessages(
        convoId: widget.conversationId,
        page: _currentPage,
        limit: _limit,
      ),
    );

    _checkingPersmmion();
  }

  void _checkingPersmmion() {
    context.read<GroupChatBloc>().add(
          PermissionCheck(widget.datumId),
        );
  }

  Future<void> _loadSessionImagePath() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('chat_image_path');

    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _imageFile = File(imagePath);
        log(" -----image-- $_imageFile");
      });
    }
  }

  Future<void> _clearSessionPaths() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('chat_image_path');
    await prefs.remove('chat_file_path');
  }

  Future<void> _loadSessionFilePath() async {
    final prefs = await SharedPreferences.getInstance();
    final filePath = prefs.getString('chat_file_path');

    if (filePath != null && filePath.isNotEmpty) {
      setState(() {
        _fileUrl = File(filePath);
        log(" ------- $_fileUrl");
      });
    }
  }

  void _sendMessage() async {
    if (_messageController.text.trim().isEmpty || widget.datumId.isEmpty) {
      return;
    }

    final nowIso = DateTime.now().toIso8601String();
    final messageId = ObjectId().toString();

    final reply = _replyMessage;

    final message = {
      'message_id': messageId,
      'content': _messageController.text.trim(),
      'sender': {'_id': currentUserId},
      'receiver': {'_id': widget.datumId},
      'messageStatus': 'delivered',
      'time': nowIso,
      if (reply != null) 'repliedMessage': reply,
      if (reply != null) 'isReplyMessage': true,
    };

    setState(() {
      socketMessages.add(message);

      final combined = [...dbMessages, ...messages, ...socketMessages];
      GrpLocalChatStorage.saveMessages(widget.conversationId, combined);
    });

    _groupBloc.add(
      SendMessageEvent(
        convoId: widget.conversationId,
        message: _messageController.text.trim(),
        senderId: currentUserId,
        receiverId: widget.datumId,
        replyTo: reply,
      ),
    );

    setState(() {
      _messageController.clear();
      _replyMessage = null;
      _imageFile = null;
    });
  }

  void _sendMessageImage() async {
    await _loadSessionImagePath();
    await _loadSessionFilePath();

    log("Sending message with image and file");
    final nowIso = DateTime.now().toIso8601String();
    final String? mimeType =
        _fileUrl != null ? lookupMimeType(_fileUrl!.path) : null;

    final message = {
      'content': _messageController.text.trim(),
      'sender': {'_id': currentUserId},
      'receiver': {'_id': widget.datumId},
      'messageStatus': 'delivered',
      'time': nowIso,
      'fileName': _fileUrl?.path.split('/').last,
      'fileType': mimeType,
      'imageUrl': _imageFile?.path,
      'fileUrl': _fileUrl?.path,
    };

    log(message.toString());
    setState(() {
      socketMessages.add(message);
      _scrollToBottom();

      final combined = [...dbMessages, ...messages, ...socketMessages];
      GrpLocalChatStorage.saveMessages(widget.conversationId, combined);
    });
    setState(() {
      _messageController.clear();
      _imageFile = null;
      _fileUrl = null;
    });

    await _clearSessionPaths();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      Timer(
          const Duration(milliseconds: 400),
          () => _scrollController.animateTo(
                _scrollController.position.maxScrollExtent,
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeInOut,
              ));
    }
  }

  void _scrollListener() {
    if (!_scrollController.hasClients) return;

    if (_scrollController.position.pixels <=
            _scrollController.position.minScrollExtent + 120 &&
        _hasNextPage &&
        !_isLoadingMore) {
      _loadMoreMessages();
    }
  }

  void _loadMoreMessages() {
    if (_hasNextPage && !_isLoadingMore) {
      setState(() => _isLoadingMore = true);

      _currentPage++;
      _fetchMessages();
    }
  }

  Future<void> _openCamera() async {
    try {
      final XFile? file =
          await ImagePicker().pickImage(source: ImageSource.camera);

      if (file != null) {
        final File localFile = File(file.path);

        if (!localFile.existsSync()) {
          log("  File does not exist at: ${file.path}");
          Messenger.alert(msg: "Selected image is missing.");
          return;
        }

        final mimeType = lookupMimeType(file.path);
        final isImage = mimeType != null && mimeType.startsWith('image/');
        log("📄 MIME Type: $mimeType");
        log("🖼️ Is Image: $isImage");

        final prefs = await SharedPreferences.getInstance();

        if (isImage) {
          await prefs.setString('chat_image_path', localFile.path);
          log(" Image path saved: ${localFile.path}");
        }

        ShowAltDialog.showOptionsDialog(context,
            conversationId: widget.conversationId,
            senderId: currentUserId,
            receiverId: widget.datumId,
            isGroupChat: true,
            onOptionSelected: _sendMessageImage);

        final message = {
          'content': '',
          'sender': {'_id': currentUserId},
          'receiver': {'_id': widget.datumId},
          'messageStatus': 'pending',
          'time': DateTime.now().toIso8601String(),
          'localImagePath': file.path,
          'fileName': file.name,
          'fileType': mimeType,
          'imageUrl': file.path,
          'fileUrl': null,
        };

        log("🟢 Local message metadata: $message");

        setState(() {
          socketMessages.add(message);
        });

        context.read<GroupChatBloc>().add(
              GrpUploadFileEvent(
                localFile,
                widget.conversationId,
                currentUserId,
                widget.datumId,
                "",
              ),
            );

        Navigator.pop(context);
      }
    } catch (e) {
      log('  Error opening camera: $e');
      Messenger.alert(msg: "Could not open camera.");
    }
  }

  void _appendMessage(Map<String, dynamic> message) {
    setState(() {
      messages.add(message);
    });
  }

  String _formatDateTime(DateTime? dateTime) {
    if (dateTime == null) return '';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final messageDate = DateTime(dateTime.year, dateTime.month, dateTime.day);

    if (messageDate == today) return 'Today';
    if (messageDate == yesterday) return 'Yesterday';
    return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
  }

  void _toggleSelectionMode() {
    setState(() {
      _isSelectionMode = false;
      _selectedMessages.clear();
      _selectedMessageKeys.clear();
    });
  }

  void _markMessagesAsDeleted(List<String> messageIds) {
    log("Marking messages as deleted: $messageIds");

    setState(() {
      List<Map<String, dynamic>> updateMessages(
          List<Map<String, dynamic>> list) {
        return list.map((msg) {
          if (messageIds.contains(msg['message_id']?.toString())) {
            return {
              ...msg,
              'content': 'Message Deleted',
              'imageUrl': null,
              'fileUrl': null,
              'fileName': null,
              'fileType': null,
              'isDeleted': true,
            };
          }
          return msg;
        }).toList();
      }

      messages = updateMessages(messages);
      dbMessages = updateMessages(dbMessages);
      socketMessages = updateMessages(socketMessages);

      final combined = [...dbMessages, ...messages, ...socketMessages];
      GrpLocalChatStorage.saveMessages(widget.conversationId, combined);
    });
  }

  void _deleteSelectedMessages() {
    if (_selectedMessageIds.isEmpty) {
      log("No messages selected to delete");
      return;
    }

    setState(() {
      _isDeletingMessages = true;
    });

    _markMessagesAsDeleted(_selectedMessageIds.toList());

    _groupBloc.add(DeleteMessagesEvent(
      messageIds: _selectedMessageIds.toList(),
      convoId: widget.conversationId,
      senderId: currentUserId,
      receiverId: widget.datumId,
      message: _selectedMessageKeys.first,
    ));

    setState(() {
      _selectedMessages.clear();
      _selectedMessageIds.clear();
      _selectedMessageKeys.clear();
      _isSelectionMode = false;
      _isDeletingMessages = false;
    });
  }

  void _toggleMessageSelection(Map<String, dynamic> msg) {
    final key = _generateMessageKey(msg);
    final String? messageId = msg['message_id']?.toString();

    setState(() {
      if (_selectedMessageIds.contains(messageId)) {
        _selectedMessageIds.remove(messageId);
        _selectedMessageKeys.remove(key);
        _selectedMessages.removeWhere((m) => _generateMessageKey(m) == key);
      } else if (messageId != null) {
        _selectedMessageIds.add(messageId);
        _selectedMessageKeys.add(key);
        _selectedMessages.add(msg);
      }
      _isSelectionMode = _selectedMessageIds.isNotEmpty;
    });
  }

  void _forwardSelectedMessages() {
    MyRouter.pushReplace(
      screen: ForwardMessageScreen(
        messages: _selectedMessages.toList(),
        currentUserId: currentUserId,
        conversionalid: "",
        username: widget.groupName,
      ),
    );

    setState(() {
      _selectedMessages.clear();
      _selectedMessageKeys.clear();
      _selectedMessageIds.clear();
      _isSelectionMode = false;
    });
  }

  void _starSelectedMessages() {
    setState(() {
      _selectedMessages.clear();
      _isSelectionMode = false;
    });
  }

  void _replyToMessage(Map<String, dynamic> message) {
    if (message.isEmpty) return;
    setState(() {
      _replyMessage = message;
      _focusNode.requestFocus();
    });
  }

  void _toggleEmojiKeyboard() {
    setState(() {
      _showEmoji = !_showEmoji;
    });

    if (_showEmoji) {
      _focusNode.unfocus();
    } else {
      _focusNode.requestFocus();
    }
  }

  Future<void> _clearSessionImagePath() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('chat_image_path');
    await prefs.remove('chat_file_path');
  }

  String _generateMessageKey(Map<String, dynamic> msg) {
    return '${msg['message_id'] ?? msg['time']}_${msg['content']}_${msg['imageUrl'] ?? ''}_${msg['fileUrl'] ?? ''}${msg['userName'] ?? ''}';
  }

  /// Merge all messages (db + messages + socket), sort, dedupe
  List<Map<String, dynamic>> _getCombinedMessages() {
    final List<Map<String, dynamic>> combined = [];

    void addUnique(Map<String, dynamic> msg) {
      if (msg['content']?.toString().trim() == '' &&
          (msg['imageUrl'] == null || msg['imageUrl'].toString().isEmpty) &&
          (msg['fileUrl'] == null || msg['fileUrl'].toString().isEmpty)) {
        return;
      }

      bool exists = combined.any((m) =>
          m['time'] == msg['time'] &&
          m['content'] == msg['content'] &&
          m['ContentType'] == msg['ContentType'] &&
          (m['isReplyMessage'] ?? false) == (msg['isReplyMessage'] ?? false) &&
          (m['imageUrl'] ?? '') == (msg['imageUrl'] ?? '') &&
          (m['fileName'] ?? '') == (msg['fileName'] ?? '') &&
          (m['fileUrl'] ?? '') == (msg['fileUrl'] ?? ''));

      if (!exists) combined.add(msg);
    }

    for (var m in dbMessages) addUnique(m);
    for (var m in messages) addUnique(m);
    for (var m in socketMessages) addUnique(m);

    combined.sort(
      (a, b) => _parseTime(a['time']).compareTo(_parseTime(b['time'])),
    );

    return combined;
  }

  /// Load older pages until message with [messageId] exists or no more pages
  Future<bool> _fetchUntilMessageFound(String messageId) async {
    if (messageId.isEmpty) return false;
    int safety = 0;

    while (safety < 10 && mounted) {
      safety++;

      final combined = _getCombinedMessages();
      final exists = combined.any((m) {
        final mid = (m['message_id'] ?? m['id'])?.toString() ?? '';
        return mid == messageId;
      });

      if (exists) return true;
      if (!_hasNextPage) return false;

      final completer = Completer<void>();
      late final StreamSubscription sub;

      sub = _groupBloc.stream.listen((state) {
        if (state is GroupChatLoaded && !completer.isCompleted) {
          completer.complete();
        }
      });

      _currentPage++;
      _groupBloc.add(
        FetchGroupMessages(
          convoId: widget.conversationId,
          page: _currentPage,
          limit: _limit,
        ),
      );

      try {
        await completer.future;
      } finally {
        await sub.cancel();
      }
    }

    final combined = _getCombinedMessages();
    return combined.any((m) {
      final mid = (m['message_id'] ?? m['id'])?.toString() ?? '';
      return mid == messageId;
    });
  }

  /// Scroll to message used in reply, with pagination + local storage
  Future<bool> _scrollToMessageById(String messageId,
      {bool fetchIfMissing = true}) async {
    if (messageId.isEmpty) return false;

    List<Map<String, dynamic>> combined = _getCombinedMessages();

    int index = combined.indexWhere((m) {
      final mid = (m['message_id'] ?? m['id'])?.toString() ?? '';
      return mid == messageId;
    });

    if (index == -1 && fetchIfMissing) {
      final found = await _fetchUntilMessageFound(messageId);
      if (!found) return false;

      combined = _getCombinedMessages();
      index = combined.indexWhere((m) {
        final mid = (m['message_id'] ?? m['id'])?.toString() ?? '';
        return mid == messageId;
      });

      if (index == -1) return false;
    }

    if (!_scrollController.hasClients) return false;

    await Future.delayed(const Duration(milliseconds: 50));

    const double itemHeightEstimate = 80.0;
    final double offset = (index * itemHeightEstimate)
        .clamp(0.0, _scrollController.position.maxScrollExtent);

    await _scrollController.animateTo(
      offset,
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOut,
    );

    return true;
  }

  /// Reply preview (tap → scroll to original). Works after reopen because ids are persisted.
  Widget _buildReplyPreview(Map<String, dynamic> message, bool isSentByMe) {
    final Map<String, dynamic>? reply = (message['repliedMessage'] ??
        message['reply']) as Map<String, dynamic>?;

    if (reply == null) return const SizedBox.shrink();

    final replyId = (reply['id'] ?? reply['message_id'] ?? reply['messageId'])
            ?.toString() ??
        '';

    final replyUser = (reply['replyToUser'] ??
            '${reply['first_name'] ?? ''} ${reply['last_name'] ?? ''}')
        .toString()
        .trim();

    final replyContent =
        (reply['replyContent'] ?? reply['content'] ?? '').toString();

    if (replyId.isEmpty && replyContent.isEmpty) {
      return const SizedBox.shrink();
    }

    return GestureDetector(
      onTap: () async {
        if (replyId.isEmpty) return;
        final ok = await _scrollToMessageById(replyId, fetchIfMissing: true);
        if (!ok && mounted) {
          Messenger.alert(
            msg:
                "Original message not loaded. Scroll up to load older messages.",
          );
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.grey.shade200,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 3,
              height: 32,
              decoration: BoxDecoration(
                color: Colors.grey.shade500,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(width: 6),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (replyUser.isNotEmpty)
                    Text(
                      replyUser,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                  if (replyContent.isNotEmpty)
                    Text(
                      replyContent,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Colors.black87,
                      ),
                    ),
                  const SizedBox(height: 2),
                  Text(
                    'Tap to view original',
                    style: TextStyle(
                      fontSize: 10,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Reaction pill under message bubble – shows emojis aggregated
  Widget _buildReactionsBar(Map<String, dynamic> message, bool isSentByMe) {
    final raw = message['reactions'];
    if (raw == null || raw is! List) return const SizedBox.shrink();

    final List<Map<dynamic, dynamic>> reactions = raw.whereType<Map>().toList();
    if (reactions.isEmpty) return const SizedBox.shrink();

    final Map<String, int> counts = {};
    for (final r in reactions) {
      final emoji = (r['emoji'] ?? '').toString();
      if (emoji.isEmpty) continue;
      counts[emoji] = (counts[emoji] ?? 0) + 1;
    }
    if (counts.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(top: 4, left: 40, right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 3,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: counts.entries.map((e) {
          final label = e.value > 1 ? '${e.key} ${e.value}' : e.key;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2.0),
            child: Text(
              label,
              style: const TextStyle(fontSize: 13),
            ),
          );
        }).toList(),
      ),
    );
  }

  List<Map<String, dynamic>> flattenGroupedMessages(
      List<GroupMessageGroup> groups) {
    final List<Map<String, dynamic>> flat = [];

    for (var group in groups) {
      for (var msg in group.messages) {
        flat.add(msg.toJson());
      }
    }

    return flat;
  }

  Widget _buildChatBody() {
    return BlocListener<GroupChatBloc, GroupChatState>(
      listener: (context, state) {
        if (state is GrpMessageSentSuccessfully) {
          final newMessage = state.sentMessage;

          if (newMessage != null) {
            setState(() {
              socketMessages.removeWhere((msg) =>
                  msg['content'] == newMessage.message &&
                  msg['time'] == newMessage.time);
              messages.add(newMessage.toJson());
              _scrollToBottom();

              final combined = [...dbMessages, ...messages, ...socketMessages];
              GrpLocalChatStorage.saveMessages(widget.conversationId, combined);
            });
          }
        } else if (state is GroupChatError) {
          setState(() => _isDeletingMessages = false);
        }
      },
      child: BlocBuilder<GroupChatBloc, GroupChatState>(
        builder: (context, state) {
          // List<dynamic> loadedMessages =
          //     (state is GroupChatLoaded) ? state.response.data ?? [] : [];
          List<Map<String, dynamic>> loadedMessages = [];

          if (state is GroupChatLoaded) {
            loadedMessages = flattenGroupedMessages(state.response.data);
          }

          if (state is GroupChatLoading &&
              _currentPage == 1 &&
              messages.isEmpty &&
              socketMessages.isEmpty) {
            return ListView.builder(
              itemCount: 10,
              itemBuilder: (context, index) {
                final isSentByMe = index % 3 == 0;
                return ShimmerMessageBubble(
                  isSentByMe: isSentByMe,
                );
              },
            );
          }

          if (state is GroupChatLoaded) {
            _hasNextPage = state.response.hasNextPage ?? false;
            _isLoadingMore = false;

            final newDbMessages = loadedMessages
                .map<Map<String, dynamic>>((msg) => normalizeMessage(msg))
                .where((m) => m.isNotEmpty)
                .toList();
            _isSelectionMode ? voidBox : _scrollToBottom();

            if (!listEquals(dbMessages, newDbMessages)) {
              dbMessages = newDbMessages;
              GrpLocalChatStorage.saveMessages(
                  widget.conversationId, dbMessages);
            }

            for (var m in newDbMessages) {
              final id = (m['message_id'] ?? m['id'])?.toString();
              if (id != null && id.isNotEmpty) _seenMessageIds.add(id);
            }
          }

          final combinedMessages = _getCombinedMessages();

          GrpLocalChatStorage.saveMessages(
              widget.conversationId, combinedMessages);

          if (!_initialScrollDone && _scrollController.hasClients) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _scrollController.animateTo(
                _scrollController.position.maxScrollExtent,
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeInOutSine,
              );
              _initialScrollDone = true;
            });
          }

          return ListView.builder(
            controller: _scrollController,
            reverse: false,
            itemCount: combinedMessages.length + (_hasNextPage ? 1 : 0),
            itemBuilder: (context, index) {
              // Top loader when there are more pages
              if (_hasNextPage && index == 0) {
                if (_isLoadingMore) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: Center(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    ),
                  );
                } else {
                  return const SizedBox(height: 8);
                }
              }

              final adjustedIndex = _hasNextPage ? index - 1 : index;

              if (adjustedIndex < 0 ||
                  adjustedIndex >= combinedMessages.length) {
                return const SizedBox.shrink();
              }

              final message = combinedMessages[adjustedIndex];
              final senderMap = (message['sender'] is Map)
                  ? Map<String, dynamic>.from(message['sender'])
                  : <String, dynamic>{};

              final isSentByMe = senderMap['_id'] == currentUserId;
              final isSystem = message['ContentType'] == "system";
              final content = message['content']?.toString() ?? '';

              final currentTime = _parseTime(message['time']);
              final prevTime = adjustedIndex > 0
                  ? _parseTime(combinedMessages[adjustedIndex - 1]['time'])
                  : DateTime.now();

              List<Widget> children = [];

              if (isSystem &&
                  (content.contains('Group created by') ||
                      content.contains('added') ||
                      content.contains('left'))) {
                children.add(_buildtextSeparator(content));
              }

              if (adjustedIndex == 0 || !isSameDay(currentTime, prevTime)) {
                children.add(_buildDateSeparator(currentTime));
              }

              children.add(_buildMessageBubble(message, isSentByMe));

              return Column(
                crossAxisAlignment: isSentByMe
                    ? CrossAxisAlignment.end
                    : CrossAxisAlignment.start,
                children: children,
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> message, bool isSentByMe) {
    final String content = message['content']?.toString() ?? '';
    final String? imageUrl = message['imageUrl'] ?? _imageFile;
    final String? fileUrl = message['fileUrl'] ?? _fileUrl;
    final String? fileName = message['fileName'];
    final String? fileType = message['fileType'];
    final bool? isForwarded = message['isForwarded'];
    final String userName = message['userName'] ?? "";
    final String contentType = message['ContentType'] ?? "";
    final senderData = message['sender'] is Map ? message['sender'] : {};
    final String profileImageUrl = senderData['profile_pic_path']?.toString() ??
        senderData['profilePic']?.toString() ??
        senderData['avatar']?.toString() ??
        message['profile_pic_path']?.toString() ??
        "";

    if (message['isDeleted'] == true ||
        message['content'] == 'Message Deleted') {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Text(
          "This message was deleted",
          style: TextStyle(color: Colors.grey, fontStyle: FontStyle.italic),
        ),
      );
    }

    final String messageStatus =
        message['messageStatus']?.toString() ?? 'delivered';

    if (content.isEmpty &&
        (imageUrl == null || imageUrl.isEmpty) &&
        (fileUrl == null || fileUrl.isEmpty)) {
      return const SizedBox.shrink();
    }

    final isSelected =
        _selectedMessageKeys.contains(_generateMessageKey(message));

    // reply detection – don't depend only on isReplyMessage flag
    final bool hasReply = (message['repliedMessage'] is Map &&
            (message['repliedMessage']['id'] ??
                    message['repliedMessage']['message_id'] ??
                    message['repliedMessage']['messageId']) !=
                null) ||
        (message['reply'] is Map &&
            (message['reply']['id'] ??
                    message['reply']['message_id'] ??
                    message['reply']['messageId']) !=
                null);

    return message['content'].contains('Group created by')
        ? voidBox
        : (contentType == "system" &&
                (content.contains('added') || content.contains('left')))
            ? voidBox
            : SwipeTo(
                animationDuration: const Duration(milliseconds: 150),
                iconOnRightSwipe: Icons.reply,
                iconColor: Colors.grey.shade600,
                iconSize: 24.0,
                offsetDx: 0.3,
                swipeSensitivity: 5,
                onRightSwipe: (details) {
                  _replyToMessage(message);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      vertical: 5.0, horizontal: 4.0),
                  child: InkWell(
                    onTap: () {
                      if (_isSelectionMode) {
                        _toggleMessageSelection(message);
                      }
                    },
                    onLongPress: () {
                      if (_isSelectionMode) {
                        _toggleMessageSelection(message);
                      } else {
                        // 👇 SAME reaction bottom sheet as private chat
                        ReactionDialog.show(
                          context: context,
                          messageId: message['message_id']?.toString() ?? '',
                          reactions: (message['reactions'] as List?)
                                  ?.whereType<Map<String, dynamic>>()
                                  .toList() ??
                              [],
                          currentUserId: currentUserId,
                          convoId: widget.conversationId,
                          receiverId: widget.datumId,
                          firstName: widget.groupName,
                          lastName: "",
                        );
                      }
                    },
                    child: Align(
                      alignment: isSentByMe
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 36),
                            child: Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 5, vertical: 6),
                              padding: const EdgeInsets.all(7),
                              constraints: const BoxConstraints(maxWidth: 250),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? chatColor.withOpacity(0.2)
                                    : (isSentByMe
                                        ? primaryshadecolor.withOpacity(0.3)
                                        : Colors.white),
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(16),
                                  topRight: const Radius.circular(16),
                                  bottomLeft: isSentByMe
                                      ? const Radius.circular(16)
                                      : Radius.zero,
                                  bottomRight: isSentByMe
                                      ? Radius.zero
                                      : const Radius.circular(16),
                                ),
                                border: isSelected
                                    ? Border.all(color: Colors.blue, width: 2.5)
                                    : null,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    blurRadius: 4,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (!isSentByMe && userName.isNotEmpty)
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 4.0),
                                      child: Text(
                                        userName,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black87,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),

                                  // REPLY PREVIEW
                                  if (hasReply)
                                    _buildReplyPreview(message, isSentByMe),

                                  if (isForwarded == true)
                                    Row(
                                      children: [
                                        Image.asset(
                                          "assets/images/forward.png",
                                          height: 15,
                                          width: 15,
                                        ),
                                        const Text(" Forwarded"),
                                      ],
                                    ),

                                  if (imageUrl != null && imageUrl.isNotEmpty)
                                    content == "Message Deleted"
                                        ? const SizedBox.shrink()
                                        : GestureDetector(
                                            onTap: () => _showFullImage(
                                                context, imageUrl),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                              child: imageUrl.startsWith(
                                                          'https') ||
                                                      imageUrl
                                                          .startsWith('http')
                                                  ? CachedNetworkImage(
                                                      imageUrl: imageUrl,
                                                      width: 240,
                                                      height: 240,
                                                      fit: BoxFit.cover,
                                                      placeholder: (context,
                                                              url) =>
                                                          const Center(
                                                              child:
                                                                  CircularProgressIndicator()),
                                                      errorWidget: (context,
                                                              url, error) =>
                                                          const Icon(
                                                              Icons.error,
                                                              color:
                                                                  Colors.red),
                                                    )
                                                  : Image.file(File(imageUrl),
                                                      width: 240,
                                                      height: 240,
                                                      fit: BoxFit.cover),
                                            ),
                                          ),

                                  if (fileUrl != null && fileUrl.isNotEmpty)
                                    content == "Message Deleted"
                                        ? const SizedBox.shrink()
                                        : Container(
                                            margin:
                                                const EdgeInsets.only(top: 8),
                                            padding: const EdgeInsets.all(8),
                                            decoration: BoxDecoration(
                                              color: Colors.grey[200],
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(_getFileIcon(fileType),
                                                    color: chatColor, size: 30),
                                                const SizedBox(width: 8),
                                                Expanded(
                                                  child: Text(
                                                    fileName ?? 'Download file',
                                                    style: const TextStyle(
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ),
                                                IconButton(
                                                  icon: const Icon(
                                                      Icons.download_rounded),
                                                  onPressed: () => _openFile(
                                                      fileUrl, fileType),
                                                ),
                                              ],
                                            ),
                                          ),

                                  if (content.isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 6),
                                      child: Builder(
                                        builder: (context) {
                                          final bool useIntrinsic =
                                              content.trim().length < 20;

                                          final Widget messageContent = Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              if (RegExp(r'https?:\/\/[^\s]+')
                                                  .hasMatch(content))
                                                AnyLinkPreview(
                                                  link:
                                                      RegExp(r'https?:\/\/[^\s]+')
                                                              .firstMatch(
                                                                  content)
                                                              ?.group(0) ??
                                                          '',
                                                  displayDirection: UIDirection
                                                      .uiDirectionVertical,
                                                  showMultimedia: true,
                                                  backgroundColor:
                                                      Colors.grey.shade200,
                                                  bodyStyle: const TextStyle(
                                                      color:
                                                          Colors.transparent),
                                                  cache:
                                                      const Duration(hours: 1),
                                                ),
                                              Linkify(
                                                text: content,
                                                onOpen: (link) async {
                                                  final uri =
                                                      Uri.parse(link.url);
                                                  if (await canLaunchUrl(uri)) {
                                                    await launchUrl(uri,
                                                        mode: LaunchMode
                                                            .externalApplication);
                                                  }
                                                },
                                                style: const TextStyle(
                                                    fontSize: 15,
                                                    color: Colors.black87),
                                                linkStyle: const TextStyle(
                                                  color: Colors.blue,
                                                  decoration:
                                                      TextDecoration.underline,
                                                ),
                                              ),
                                              const SizedBox(height: 4),
                                              isSentByMe
                                                  ? Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          TimeUtils
                                                              .formatUtcToIst(
                                                                  message[
                                                                      'time']),
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 10,
                                                            color:
                                                                Colors.black54,
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                            width: 4),
                                                        if (content !=
                                                                "Message Deleted" &&
                                                            isSentByMe)
                                                          _buildStatusIcon(
                                                              messageStatus),
                                                      ],
                                                    )
                                                  : Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Text(
                                                        TimeUtils
                                                            .formatUtcToIst(
                                                                message[
                                                                    'time']),
                                                        style: const TextStyle(
                                                          fontSize: 10,
                                                          color: Colors.black54,
                                                        ),
                                                      ),
                                                    ),
                                            ],
                                          );

                                          final constrainedBox = ConstrainedBox(
                                            constraints: const BoxConstraints(
                                                maxWidth: 250),
                                            child: messageContent,
                                          );

                                          return useIntrinsic
                                              ? IntrinsicWidth(
                                                  child: constrainedBox)
                                              : constrainedBox;
                                        },
                                      ),
                                    ),

                                  if ((message['reactions'] as List?)
                                          ?.isNotEmpty ??
                                      false)
                                    _buildReactionsBar(message, isSentByMe),
                                ],
                              ),
                            ),
                          ),
                          isSentByMe
                              ? const SizedBox.shrink()
                              : Positioned(
                                  left: isSentByMe ? null : 2,
                                  right: isSentByMe ? 2 : null,
                                  top: 10,
                                  child: CircleAvatar(
                                    radius: 16,
                                    backgroundColor: Colors.transparent,
                                    child: ClipOval(
                                      child: profileImageUrl.isNotEmpty
                                          ? CachedNetworkImage(
                                              imageUrl: profileImageUrl,
                                              width: 32,
                                              height: 32,
                                              fit: BoxFit.cover,
                                              placeholder: (context, url) =>
                                                  _buildAvatarWithInitial(
                                                      userName),
                                              errorWidget:
                                                  (context, url, error) =>
                                                      _buildAvatarWithInitial(
                                                          userName),
                                            )
                                          : _buildAvatarWithInitial(userName),
                                    ),
                                  ),
                                ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
  }

  void _openFile(String urlOrPath, String? fileType) async {
    if (urlOrPath.startsWith('http://') || urlOrPath.startsWith('https://')) {
      try {
        await launchUrl(Uri.parse(urlOrPath),
            mode: LaunchMode.externalApplication);
      } catch (e) {
        Messenger.alertError("Could not open file from URL.");
      }
    } else {
      final result = await OpenFile.open(urlOrPath);
      if (result.type != ResultType.done) {
        Messenger.alertError("Could not open local file.");
      }
    }
  }

  DateTime _parseTime(dynamic time) {
    if (time == null) return DateTime.now();
    if (time is int) return DateTime.fromMillisecondsSinceEpoch(time);
    if (time is String) {
      try {
        return DateTime.parse(time);
      } catch (_) {
        return DateTime.now();
      }
    }
    return DateTime.now();
  }

  Widget _buildStatusIcon(String status) {
    switch (status) {
      case 'sent':
        return Icon(Icons.check, size: 16, color: Colors.grey.shade600);
      case 'delivered':
        return Icon(Icons.done_all_rounded,
            size: 16, color: Colors.grey.shade600);
      case 'read':
        return const Icon(Icons.done_all, size: 16, color: Colors.blue);
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildDateSeparator(DateTime? dateTime) {
    if (dateTime == null) return const SizedBox.shrink();
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          _formatDateTime(dateTime),
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildtextSeparator(String? text) {
    if (text == null) return const SizedBox.shrink();
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  void _cancelReply() {
    setState(() {
      _replyMessage = null;
    });
  }

  void _startRecordingFs() async {
    await _recorder.startRecorder(toFile: 'voice.aac');
    setState(() {
      _isRecording = true;
      _isPaused = false;
      _recordDuration = 0;
    });
    _startTimer();
  }

  void _pauseRecordingFs() async {
    await _recorder.pauseRecorder();
    setState(() {
      _isPaused = true;
    });
    _timer?.cancel();
  }

  void _resumeRecordingFs() async {
    await _recorder.resumeRecorder();
    setState(() {
      _isPaused = false;
    });
    _startTimer();
  }

  void _stopRecordingFs() async {
    String? path = await _recorder.stopRecorder();
    _timer?.cancel();
    setState(() {
      _isRecording = false;
      _isPaused = false;
      _recordedFilePath = path;
    });
  }

  void _playRecording() async {
    if (_recordedFilePath != null) {
      await _player.startPlayer(fromURI: _recordedFilePath);
    }
  }

  void _sendRecording() {
    if (_recordedFilePath != null) {
      log("Send: $_recordedFilePath");
    }
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _recordDuration++;
      });
    });
  }

  String _formatDuration(int seconds) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$secs';
  }

  Widget _buildVoiceRecordingUI() {
    return VoiceRecordingWidget(
      isRecording: _isRecording,
      isPaused: _isPaused,
      recordDuration: Duration(seconds: _recordDuration),
      formatDuration: (duration) => _formatDuration(duration.inSeconds),
      onStartRecording: _startRecordingFs,
      onPauseRecording: _pauseRecordingFs,
      onResumeRecording: _resumeRecordingFs,
      onStopRecording: _stopRecordingFs,
      onPlayRecording: _playRecording,
      onSendRecording: _sendRecording,
      recordedFilePath: _recordedFilePath,
      onCancel: () {
        _timer?.cancel();
        setState(() {
          _isRecording = false;
          _isPaused = false;
          _recordedFilePath = null;
        });
      },
    );
  }

  Widget _buildMessageInputField(bool isKeyboardVisible, bool thereORleft) {
    return MessageInputField(
      messageController: _messageController,
      reciverID: widget.datumId,
      focusNode: _focusNode,
      onSendPressed: _sendMessage,
      onEmojiPressed: _toggleEmojiKeyboard,
      onAttachmentPressed: () => ShowAltDialog.showOptionsDialog(context,
          conversationId: widget.conversationId,
          senderId: currentUserId,
          receiverId: widget.datumId,
          isGroupChat: true,
          onOptionSelected: _sendMessageImage),
      onCameraPressed: _openCamera,
      onRecordPressed: _isRecording ? _stopRecordingFs : _startRecordingFs,
      isRecording: _isRecording,
      replyText: _replyMessage,
      onCancelReply: _cancelReply,
      thereORleft: thereORleft,
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return CommonAppBarBuilder.build(
        context: context,
        showSearchAppBar: _showSearchAppBar,
        isSelectionMode: _isSelectionMode,
        selectedMessages: _selectedMessages,
        toggleSelectionMode: _toggleSelectionMode,
        deleteSelectedMessages: _deleteSelectedMessages,
        forwardSelectedMessages: _forwardSelectedMessages,
        starSelectedMessages: _starSelectedMessages,
        replyToMessage: _replyToMessage,
        profileAvatarUrl: widget.groupAvatarUrl,
        convertionId: widget.conversationId,
        userName: widget.groupName,
        firstname: widget.groupName,
        grpId: widget.datumId,
        grpChat: widget.grpChat,
        resvID: widget.datumId,
        favouitre: widget.favorite,
        onSearchTap: () {
          setState(() {
            _showSearchAppBar = !_showSearchAppBar;
          });
        },
        onCloseSearch: () {
          setState(() {
            _showSearchAppBar = false;
          });
        });
  }

  @override
  Widget build(BuildContext context) {
    return ReusableChatScaffold(
      appBar: _buildAppBar(),
      chatBody: _buildChatBody(),
      voiceRecordingUI: _buildVoiceRecordingUI(),
      messageInputBuilder: (context) {
        return BlocBuilder<GroupChatBloc, GroupChatState>(
          buildWhen: (previous, current) =>
              current is GroupLeftState || current is GroupChatError,
          builder: (context, state) {
            if (state is GroupChatError) {
              log("GroupChatError: ${state.message}");
            }

            if (state is GroupLeftState) {
              return const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  'You have left the group',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.redAccent,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              );
            }

            final isKeyboardVisible =
                WidgetsBinding.instance.window.viewInsets.bottom > 0;

            return _buildMessageInputField(isKeyboardVisible, false);
          },
        );
      },
      isRecording: _isRecording,
      bloc: _groupBloc,
    );
  }
}

Widget _buildAvatarWithInitial(String name) {
  final String initial = name.isNotEmpty ? name[0].toUpperCase() : "?";
  return Container(
    width: 32,
    height: 32,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: name.isNotEmpty
          ? ColorUtil.getColorFromAlphabet(name)
          : Colors.grey.shade400,
    ),
    alignment: Alignment.center,
    child: Text(
      initial,
      style: const TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
        fontSize: 15,
      ),
    ),
  );
}
