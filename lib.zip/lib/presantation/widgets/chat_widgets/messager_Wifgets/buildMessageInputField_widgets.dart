import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:nde_email/data/respiratory.dart';
import 'package:nde_email/main.dart';
import 'package:nde_email/utils/reusbale/common_import.dart';

class MessageInputField extends StatefulWidget {
  final TextEditingController messageController;
  final FocusNode focusNode;
  final VoidCallback onSendPressed;
  final VoidCallback onEmojiPressed;
  final VoidCallback onAttachmentPressed;
  final VoidCallback onCameraPressed;
  final VoidCallback onRecordPressed;
  final bool isRecording;
  final Map<String, dynamic>? replyText;
  final VoidCallback? onCancelReply;
  final bool thereORleft;
    final String reciverID;

  const MessageInputField(
      {super.key,
      required this.messageController,
      required this.focusNode,
      required this.onSendPressed,
      required this.onEmojiPressed,
      required this.onAttachmentPressed,
      required this.onCameraPressed,
      required this.onRecordPressed,
      required this.isRecording,
            required this.reciverID,
      this.replyText,
      this.onCancelReply,
      this.thereORleft = false});

  @override
  _MessageInputFieldState createState() => _MessageInputFieldState();
}

class _MessageInputFieldState extends State<MessageInputField> {
  bool _showEmoji = false;
  String? detectedUrl;

  final mq = MediaQueryData.fromView(WidgetsBinding.instance.window);

  void _toggleEmojiKeyboard() {
    setState(() {
      _showEmoji = !_showEmoji;
    });

    if (_showEmoji) {
      widget.focusNode.unfocus();
    } else {
      widget.focusNode.requestFocus();
    }
  }

  /// Simple URL regex matcher
  String? extractUrl(String text) {
    final urlRegex = RegExp(r"(https?:\/\/[^\s]+)", caseSensitive: false);
    final match = urlRegex.firstMatch(text);
    return match?.group(0);
  }

  Widget _buildReplyPreview() {
    if (widget.replyText == null) return const SizedBox();

    final String content = widget.replyText?['content']?.toString() ?? '';
    final String? imageUrl = widget.replyText?['imageUrl'];
    final String? fileName = widget.replyText?['fileName'];
    final String? fileType = widget.replyText?['fileType'];
    final String userName = widget.replyText?['userName'] ?? '';

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        border: Border(
          left: BorderSide(color: Colors.blue.shade300, width: 4),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (userName.isNotEmpty)
                  Text(
                    'Replying to $userName',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                const SizedBox(height: 4),
                if (imageUrl != null && imageUrl.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4.0),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: Image.network(
                        imageUrl,
                        height: 80,
                        width: 80,
                        fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                        const Icon(Icons.broken_image),
                      ),
                    ),
                  ),
                if (fileName != null &&
                    fileName.trim().isNotEmpty &&
                    fileName.trim().toLowerCase() != 'file')
                  Text(
                    '📄 $fileName (${fileType ?? 'file'})',
                    style: const TextStyle(fontStyle: FontStyle.italic),
                  ),
                if (content.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: Text(content),
                  ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: widget.onCancelReply,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final text = widget.messageController.text.trim();
    detectedUrl = extractUrl(text);

    return widget.thereORleft == true
        ? voidBox
        : Padding(
            padding: EdgeInsets.symmetric(
              vertical: mq.size.height * .01,
              horizontal: mq.size.width * .025,
            ),
            child: Column(
              children: [
                if (widget.replyText != null) _buildReplyPreview(),

                // ✅ Link preview box
                if (detectedUrl != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: AnyLinkPreview(
                      link: detectedUrl!,
                      displayDirection: UIDirection.uiDirectionHorizontal,
                      showMultimedia: true,
                      bodyMaxLines: 3,
                      bodyTextOverflow: TextOverflow.ellipsis,
                      titleStyle: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14),
                      bodyStyle: const TextStyle(color: Colors.black),
                    ),
                  ),

                Row(
                  children: [
                    Expanded(
                      child: Card(
                        color: Colors.white,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(25)),
                        ),
                        child: Row(
                          children: [
                            IconButton(
                              onPressed: _toggleEmojiKeyboard,
                              icon: const Icon(Icons.emoji_emotions_outlined,
                                  color: Colors.black, size: 25),
                            ),
                            Expanded(
                              child: TextField(
                                controller: widget.messageController,
                                focusNode: widget.focusNode,
                                decoration: const InputDecoration(
                                  hintText: 'Message',
                                  hintStyle: TextStyle(color: Colors.grey),
                                  border: InputBorder.none,
                                ),
                                minLines: 1,
                                maxLines: 5,
                                          onChanged: (value) async {
                                  setState(() {});

                                  if (value.trim().isNotEmpty) {
                                   
                                    final userId =
                                        await UserPreferences.getUserId() ??
                                            "Unknown";
                                            print(userId);
                                            log(userId);

                                  
                                    final roomId = socketService.generateRoomId(
                                      userId,
                                      widget.reciverID, 
                                    );

                                    
                                    final userFullName =
                                        await UserPreferences.getUsername() ??
                                            "Unknown";

                             
                                    socketService.sendTyping(
                                      roomId: roomId,
                                      userName: userFullName,
                                    );
                                  }
                                },
                              ),
                            ),
                            IconButton(
                              onPressed: widget.onAttachmentPressed,
                              icon: const Icon(Icons.attach_file,
                                  color: Colors.black, size: 26),
                            ),
                            IconButton(
                              onPressed: widget.onCameraPressed,
                              icon: const Icon(Icons.camera_alt_rounded,
                                  color: Colors.black, size: 26),
                            ),
                            SizedBox(width: mq.size.width * .02),
                          ],
                        ),
                      ),
                    ),
                    MaterialButton(
                      onPressed: widget.messageController.text.trim().isEmpty
                          ? widget.onRecordPressed
                          : widget.onSendPressed,
                      minWidth: 0,
                      padding: const EdgeInsets.all(10),
                      shape: const CircleBorder(),
                      color: widget.messageController.text.trim().isEmpty
                          ? (widget.isRecording ? Colors.red : chatColor)
                          : chatColor,
                      child: Icon(
                        widget.messageController.text.trim().isEmpty
                            ? (widget.isRecording ? Icons.stop : Icons.mic)
                            : Icons.send,
                        color: Colors.white,
                        size: 28,
                      ),
                    ),
                  ],
                ),
                if (_showEmoji)
                  SizedBox(
                    height: 250,
                    child: EmojiPicker(
                      onEmojiSelected: (category, emoji) {
                        setState(() {
                          widget.messageController.text += emoji.emoji;
                        });
                      },
                    ),
                  ),
              ],
            ),
          );
  }
}
