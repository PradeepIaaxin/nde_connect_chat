import 'dart:async';
import 'dart:developer' show log;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_bloc.dart';
import 'package:nde_email/presantation/chat/chat_group_Screen/group_event.dart';
import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/MessagerBloc.dart';
import 'package:nde_email/presantation/chat/chat_private_screen/messager_Bloc/MessagerEvent.dart';
import 'package:mime/mime.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ShowAltDialog {
  static void showOptionsDialog(
    BuildContext context, {
    String? conversationId,
    String? senderId,
    String? receiverId,
    String? roomId,
    String? workspaceId,
    bool? isGroupChat,
    required VoidCallback onOptionSelected,
  }) {
    XFile? selectedFile;
    String? selectedLabel;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setState) {
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text("Select an Option",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    if (selectedFile == null) ...[
                      GridView.count(
                        shrinkWrap: true,
                        crossAxisCount: 4,
                        mainAxisSpacing: 16,
                        crossAxisSpacing: 16,
                        children: [
                          _buildOption(context, Icons.photo_library, "Gallery",
                              () async {
                            final XFile? file = await ImagePicker()
                                .pickImage(source: ImageSource.gallery);
                            if (file != null) {
                              setState(() {
                                selectedFile = file;
                                selectedLabel = 'Image';
                              });
                            }
                          }),
                          _buildOption(context, Icons.camera_alt, "Camera",
                              () async {
                            final XFile? file = await ImagePicker()
                                .pickImage(source: ImageSource.camera);
                            if (file != null) {
                              setState(() {
                                selectedFile = file;
                                selectedLabel = 'Image';
                              });
                            }
                          }),
                          _buildOption(
                              context, Icons.insert_drive_file, "Document",
                              () async {
                            final result =
                                await FilePicker.platform.pickFiles();
                            if (result != null &&
                                result.files.single.path != null) {
                              setState(() {
                                selectedFile = XFile(result.files.single.path!);
                                selectedLabel = 'Document';
                              });
                            }
                          }),
                          _buildOption(context, Icons.audiotrack, "Audio",
                              () async {
                            final result = await FilePicker.platform
                                .pickFiles(type: FileType.audio);
                            if (result != null &&
                                result.files.single.path != null) {
                              setState(() {
                                selectedFile = XFile(result.files.single.path!);
                                selectedLabel = 'Audio';
                              });
                            }
                          }),
                          _buildOption(context, Icons.location_on, "Location",
                              () async {}),
                        ],
                      )
                    ] else ...[
                      const SizedBox(height: 10),
                      if (selectedLabel == 'Image')
                        FutureBuilder<ImageInfo>(
                          future: _loadImageDimensions(selectedFile!.path),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.done) {
                              if (snapshot.hasError || !snapshot.hasData) {
                                return const Center(
                                  child: Text('Failed to load image'),
                                );
                              }
                              return Image.file(
                                File(selectedFile!.path),
                                height: 500,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              );
                            }
                            return const CircularProgressIndicator();
                          },
                        )
                      else
                        Column(
                          children: [
                            Icon(_getIconForType(selectedLabel!), size: 80),
                            const SizedBox(height: 10),
                            Text(selectedFile!.name,
                                style: const TextStyle(fontSize: 16)),
                          ],
                        ),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        icon: const Icon(Icons.send),
                        label: const Text("Send"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                        ),
                        onPressed: () async {
                          await _sendFile(
                              context: context,
                              file: selectedFile!,
                              conversationId: conversationId!,
                              senderId: senderId!,
                              receiverId: receiverId!,
                              isGroupChat: isGroupChat ?? false);

                          log("onOptionSelected");
                          onOptionSelected();

                          Navigator.of(context).pop();
                        },
                      ),
                      TextButton(
                        onPressed: () => setState(() {
                          selectedFile = null;
                          selectedLabel = null;
                        }),
                        child: const Text("Choose Another"),
                      ),
                    ]
                  ],
                ),
              ),
            ),
          );
        });
      },
    );
  }

  static Future<ImageInfo> _loadImageDimensions(String filePath) async {
    final image = Image.file(File(filePath));
    final completer = Completer<ImageInfo>();
    image.image.resolve(ImageConfiguration()).addListener(
      ImageStreamListener((ImageInfo imageInfo, bool synchronousCall) {
        completer.complete(imageInfo);
      }),
    );
    return completer.future;
  }

  static IconData _getIconForType(String label) {
    switch (label) {
      case 'Document':
        return Icons.insert_drive_file;
      case 'Audio':
        return Icons.audiotrack;
      case 'Location':
        return Icons.location_on;
      default:
        return Icons.insert_drive_file;
    }
  }

  static Future<void> saveImagePathToSession(File imageFile) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString('chat_image_path', imageFile.path);
    log(" Image path saved to session: ${imageFile.path}");
  }

  static Future<void> saveFilePathToSession(File fileFile) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString('chat_file_path', fileFile.path);
    log(" File path saved to session: ${fileFile.path}");
  }

  static Future<void> _sendFile({
    required BuildContext context,
    required XFile file,
    required String conversationId,
    required String senderId,
    required String receiverId,
    required bool isGroupChat,
  }) async {
    try {
      final File localFile = File(file.path);

      if (!localFile.existsSync()) {
        log("  File does not exist at: ${file.path}");
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Selected file is missing.")),
        );
        return;
      }

      final mimeType = lookupMimeType(file.path);
      final isImage = mimeType != null && mimeType.startsWith('image/');
      log("📄 Detected MIME type: $mimeType");
      log("🖼️ Is Image: $isImage");

      final prefs = await SharedPreferences.getInstance();

      if (isImage) {
        await prefs.setString('chat_image_path', localFile.path);
        log(" Image path saved: ${localFile.path}");
      } else {
        await prefs.setString('chat_file_path', localFile.path);
        log(" File path saved: ${localFile.path}");
      }

      final message = {
        'content': '',
        'sender': {'_id': senderId},
        'receiver': {'_id': receiverId},
        'messageStatus': 'pending',
        'time': DateTime.now().toIso8601String(),
        'localImagePath': isImage ? file.path : null,
        'fileName': file.name,
        'fileType': mimeType,
        'imageUrl': isImage ? file.path : null,
        'fileUrl': !isImage ? file.path : null,
      };

      log("🟢 Local message metadata: $message");

      if (isGroupChat) {
        context.read<GroupChatBloc>().add(
              GrpUploadFileEvent(
                localFile,
                conversationId,
                senderId,
                receiverId,
                "",
              ),
            );
      } else {
        context.read<MessagerBloc>().add(
              UploadFileEvent(
                localFile,
                conversationId,
                senderId,
                receiverId,
                "",
              ),
            );
      }
    } catch (e, stacktrace) {
      log("  Error uploading file: $e");
      log("🪵 Stacktrace: $stacktrace");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to upload file.")),
      );
    }
  }

  static Widget _buildOption(
    BuildContext context,
    IconData icon,
    String label,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: Colors.blue.shade200,
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(height: 6),
          Text(label,
              style: const TextStyle(fontSize: 12),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
