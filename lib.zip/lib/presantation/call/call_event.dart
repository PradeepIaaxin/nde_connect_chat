abstract class CallEvent {}

class FetchCallHistoryEvent extends CallEvent {}
