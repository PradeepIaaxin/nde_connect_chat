class NotificationModel {
  final String rcpt;
  final String userId;
  final String userAddress;
  final String fromAddress; //  Sender email
  final String fromName; //  Sender name
  final String threadId;
  final String mailbox;
  final String path;
  final int uid;
  final String id;
  final String message;
  final String type;
  final DateTime time;
  final String workspaceId;

  NotificationModel({
    required this.rcpt,
    required this.userId,
    required this.userAddress,
    required this.fromAddress,
    required this.fromName,
    required this.threadId,
    required this.mailbox,
    required this.path,
    required this.uid,
    required this.id,
    required this.message,
    required this.type,
    required this.time,
    required this.workspaceId,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      rcpt: json['rcpt'] ?? '',
      userId: json['user'] ?? '',
      userAddress: json['userAddress'] ?? '',
      fromAddress: json['fromAddress'] ?? 'No Email', //  Email
      fromName: json['fromName'] ?? 'Unknown Sender', //  Name
      threadId: json['threadId'] ?? '',
      mailbox: json['mailbox'] ?? '',
      path: json['path'] ?? '',
      uid: json['uid'] ?? 0,
      id: json['id'] ?? '',
      message: json['message'] ?? 'No Message',
      type: json['type'] ?? '',
      time: _parseDateTime(json['time']),
      workspaceId: json['workspace_id'] ?? '',
    );
  }

  static DateTime _parseDateTime(dynamic date) {
    try {
      if (date != null && date is String && date.isNotEmpty) {
        return DateTime.parse(date);
      }
    } catch (_) {}
    return DateTime.now();
  }

  Map<String, dynamic> toJson() {
    return {
      'rcpt': rcpt,
      'user': userId,
      'userAddress': userAddress,
      'fromAddress': fromAddress,
      'fromName': fromName,
      'threadId': threadId,
      'mailbox': mailbox,
      'path': path,
      'uid': uid,
      'id': id,
      'message': message,
      'type': type,
      'time': time.toIso8601String(),
      'workspace_id': workspaceId,
    };
  }
}
