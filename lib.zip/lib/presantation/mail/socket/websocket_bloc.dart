import 'dart:async';
import 'dart:developer';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'websocket_event.dart';
import 'websocket_state.dart';
import 'package:nde_email/domain/sockets/mail_socket/socket.dart';
import 'package:nde_email/presantation/mail/socket/websocket_model.dart';
import 'dart:convert';
import 'package:nde_email/domain/sockets/mail_socket/nottification.dart';

class WebSocketBloc extends Bloc<WebSocketEvent, WebSocketState> {
  final WebSocketService socketService;
  final List<NotificationModel> notifications = [];

  WebSocketBloc(this.socketService) : super(WebSocketInitial()) {
    on<ConnectWebSocket>((event, emit) async {
      await socketService.connect();
      emit(WebSocketConnected());

      // Add a delay before listening to avoid race conditions
      Future.delayed(Duration(seconds: 1), () {
        socketService.messages.listen((message) {
          add(ReceiveMessage(message));
        });
      });
    });

    on<ReceiveMessage>((event, emit) async {
      try {
        final Map<String, dynamic> data = jsonDecode(event.message);
        final newNotification = NotificationModel.fromJson(data);

        notifications.add(newNotification);

        String senderName = newNotification.fromName;
        String senderEmail = newNotification.fromAddress;

        // Display notification with both name and email
        await NotificationService.showNotification(
          title: '📧 $senderName',
          body: 'Email: $senderEmail\n${newNotification.message}',
        );

        emit(WebSocketMessageReceived(List.from(notifications)));
      } catch (e) {
        log('  Error parsing message: $e');
      }
    });
  }

  @override
  Future<void> close() {
    socketService.dispose();
    return super.close();
  }
}
