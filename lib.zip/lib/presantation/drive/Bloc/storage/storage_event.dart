abstract class StorageEvent {}

class FetchStorageData extends StorageEvent {}

